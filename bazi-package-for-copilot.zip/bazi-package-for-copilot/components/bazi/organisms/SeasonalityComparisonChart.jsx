/**
 * ============================================================================
 * SEASONALITY COMPARISON CHART - 8-CHART CATHEDRAL LAYOUT
 * ============================================================================
 *
 * The complete "Before → After" pilgrimage through elemental transformation.
 *
 * Layout: 2 columns × 4 rows = 8 charts total
 *
 * LEFT COLUMN (Raw/Unadjusted):
 *   1. Raw Donut Chart
 *   2. Raw Horizontal Bar Chart
 *   3. Raw Vertical Bar Chart
 *   4. Raw Radar Fingerprint
 *
 * RIGHT COLUMN (Adjusted/Seasonality-Weighted):
 *   5. Adjusted Donut Chart
 *   6. Adjusted Horizontal Bar Chart
 *   7. Adjusted Vertical Bar Chart
 *   8. Super-Imposed Radar (raw faint + adjusted bold)
 *
 * This creates a visual "before → after" ceremonial walk from narthex to nave.
 *
 * Created: January 2026
 * Based on: Classical 四季土 (Four Season Earth) Doctrine
 * ============================================================================
 */

import React, { useMemo } from 'react';
import { ResponsiveBar } from '@nivo/bar';
import { ResponsiveRadar } from '@nivo/radar';
import { ResponsivePie } from '@nivo/pie';
import {
  applySeasonality,
  calculateSeasonalImpact,
  getSeasonalGainersLosers,
  ELEMENT_COLORS,
  ELEMENT_CHINESE,
  ELEMENT_EMOJIS
} from '../../../utils/baziSeasonality';
import { useBaziTheme, getElementColor, getElementIcon } from '../theme/BaziTheme';

// ============================================================================
// MAIN COMPONENT
// ============================================================================

export function SeasonalityComparisonChart({
  rawDistribution,
  monthBranch,
  title = "Seasonality Adjustment",
  showExplanation = true,
  compact = false
}) {
  const theme = useBaziTheme();
  const isDark = theme?.mode === 'dark' || true; // Default to dark

  // Normalize raw distribution to lowercase keys
  const normalizedRaw = useMemo(() => ({
    wood: rawDistribution?.wood || rawDistribution?.Wood || 0,
    fire: rawDistribution?.fire || rawDistribution?.Fire || 0,
    earth: rawDistribution?.earth || rawDistribution?.Earth || 0,
    metal: rawDistribution?.metal || rawDistribution?.Metal || 0,
    water: rawDistribution?.water || rawDistribution?.Water || 0
  }), [rawDistribution]);

  // Apply seasonality adjustment
  const seasonalityResult = useMemo(() => {
    if (!rawDistribution || !monthBranch) return null;
    return applySeasonality(normalizedRaw, monthBranch);
  }, [normalizedRaw, monthBranch]);

  // Calculate impact
  const impact = useMemo(() => {
    if (!seasonalityResult) return null;
    return calculateSeasonalImpact(normalizedRaw, seasonalityResult.normalized);
  }, [normalizedRaw, seasonalityResult]);

  const { gainers, losers } = useMemo(() => {
    if (!impact) return { gainers: [], losers: [] };
    return getSeasonalGainersLosers(impact);
  }, [impact]);

  if (!seasonalityResult) {
    return (
      <div className="p-4 text-center text-white/40">
        No data available for seasonality analysis
      </div>
    );
  }

  // Prepare normalized raw for comparison (as percentages)
  const rawTotal = Object.values(normalizedRaw).reduce((a, b) => a + b, 0);
  const rawPercentages = {
    wood: rawTotal > 0 ? (normalizedRaw.wood / rawTotal) * 100 : 20,
    fire: rawTotal > 0 ? (normalizedRaw.fire / rawTotal) * 100 : 20,
    earth: rawTotal > 0 ? (normalizedRaw.earth / rawTotal) * 100 : 20,
    metal: rawTotal > 0 ? (normalizedRaw.metal / rawTotal) * 100 : 20,
    water: rawTotal > 0 ? (normalizedRaw.water / rawTotal) * 100 : 20
  };

  return (
    <div className="space-y-6">
      {/* Header with Season Info */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <h3 className={`text-lg font-semibold ${isDark ? 'text-white' : 'text-slate-900'} flex items-center gap-2`}>
          <span className="text-2xl">{seasonalityResult.seasonEmoji}</span>
          {title}
        </h3>
        <div className="flex items-center gap-3">
          <div className={`px-3 py-1 rounded-full ${isDark ? 'bg-amber-500/20 text-amber-400' : 'bg-amber-100 text-amber-700'} text-sm`}>
            {seasonalityResult.seasonChinese} Season • {monthBranch} Month
          </div>
          {/* Legend */}
          <div className="flex items-center gap-4 text-xs">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded-full bg-white/30 border border-white/50"></div>
              <span className={isDark ? 'text-white/60' : 'text-slate-500'}>Raw</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded-full bg-amber-500"></div>
              <span className={isDark ? 'text-white/60' : 'text-slate-500'}>Adjusted</span>
            </div>
          </div>
        </div>
      </div>

      {/* Dominant Element Change Indicator */}
      {seasonalityResult.dominantChanged && (
        <div className={`p-3 rounded-lg ${isDark ? 'bg-purple-500/20 border-purple-500/30' : 'bg-purple-50 border-purple-200'} border`}>
          <div className={`flex items-center gap-2 ${isDark ? 'text-purple-300' : 'text-purple-700'}`}>
            <span className="text-xl">⚡</span>
            <span className="font-medium">Dominant Element Shifted!</span>
          </div>
          <p className={`text-sm mt-1 ${isDark ? 'text-purple-200/80' : 'text-purple-600'}`}>
            {getElementIcon(seasonalityResult.dominantBefore)} {capitalize(seasonalityResult.dominantBefore)}
            {' → '}
            {getElementIcon(seasonalityResult.dominantAfter)} {capitalize(seasonalityResult.dominantAfter)}
          </p>
        </div>
      )}

      {/* ================================================================== */}
      {/* 8-CHART GRID: 2 columns × 4 rows                                  */}
      {/* Left = Raw/Unadjusted, Right = Adjusted/Seasonality-Weighted      */}
      {/* ================================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* Column Headers */}
        <div className={`text-center py-2 rounded-t-lg ${isDark ? 'bg-slate-700/50' : 'bg-slate-200'}`}>
          <h4 className={`font-semibold ${isDark ? 'text-white/80' : 'text-slate-700'}`}>
            📊 Raw Distribution (Before)
          </h4>
        </div>
        <div className={`text-center py-2 rounded-t-lg ${isDark ? 'bg-amber-500/20' : 'bg-amber-100'}`}>
          <h4 className={`font-semibold ${isDark ? 'text-amber-400' : 'text-amber-700'}`}>
            ✨ Seasonally Adjusted (After)
          </h4>
        </div>

        {/* Row 1: Donut Charts */}
        <ChartCard title="Proportional Distribution" isDark={isDark}>
          <div className="h-[220px]">
            <DonutChart distribution={rawPercentages} isRaw={true} isDark={isDark} />
          </div>
        </ChartCard>
        <ChartCard title="Proportional Distribution" isDark={isDark} highlight>
          <div className="h-[220px]">
            <DonutChart distribution={seasonalityResult.normalized} isRaw={false} isDark={isDark} />
          </div>
        </ChartCard>

        {/* Row 2: Horizontal Bar Charts */}
        <ChartCard title="Horizontal Comparison" isDark={isDark}>
          <div className="h-[200px]">
            <HorizontalBarChart distribution={rawPercentages} isRaw={true} isDark={isDark} />
          </div>
        </ChartCard>
        <ChartCard title="Horizontal Comparison" isDark={isDark} highlight>
          <div className="h-[200px]">
            <HorizontalBarChart
              distribution={seasonalityResult.normalized}
              rawDistribution={rawPercentages}
              weights={seasonalityResult.weights}
              isRaw={false}
              isDark={isDark}
            />
          </div>
        </ChartCard>

        {/* Row 3: Vertical Bar Charts */}
        <ChartCard title="Element Ranking" isDark={isDark}>
          <div className="h-[200px]">
            <VerticalBarChart distribution={rawPercentages} isRaw={true} isDark={isDark} />
          </div>
        </ChartCard>
        <ChartCard title="Element Ranking" isDark={isDark} highlight>
          <div className="h-[200px]">
            <VerticalBarChart distribution={seasonalityResult.normalized} isRaw={false} isDark={isDark} />
          </div>
        </ChartCard>

        {/* Row 4: Radar Charts - The Crown Jewel */}
        <ChartCard title="Elemental Fingerprint" isDark={isDark}>
          <div className="h-[280px]">
            <RadarChart distribution={rawPercentages} isRaw={true} isDark={isDark} />
          </div>
        </ChartCard>
        <ChartCard title="Super-Imposed Fingerprint" isDark={isDark} highlight>
          <div className="h-[280px]">
            <SuperImposedRadar
              rawDistribution={rawPercentages}
              adjustedDistribution={seasonalityResult.normalized}
              isDark={isDark}
            />
          </div>
          <div className="flex justify-center gap-6 mt-2 text-xs">
            <div className="flex items-center gap-2">
              <div className="w-3 h-0.5 bg-white/30"></div>
              <span className={isDark ? 'text-white/50' : 'text-slate-400'}>Raw (Faint)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-0.5 bg-amber-500"></div>
              <span className={isDark ? 'text-white/50' : 'text-slate-400'}>Adjusted (Bold)</span>
            </div>
          </div>
        </ChartCard>
      </div>

      {/* ================================================================== */}
      {/* SEASONAL WEIGHTS TABLE                                            */}
      {/* ================================================================== */}
      <div className={`p-4 rounded-xl ${isDark ? 'bg-slate-800/50 border-white/10' : 'bg-white border-slate-200'} border`}>
        <h4 className={`text-sm font-medium mb-3 flex items-center gap-2 ${isDark ? 'text-white/80' : 'text-slate-700'}`}>
          <span>⚖️</span>
          Seasonal Weight Multipliers ({monthBranch} Month - {seasonalityResult.seasonChinese})
        </h4>
        <div className="grid grid-cols-5 gap-2">
          {Object.entries(seasonalityResult.weights).map(([element, weight]) => (
            <div
              key={element}
              className="p-2 rounded-lg text-center transition-all hover:scale-105"
              style={{
                backgroundColor: `${ELEMENT_COLORS[element]}20`,
                borderColor: ELEMENT_COLORS[element],
                borderWidth: weight === 1.0 ? 2 : 1,
                borderStyle: 'solid'
              }}
            >
              <div className="text-lg">{getElementIcon(element)}</div>
              <div className={`text-xs mt-1 ${isDark ? 'text-white/60' : 'text-slate-500'}`}>
                {capitalize(element)}
              </div>
              <div
                className="font-mono font-bold mt-1"
                style={{ color: ELEMENT_COLORS[element] }}
              >
                ×{weight.toFixed(1)}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ================================================================== */}
      {/* IMPACT INDICATORS                                                 */}
      {/* ================================================================== */}
      <div className="grid grid-cols-2 gap-4">
        {/* Gainers */}
        <div className={`p-4 rounded-xl ${isDark ? 'bg-green-500/10 border-green-500/30' : 'bg-green-50 border-green-200'} border`}>
          <h4 className={`text-sm font-medium mb-2 flex items-center gap-2 ${isDark ? 'text-green-400' : 'text-green-700'}`}>
            <span>📈</span>
            Strengthened by Season
          </h4>
          {gainers.length > 0 ? (
            <div className="space-y-2">
              {gainers.map(({ element, change }) => (
                <div key={element} className="flex items-center justify-between">
                  <span className={`flex items-center gap-2 ${isDark ? 'text-white/80' : 'text-slate-700'}`}>
                    {getElementIcon(element)} {capitalize(element)}
                    <span className={isDark ? 'text-white/40' : 'text-slate-400'}>{ELEMENT_CHINESE[element]}</span>
                  </span>
                  <span className={`font-mono ${isDark ? 'text-green-400' : 'text-green-600'}`}>
                    +{change.toFixed(1)}%
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className={`text-sm ${isDark ? 'text-white/40' : 'text-slate-400'}`}>No significant gains</p>
          )}
        </div>

        {/* Losers */}
        <div className={`p-4 rounded-xl ${isDark ? 'bg-red-500/10 border-red-500/30' : 'bg-red-50 border-red-200'} border`}>
          <h4 className={`text-sm font-medium mb-2 flex items-center gap-2 ${isDark ? 'text-red-400' : 'text-red-700'}`}>
            <span>📉</span>
            Weakened by Season
          </h4>
          {losers.length > 0 ? (
            <div className="space-y-2">
              {losers.map(({ element, change }) => (
                <div key={element} className="flex items-center justify-between">
                  <span className={`flex items-center gap-2 ${isDark ? 'text-white/80' : 'text-slate-700'}`}>
                    {getElementIcon(element)} {capitalize(element)}
                    <span className={isDark ? 'text-white/40' : 'text-slate-400'}>{ELEMENT_CHINESE[element]}</span>
                  </span>
                  <span className={`font-mono ${isDark ? 'text-red-400' : 'text-red-600'}`}>
                    {change.toFixed(1)}%
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className={`text-sm ${isDark ? 'text-white/40' : 'text-slate-400'}`}>No significant weakening</p>
          )}
        </div>
      </div>

      {/* ================================================================== */}
      {/* EDUCATIONAL EXPLANATION                                           */}
      {/* ================================================================== */}
      {showExplanation && (
        <div className={`p-4 rounded-xl ${isDark ? 'bg-amber-500/10 border-amber-500/30' : 'bg-amber-50 border-amber-200'} border`}>
          <h4 className={`text-sm font-medium mb-2 flex items-center gap-2 ${isDark ? 'text-amber-400' : 'text-amber-700'}`}>
            <span>📚</span>
            What This Means
          </h4>
          <p className={`text-sm leading-relaxed ${isDark ? 'text-white/80' : 'text-slate-700'}`}>
            {seasonalityResult.explanation}
          </p>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// CHART CARD WRAPPER
// ============================================================================

function ChartCard({ title, children, isDark, highlight = false }) {
  return (
    <div className={`p-4 rounded-xl border ${
      highlight
        ? (isDark ? 'bg-amber-500/5 border-amber-500/20' : 'bg-amber-50/50 border-amber-200')
        : (isDark ? 'bg-slate-800/50 border-white/10' : 'bg-white border-slate-200')
    }`}>
      <h5 className={`text-xs uppercase tracking-wider mb-2 ${
        highlight
          ? (isDark ? 'text-amber-400/80' : 'text-amber-600')
          : (isDark ? 'text-white/50' : 'text-slate-400')
      }`}>
        {title}
      </h5>
      {children}
    </div>
  );
}

// ============================================================================
// DONUT CHART (Nivo Pie)
// ============================================================================

function DonutChart({ distribution, isRaw, isDark }) {
  const data = [
    { id: 'Wood', label: '木 Wood', value: distribution.wood, color: ELEMENT_COLORS.wood },
    { id: 'Fire', label: '火 Fire', value: distribution.fire, color: ELEMENT_COLORS.fire },
    { id: 'Earth', label: '土 Earth', value: distribution.earth, color: ELEMENT_COLORS.earth },
    { id: 'Metal', label: '金 Metal', value: distribution.metal, color: ELEMENT_COLORS.metal },
    { id: 'Water', label: '水 Water', value: distribution.water, color: ELEMENT_COLORS.water }
  ];

  return (
    <ResponsivePie
      data={data}
      margin={{ top: 20, right: 20, bottom: 20, left: 20 }}
      innerRadius={0.5}
      padAngle={1}
      cornerRadius={3}
      activeOuterRadiusOffset={8}
      colors={{ datum: 'data.color' }}
      borderWidth={1}
      borderColor={{ from: 'color', modifiers: [['darker', 0.2]] }}
      enableArcLinkLabels={false}
      arcLabelsSkipAngle={20}
      arcLabelsTextColor="#ffffff"
      arcLabel={d => `${d.value.toFixed(0)}%`}
      motionConfig="gentle"
      theme={{
        labels: {
          text: { fill: '#ffffff', fontSize: 11, fontWeight: 600 }
        },
        tooltip: {
          container: {
            background: isDark ? '#1e293b' : '#ffffff',
            color: isDark ? '#ffffff' : '#1e293b',
            borderRadius: 8,
            boxShadow: '0 4px 12px rgba(0,0,0,0.3)'
          }
        }
      }}
    />
  );
}

// ============================================================================
// HORIZONTAL BAR CHART
// ============================================================================

function HorizontalBarChart({ distribution, rawDistribution, weights, isRaw, isDark }) {
  const data = [
    { element: 'Water', value: distribution.water, color: ELEMENT_COLORS.water, raw: rawDistribution?.water, weight: weights?.water },
    { element: 'Metal', value: distribution.metal, color: ELEMENT_COLORS.metal, raw: rawDistribution?.metal, weight: weights?.metal },
    { element: 'Earth', value: distribution.earth, color: ELEMENT_COLORS.earth, raw: rawDistribution?.earth, weight: weights?.earth },
    { element: 'Fire', value: distribution.fire, color: ELEMENT_COLORS.fire, raw: rawDistribution?.fire, weight: weights?.fire },
    { element: 'Wood', value: distribution.wood, color: ELEMENT_COLORS.wood, raw: rawDistribution?.wood, weight: weights?.wood }
  ];

  return (
    <ResponsiveBar
      data={data}
      keys={['value']}
      indexBy="element"
      layout="horizontal"
      margin={{ top: 10, right: 50, bottom: 10, left: 60 }}
      padding={0.3}
      valueScale={{ type: 'linear', max: 50 }}
      colors={({ data }) => isRaw ? `${data.color}80` : data.color}
      borderRadius={4}
      axisTop={null}
      axisRight={null}
      axisBottom={null}
      axisLeft={{
        tickSize: 0,
        tickPadding: 8
      }}
      enableGridY={false}
      labelSkipWidth={12}
      labelTextColor="#ffffff"
      label={d => `${d.value.toFixed(1)}%`}
      tooltip={({ data }) => (
        <div className={`px-3 py-2 rounded-lg shadow-lg ${isDark ? 'bg-slate-800 text-white' : 'bg-white text-slate-800'}`}>
          <div className="font-semibold">{data.element}</div>
          {!isRaw && data.raw !== undefined && (
            <>
              <div className="text-xs opacity-70">Raw: {data.raw?.toFixed(1)}%</div>
              <div className="text-xs opacity-70">Weight: ×{data.weight?.toFixed(1)}</div>
              <div className="text-xs font-medium">Adjusted: {data.value.toFixed(1)}%</div>
            </>
          )}
          {isRaw && <div className="text-xs">Value: {data.value.toFixed(1)}%</div>}
        </div>
      )}
      theme={{
        axis: {
          ticks: {
            text: { fill: isDark ? 'rgba(255,255,255,0.6)' : 'rgba(0,0,0,0.6)', fontSize: 11 }
          }
        }
      }}
    />
  );
}

// ============================================================================
// VERTICAL BAR CHART
// ============================================================================

function VerticalBarChart({ distribution, isRaw, isDark }) {
  const data = [
    { element: 'Wood', value: distribution.wood, color: ELEMENT_COLORS.wood },
    { element: 'Fire', value: distribution.fire, color: ELEMENT_COLORS.fire },
    { element: 'Earth', value: distribution.earth, color: ELEMENT_COLORS.earth },
    { element: 'Metal', value: distribution.metal, color: ELEMENT_COLORS.metal },
    { element: 'Water', value: distribution.water, color: ELEMENT_COLORS.water }
  ];

  return (
    <ResponsiveBar
      data={data}
      keys={['value']}
      indexBy="element"
      layout="vertical"
      margin={{ top: 10, right: 10, bottom: 30, left: 40 }}
      padding={0.3}
      valueScale={{ type: 'linear', max: 50 }}
      colors={({ data }) => isRaw ? `${data.color}80` : data.color}
      borderRadius={4}
      axisTop={null}
      axisRight={null}
      axisBottom={{
        tickSize: 0,
        tickPadding: 5,
        tickRotation: 0
      }}
      axisLeft={{
        tickSize: 0,
        tickPadding: 5,
        tickValues: 5
      }}
      enableGridY={true}
      gridYValues={5}
      labelSkipHeight={12}
      labelTextColor="#ffffff"
      label={d => `${d.value.toFixed(0)}%`}
      theme={{
        axis: {
          ticks: {
            text: { fill: isDark ? 'rgba(255,255,255,0.6)' : 'rgba(0,0,0,0.6)', fontSize: 10 }
          }
        },
        grid: {
          line: { stroke: isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)' }
        }
      }}
    />
  );
}

// ============================================================================
// SINGLE RADAR CHART (Raw only)
// ============================================================================

function RadarChart({ distribution, isRaw, isDark }) {
  const data = [
    { element: 'Wood 木', value: distribution.wood },
    { element: 'Fire 火', value: distribution.fire },
    { element: 'Earth 土', value: distribution.earth },
    { element: 'Metal 金', value: distribution.metal },
    { element: 'Water 水', value: distribution.water }
  ];

  return (
    <ResponsiveRadar
      data={data}
      keys={['value']}
      indexBy="element"
      maxValue={50}
      margin={{ top: 40, right: 60, bottom: 40, left: 60 }}
      borderColor={{ from: 'color' }}
      gridLevels={5}
      gridShape="circular"
      gridLabelOffset={16}
      dotSize={8}
      dotColor={{ theme: 'background' }}
      dotBorderWidth={2}
      colors={[isRaw ? 'rgba(255,255,255,0.4)' : '#f59e0b']}
      fillOpacity={isRaw ? 0.15 : 0.3}
      motionConfig="gentle"
      theme={{
        axis: {
          ticks: {
            text: { fill: isDark ? 'rgba(255,255,255,0.6)' : 'rgba(0,0,0,0.6)', fontSize: 11 }
          }
        },
        grid: {
          line: { stroke: isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)' }
        }
      }}
    />
  );
}

// ============================================================================
// SUPER-IMPOSED RADAR (The Crown Jewel)
// ============================================================================

function SuperImposedRadar({ rawDistribution, adjustedDistribution, isDark }) {
  const data = [
    {
      element: 'Wood 木',
      raw: rawDistribution.wood,
      adjusted: adjustedDistribution.wood
    },
    {
      element: 'Fire 火',
      raw: rawDistribution.fire,
      adjusted: adjustedDistribution.fire
    },
    {
      element: 'Earth 土',
      raw: rawDistribution.earth,
      adjusted: adjustedDistribution.earth
    },
    {
      element: 'Metal 金',
      raw: rawDistribution.metal,
      adjusted: adjustedDistribution.metal
    },
    {
      element: 'Water 水',
      raw: rawDistribution.water,
      adjusted: adjustedDistribution.water
    }
  ];

  return (
    <ResponsiveRadar
      data={data}
      keys={['raw', 'adjusted']}
      indexBy="element"
      maxValue={50}
      margin={{ top: 40, right: 60, bottom: 40, left: 60 }}
      borderColor={{ from: 'color' }}
      gridLevels={5}
      gridShape="circular"
      gridLabelOffset={16}
      dotSize={8}
      dotColor={{ theme: 'background' }}
      dotBorderWidth={2}
      colors={['rgba(255,255,255,0.25)', '#f59e0b']}
      fillOpacity={0.2}
      blendMode="normal"
      motionConfig="gentle"
      legends={[]}
      theme={{
        axis: {
          ticks: {
            text: { fill: isDark ? 'rgba(255,255,255,0.6)' : 'rgba(0,0,0,0.6)', fontSize: 11 }
          }
        },
        grid: {
          line: { stroke: isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)' }
        }
      }}
    />
  );
}

// ============================================================================
// UTILITIES
// ============================================================================

function capitalize(str) {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// ============================================================================
// EXPORTS
// ============================================================================

export default SeasonalityComparisonChart;
