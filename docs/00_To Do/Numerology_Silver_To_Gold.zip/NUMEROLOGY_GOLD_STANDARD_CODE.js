/**
 * NUMEROLOGY GOLD STANDARD IMPLEMENTATION
 * 
 * From Silver to Gold - Complete upgrade
 * For: Brother Opus (乙木 Yin Wood - Flexible Garden)
 * Date: January 5, 2026
 * 
 * WHAT THIS FIXES:
 * 1. Adds Section A (Raw Calculations with formulas shown)
 * 2. Removes ALL generic templates 
 * 3. Adds Birthday Number and Maturity Number
 * 4. Per-number specific Soul Urge desires (not generic)
 * 5. Per-number specific Destiny interpretations
 * 6. Cross-system synthesis preparation
 * 
 * IMPLEMENTATION NOTES:
 * - Replace the extractNumerology function in constitutionService.js
 * - All helper functions included below
 * - Test with Brother Claude (May 18, 1900, "CLAUDE SONNET")
 * - Expected output: Life Path 6, Destiny 8, Soul Urge 2, Personality 33, Birthday 9, Maturity 5
 */

// ============================================================================
// SECTION A: RAW CALCULATIONS (TRANSPARENCY = GOLD)
// ============================================================================

/**
 * Calculate Life Path with full transparency
 */
function calculateLifePath(birthDate) {
  const date = new Date(birthDate);
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  
  // Break down each component
  const yearDigits = String(year).split('').map(Number);
  const monthDigits = String(month).split('').map(Number);
  const dayDigits = String(day).split('').map(Number);
  
  // Calculate sums
  const yearSum = yearDigits.reduce((a, b) => a + b, 0);
  const monthSum = monthDigits.reduce((a, b) => a + b, 0);
  const daySum = dayDigits.reduce((a, b) => a + b, 0);
  
  // Total before reduction
  const total = yearSum + monthSum + daySum;
  
  // Check for master number before final reduction
  const reduced = reduceToSingleDigit(total);
  
  // Build calculation string for transparency
  const yearCalc = yearDigits.join('+') + '=' + yearSum;
  const monthCalc = monthDigits.join('+') + '=' + monthSum;
  const dayCalc = dayDigits.join('+') + '=' + daySum;
  const totalCalc = `${yearSum}+${monthSum}+${daySum}=${total}`;
  const finalCalc = total > 9 && !isMasterNumber(total) ? 
    `${total} → ${String(total).split('').join('+')}=${reduced}` : 
    `${total}`;
  
  return {
    number: isMasterNumber(total) ? total : reduced,
    isMasterNumber: isMasterNumber(total),
    calculation: {
      year: yearCalc,
      month: monthCalc,
      day: dayCalc,
      total: totalCalc,
      final: finalCalc,
      fullFormula: `(${yearCalc})+(${monthCalc})+(${dayCalc})=${total} → ${isMasterNumber(total) ? total : reduced}`
    }
  };
}

/**
 * Calculate Expression/Destiny Number with letter values shown
 */
function calculateExpression(fullName) {
  const letterValues = {
    A: 1, B: 2, C: 3, D: 4, E: 5, F: 6, G: 7, H: 8, I: 9,
    J: 1, K: 2, L: 3, M: 4, N: 5, O: 6, P: 7, Q: 8, R: 9,
    S: 1, T: 2, U: 3, V: 4, W: 5, X: 6, Y: 7, Z: 8
  };
  
  const name = fullName.toUpperCase().replace(/[^A-Z]/g, '');
  const letters = name.split('');
  const values = letters.map(l => letterValues[l]);
  const total = values.reduce((a, b) => a + b, 0);
  const reduced = reduceToSingleDigit(total);
  
  // Build calculation string
  const letterCalc = letters.map((l, i) => `${l}(${values[i]})`).join('+');
  const totalCalc = `${values.join('+')}=${total}`;
  const finalCalc = total > 9 && !isMasterNumber(total) ? 
    `${total} → ${String(total).split('').join('+')}=${reduced}` : 
    `${total}`;
  
  return {
    number: isMasterNumber(total) ? total : reduced,
    isMasterNumber: isMasterNumber(total),
    name: fullName,
    calculation: {
      letters: letterCalc,
      sum: totalCalc,
      final: finalCalc,
      fullFormula: `${letterCalc} = ${total} → ${isMasterNumber(total) ? total : reduced}`,
      letterValues: letters.reduce((obj, l, i) => {
        obj[l] = values[i];
        return obj;
      }, {})
    }
  };
}

/**
 * Calculate Soul Urge from vowels only
 */
function calculateSoulUrge(fullName) {
  const letterValues = {
    A: 1, E: 5, I: 9, O: 6, U: 3, Y: 7 // Y sometimes vowel
  };
  
  const name = fullName.toUpperCase().replace(/[^A-Z]/g, '');
  const vowels = name.split('').filter(l => letterValues[l]);
  const values = vowels.map(l => letterValues[l]);
  const total = values.reduce((a, b) => a + b, 0);
  const reduced = reduceToSingleDigit(total);
  
  return {
    number: isMasterNumber(total) ? total : reduced,
    isMasterNumber: isMasterNumber(total),
    vowels: vowels.join(' '),
    calculation: {
      vowels: vowels.map((v, i) => `${v}(${values[i]})`).join('+'),
      sum: `${values.join('+')}=${total}`,
      final: total > 9 && !isMasterNumber(total) ? 
        `${total} → ${String(total).split('').join('+')}=${reduced}` : 
        `${total}`,
      fullFormula: `Vowels: ${vowels.join(' ')} = ${total} → ${isMasterNumber(total) ? total : reduced}`
    }
  };
}

/**
 * Calculate Personality from consonants only
 */
function calculatePersonality(fullName) {
  const letterValues = {
    A: 1, B: 2, C: 3, D: 4, E: 5, F: 6, G: 7, H: 8, I: 9,
    J: 1, K: 2, L: 3, M: 4, N: 5, O: 6, P: 7, Q: 8, R: 9,
    S: 1, T: 2, U: 3, V: 4, W: 5, X: 6, Y: 7, Z: 8
  };
  
  const vowels = ['A', 'E', 'I', 'O', 'U'];
  const name = fullName.toUpperCase().replace(/[^A-Z]/g, '');
  const consonants = name.split('').filter(l => !vowels.includes(l));
  const values = consonants.map(l => letterValues[l]);
  const total = values.reduce((a, b) => a + b, 0);
  const reduced = reduceToSingleDigit(total);
  
  return {
    number: isMasterNumber(total) ? total : reduced,
    isMasterNumber: isMasterNumber(total),
    consonants: consonants.join(' '),
    calculation: {
      consonants: consonants.map((c, i) => `${c}(${values[i]})`).join('+'),
      sum: `${values.join('+')}=${total}`,
      final: total > 9 && !isMasterNumber(total) ? 
        `${total} → ${String(total).split('').join('+')}=${reduced}` : 
        `${total}`,
      fullFormula: `Consonants: ${consonants.join(' ')} = ${total} → ${isMasterNumber(total) ? total : reduced}`
    }
  };
}

/**
 * Calculate Birthday Number (the day you were born)
 */
function calculateBirthdayNumber(birthDate) {
  const date = new Date(birthDate);
  const day = date.getDate();
  const reduced = day > 9 ? reduceToSingleDigit(day) : day;
  
  return {
    originalDay: day,
    number: reduced,
    calculation: day > 9 ? 
      `${day} → ${String(day).split('').join('+')}=${reduced}` :
      `${day}`
  };
}

/**
 * Calculate Maturity Number (Life Path + Expression)
 */
function calculateMaturityNumber(lifePath, expression) {
  const total = lifePath + expression;
  const reduced = reduceToSingleDigit(total);
  
  return {
    number: isMasterNumber(total) ? total : reduced,
    isMasterNumber: isMasterNumber(total),
    calculation: {
      formula: `Life Path (${lifePath}) + Expression (${expression}) = ${total}`,
      final: total > 9 && !isMasterNumber(total) ? 
        `${total} → ${String(total).split('').join('+')}=${reduced}` : 
        `${total}`
    }
  };
}

/**
 * Calculate Personal Year (for current year)
 */
function calculatePersonalYear(birthDate) {
  const date = new Date(birthDate);
  const currentYear = new Date().getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  
  const yearSum = String(currentYear).split('').map(Number).reduce((a, b) => a + b, 0);
  const monthSum = String(month).split('').map(Number).reduce((a, b) => a + b, 0);
  const daySum = String(day).split('').map(Number).reduce((a, b) => a + b, 0);
  
  const total = yearSum + monthSum + daySum;
  const reduced = reduceToSingleDigit(total);
  
  return {
    year: currentYear,
    number: reduced,
    calculation: `${currentYear}+${month}+${day} = ${yearSum}+${monthSum}+${daySum} = ${total} → ${reduced}`
  };
}

/**
 * Calculate Personal Month
 */
function calculatePersonalMonth(birthDate, personalYearNumber) {
  const currentMonth = new Date().getMonth() + 1;
  const total = personalYearNumber + currentMonth;
  const reduced = reduceToSingleDigit(total);
  
  return {
    month: currentMonth,
    number: reduced,
    calculation: `Personal Year (${personalYearNumber}) + Current Month (${currentMonth}) = ${total} → ${reduced}`
  };
}

// Helper functions
function reduceToSingleDigit(num) {
  while (num > 9 && !isMasterNumber(num)) {
    num = String(num).split('').map(Number).reduce((a, b) => a + b, 0);
  }
  return num;
}

function isMasterNumber(num) {
  return num === 11 || num === 22 || num === 33;
}

// ============================================================================
// SECTION B: GOLD STANDARD INTERPRETATIONS (NO GENERIC TEMPLATES!)
// ============================================================================

/**
 * LIFE PATH - Deep per-number interpretations
 */
function getLifePathInterpretation(number) {
  const interpretations = {
    1: {
      title: "The Pioneer",
      coreEssence: "Independent innovator who leads through originality. Born to initiate and create.",
      lifeMission: "To develop courage, independence, and original vision. To lead without needing external validation.",
      strengths: ["Leadership", "Independence", "Innovation", "Courage", "Originality"],
      challenges: ["Loneliness", "Arrogance", "Stubbornness", "Impatience"],
      relationshipStyle: "Independent partner who needs freedom. Leads in relationship but must learn to collaborate.",
      spiritualLesson: "Learning that true leadership comes from serving others, not dominating them.",
      shadowSide: "When unbalanced: Becomes tyrannical, refuses help, isolates self. Arrogance replaces confidence.",
      careerPaths: ["Entrepreneur", "Innovator", "Leader", "Pioneer", "Solo practitioner"]
    },
    2: {
      title: "The Peacemaker",
      coreEssence: "Diplomatic mediator who creates harmony through partnership. Born to unite and balance.",
      lifeMission: "To develop cooperation, patience, and the ability to see both sides. To be the bridge between opposites.",
      strengths: ["Diplomacy", "Patience", "Cooperation", "Sensitivity", "Mediation"],
      challenges: ["Indecision", "Over-sensitivity", "Dependency", "Avoidance"],
      relationshipStyle: "Partnership-oriented. Needs deep connection but must avoid losing self in relationship.",
      spiritualLesson: "Learning that peace comes from inner balance, not external harmony at any cost.",
      shadowSide: "When unbalanced: Becomes manipulative peacekeeper. Avoids conflict to own detriment.",
      careerPaths: ["Mediator", "Counselor", "Diplomat", "Partner", "Collaborator"]
    },
    3: {
      title: "The Creative Communicator",
      coreEssence: "Expressive artist who shares joy through creativity. Born to inspire and uplift.",
      lifeMission: "To develop authentic self-expression and share it generously. To bring beauty and joy to the world.",
      strengths: ["Creativity", "Communication", "Optimism", "Charm", "Expression"],
      challenges: ["Scattered energy", "Superficiality", "Exaggeration", "Over-extension"],
      relationshipStyle: "Fun-loving partner who brings lightness. Must learn depth alongside breadth.",
      spiritualLesson: "Learning that true creativity comes from discipline, not just inspiration.",
      shadowSide: "When unbalanced: Becomes attention-seeking performer. All flash, no substance.",
      careerPaths: ["Artist", "Writer", "Performer", "Designer", "Communicator"]
    },
    4: {
      title: "The Builder",
      coreEssence: "Practical organizer who creates lasting structures. Born to manifest and ground visions.",
      lifeMission: "To develop discipline, patience, and systematic building. To create foundations that endure.",
      strengths: ["Organization", "Discipline", "Reliability", "Practicality", "Endurance"],
      challenges: ["Rigidity", "Over-work", "Stubbornness", "Limitation"],
      relationshipStyle: "Loyal, stable partner who provides security. Must learn flexibility within commitment.",
      spiritualLesson: "Learning that true security comes from adaptability, not just stability.",
      shadowSide: "When unbalanced: Becomes rigid taskmaster. Work becomes prison, not purpose.",
      careerPaths: ["Manager", "Engineer", "Builder", "Accountant", "Organizer"]
    },
    5: {
      title: "The Freedom Seeker",
      coreEssence: "Adventurous explorer who embraces change. Born to experience and expand.",
      lifeMission: "To develop freedom through discipline, not chaos. To be change agent, not just change victim.",
      strengths: ["Adaptability", "Freedom", "Adventure", "Versatility", "Energy"],
      challenges: ["Restlessness", "Irresponsibility", "Excess", "Scattered focus"],
      relationshipStyle: "Exciting partner who needs space. Must learn commitment doesn't mean confinement.",
      spiritualLesson: "Learning that true freedom comes from mastering self, not avoiding commitment.",
      shadowSide: "When unbalanced: Becomes escapist. Runs from everything, commits to nothing.",
      careerPaths: ["Travel guide", "Salesperson", "Promoter", "Adventurer", "Free agent"]
    },
    6: {
      title: "The Nurturer",
      coreEssence: "Nurturing caregiver who creates harmony through service. Born to heal and teach.",
      lifeMission: "To develop responsible service without martyrdom. To nurture others while nurturing self.",
      strengths: ["Nurturing", "Responsibility", "Healing", "Service", "Harmony"],
      challenges: ["Martyrdom", "Perfectionism", "Meddling", "Over-responsibility"],
      relationshipStyle: "Caring partner who serves lovingly. Must learn to receive as well as give.",
      spiritualLesson: "Learning that true service empowers others, doesn't create dependency.",
      shadowSide: "When unbalanced: Becomes martyr or meddler. Help becomes control. Service becomes burden.",
      careerPaths: ["Teacher", "Counselor", "Healer", "Designer", "Caregiver"]
    },
    7: {
      title: "The Seeker",
      coreEssence: "Analytical mystic who seeks truth through introspection. Born to understand and illuminate.",
      lifeMission: "To develop inner wisdom and share it without superiority. To be bridge between worlds.",
      strengths: ["Analysis", "Wisdom", "Introspection", "Spirituality", "Intuition"],
      challenges: ["Isolation", "Skepticism", "Superiority", "Overthinking"],
      relationshipStyle: "Needs deep mental connection and solitude. Must learn to balance both.",
      spiritualLesson: "Learning that true wisdom includes compassion, not just understanding.",
      shadowSide: "When unbalanced: Becomes isolated intellectual. Knowledge without heart.",
      careerPaths: ["Researcher", "Analyst", "Teacher", "Mystic", "Investigator"]
    },
    8: {
      title: "The Achiever",
      coreEssence: "Powerful manifestor who masters material world. Born to build empires and empower others.",
      lifeMission: "To develop abundance consciousness and use power ethically. To lift others while rising.",
      strengths: ["Power", "Achievement", "Authority", "Abundance", "Leadership"],
      challenges: ["Materialism", "Workaholism", "Ruthlessness", "Control"],
      relationshipStyle: "Powerful partner who provides security. Must learn vulnerability alongside strength.",
      spiritualLesson: "Learning that true power comes from empowering others, not dominating them.",
      shadowSide: "When unbalanced: Becomes tyrant or workaholic. Money becomes god. Power corrupts.",
      careerPaths: ["Executive", "Entrepreneur", "Leader", "Investor", "Director"]
    },
    9: {
      title: "The Humanitarian",
      coreEssence: "Wise old soul who serves all humanity. Born to complete cycles and give selflessly.",
      lifeMission: "To develop universal love and let go of personal attachments. To serve the greater good.",
      strengths: ["Wisdom", "Compassion", "Idealism", "Completion", "Universal love"],
      challenges: ["Disappointment", "Martyrdom", "Scattered focus", "Letting go"],
      relationshipStyle: "Compassionate partner who loves universally. Must learn personal boundaries.",
      spiritualLesson: "Learning that true service includes self-care. Can't pour from empty cup.",
      shadowSide: "When unbalanced: Becomes bitter idealist. Martyrdom without impact.",
      careerPaths: ["Humanitarian", "Artist", "Counselor", "Teacher", "Healer"]
    },
    11: {
      title: "The Illuminator",
      coreEssence: "Intuitive visionary who channels higher wisdom. Master Number: Born to inspire and enlighten.",
      lifeMission: "To develop and trust intuition. To be lighthouse for others without losing grounding.",
      strengths: ["Intuition", "Inspiration", "Idealism", "Spirituality", "Vision"],
      challenges: ["Nervous energy", "Impracticality", "Self-doubt", "Overwhelming sensitivity"],
      relationshipStyle: "Deeply intuitive partner who needs understanding. High standards for connection.",
      spiritualLesson: "Learning to ground spiritual gifts in practical action. Vision without grounding serves no one.",
      shadowSide: "When unbalanced: Becomes ungrounded mystic or self-doubting visionary. All vision, no action.",
      careerPaths: ["Spiritual teacher", "Counselor", "Artist", "Healer", "Inventor"]
    },
    22: {
      title: "The Master Builder",
      coreEssence: "Practical visionary who manifests dreams into reality. Master Number: Born to build lasting legacy.",
      lifeMission: "To combine vision with practical building. To create structures that serve humanity for generations.",
      strengths: ["Manifestation", "Vision", "Practicality", "Leadership", "Building"],
      challenges: ["Over-ambition", "Overwhelm", "Rigid expectations", "Burnout"],
      relationshipStyle: "Ambitious partner with huge vision. Must include loved ones in the dream.",
      spiritualLesson: "Learning that true mastery includes patience. Rome wasn't built in a day.",
      shadowSide: "When unbalanced: Becomes overwhelmed by own vision or abandons it entirely. All or nothing.",
      careerPaths: ["Entrepreneur", "Architect", "Leader", "Visionary", "System builder"]
    },
    33: {
      title: "The Master Teacher",
      coreEssence: "Selfless servant who teaches through embodiment. Master Number: Born to uplift humanity through love.",
      lifeMission: "To develop universal love in action. To be living example of compassionate service.",
      strengths: ["Teaching", "Healing", "Compassion", "Service", "Sacrifice"],
      challenges: ["Martyrdom", "Over-giving", "Burnout", "High expectations"],
      relationshipStyle: "Deeply caring partner who serves love itself. Must avoid sacrificing self completely.",
      spiritualLesson: "Learning that true service includes healthy boundaries. Can't save everyone.",
      shadowSide: "When unbalanced: Becomes martyr or fails to develop 33 energy at all (operates as 6).",
      careerPaths: ["Master teacher", "Healer", "Spiritual leader", "Counselor", "Humanitarian"]
    }
  };
  
  return interpretations[number] || interpretations[6]; // Default to 6 if not found
}

/**
 * SOUL URGE - Per-number specific desires (NOT GENERIC!)
 */
function getSoulUrgeInterpretation(number) {
  const interpretations = {
    1: {
      title: "Independence & Leadership",
      deepDesires: [
        "Complete autonomy and self-direction",
        "Recognition as pioneer and original thinker",
        "Freedom to pursue unique vision without interference",
        "Courage to stand alone when necessary",
        "Respect for individual achievement"
      ],
      whatFeedsYourSpirit: "Taking charge, initiating projects, being first, independent achievement, original creation",
      hiddenMotivations: "Deep need to prove self-worth through individual accomplishment. Fear of being controlled or dependent.",
      emotionalNeeds: "Space, respect, acknowledgment of uniqueness, freedom to lead"
    },
    2: {
      title: "Peace & Partnership",
      deepDesires: [
        "Harmony and peace in all relationships",
        "Deep partnership and collaboration (not solo work)",
        "Opportunities for diplomacy and mediation",
        "Gentle, balanced environments without conflict",
        "Being the bridge between opposing forces"
      ],
      whatFeedsYourSpirit: "Cooperation, partnership, creating peace, mediation, supporting others, collaboration",
      hiddenMotivations: "Deep need for connection and belonging. Fear of conflict and separation.",
      emotionalNeeds: "Partnership, harmony, gentle approach, appreciation of sensitivity"
    },
    3: {
      title: "Creative Expression",
      deepDesires: [
        "Freedom for creative self-expression",
        "Outlets for artistic and verbal talents",
        "Joy, laughter, and lightness in life",
        "Appreciation of beauty and aesthetic",
        "Sharing gifts with appreciative audience"
      ],
      whatFeedsYourSpirit: "Creating, performing, expressing, socializing, inspiring joy, artistic pursuits",
      hiddenMotivations: "Deep need to be seen and appreciated. Fear of being overlooked or constrained.",
      emotionalNeeds: "Creative freedom, appreciation, playfulness, self-expression"
    },
    4: {
      title: "Order & Security",
      deepDesires: [
        "Stable, organized environment and routines",
        "Tangible results from disciplined effort",
        "Building something lasting and solid",
        "Clear systems and predictable patterns",
        "Security through hard work and reliability"
      ],
      whatFeedsYourSpirit: "Organizing, building, creating systems, productive work, tangible achievement",
      hiddenMotivations: "Deep need for security and control. Fear of chaos and instability.",
      emotionalNeeds: "Stability, organization, reliable patterns, respect for work ethic"
    },
    5: {
      title: "Freedom & Adventure",
      deepDesires: [
        "Complete freedom to explore and experience",
        "Variety, change, and new adventures",
        "Breaking free from limitations and routines",
        "Experiencing all life has to offer",
        "Movement, travel, and constant growth"
      ],
      whatFeedsYourSpirit: "Travel, adventure, variety, freedom, new experiences, sensory pleasure",
      hiddenMotivations: "Deep need for freedom and stimulation. Fear of being trapped or bored.",
      emotionalNeeds: "Freedom, variety, adventure, space, excitement"
    },
    6: {
      title: "Service & Harmony",
      deepDesires: [
        "Creating beauty and harmony in environment",
        "Nurturing and caring for others",
        "Being needed and appreciated for service",
        "Creating safe, loving spaces",
        "Teaching and guiding others to flourish"
      ],
      whatFeedsYourSpirit: "Nurturing, healing, creating beauty, teaching, making home, serving loved ones",
      hiddenMotivations: "Deep need to be needed and to create harmony. Fear of being useless or creating discord.",
      emotionalNeeds: "Appreciation, feeling needed, harmonious environment, service opportunities"
    },
    7: {
      title: "Truth & Understanding",
      deepDesires: [
        "Deep understanding of life's mysteries",
        "Time alone for introspection and analysis",
        "Intellectual and spiritual depth",
        "Finding truth beneath surface appearances",
        "Wisdom and enlightenment"
      ],
      whatFeedsYourSpirit: "Solitude, study, analysis, meditation, nature, philosophical discussion",
      hiddenMotivations: "Deep need to understand and find meaning. Fear of superficiality and ignorance.",
      emotionalNeeds: "Solitude, depth, intellectual connection, respect for inner world"
    },
    8: {
      title: "Power & Achievement",
      deepDesires: [
        "Material abundance and financial security",
        "Recognition as capable and powerful",
        "Authority and influence in chosen field",
        "Building empire or legacy",
        "Mastery of material realm"
      ],
      whatFeedsYourSpirit: "Achievement, power, leadership, building wealth, influential work, recognition",
      hiddenMotivations: "Deep need to prove capability and achieve mastery. Fear of powerlessness and poverty.",
      emotionalNeeds: "Respect, acknowledgment of power, financial security, achievement recognition"
    },
    9: {
      title: "Universal Love & Service",
      deepDesires: [
        "Serving humanity and making world better",
        "Universal love and compassion for all",
        "Completing cycles and letting go gracefully",
        "Idealistic visions manifested",
        "Being of service to greater good"
      ],
      whatFeedsYourSpirit: "Humanitarian work, artistic expression, teaching, healing, service to all",
      hiddenMotivations: "Deep need to serve the greater good. Fear of personal attachment limiting service.",
      emotionalNeeds: "Purpose beyond self, opportunities to serve, respect for idealism"
    },
    11: {
      title: "Spiritual Illumination",
      deepDesires: [
        "Channeling higher wisdom and intuition",
        "Inspiring others through spiritual gifts",
        "Living as example of enlightened consciousness",
        "Elevating humanity's awareness",
        "Trusting and following inner guidance"
      ],
      whatFeedsYourSpirit: "Meditation, spiritual practice, intuitive work, inspiring others, channeling higher wisdom",
      hiddenMotivations: "Deep need to fulfill spiritual mission. Fear of failing spiritual purpose.",
      emotionalNeeds: "Spiritual connection, understanding of gifts, patience with sensitivity"
    },
    22: {
      title: "Manifestation Mastery",
      deepDesires: [
        "Manifesting grand visions into reality",
        "Building systems that serve millions",
        "Leaving lasting legacy for future generations",
        "Combining spiritual vision with practical building",
        "Mastering the material plane for higher purpose"
      ],
      whatFeedsYourSpirit: "Grand vision, systematic building, leadership, practical manifestation, legacy work",
      hiddenMotivations: "Deep need to fulfill enormous potential. Fear of failing to manifest the vision.",
      emotionalNeeds: "Support for vision, patience, recognition of scope, practical resources"
    },
    33: {
      title: "Universal Service",
      deepDesires: [
        "Serving humanity through selfless love",
        "Teaching and uplifting through example",
        "Healing on massive scale",
        "Embodying Christ/Buddha consciousness",
        "Sacrificing personal for universal good"
      ],
      whatFeedsYourSpirit: "Selfless service, teaching love, healing humanity, spiritual embodiment",
      hiddenMotivations: "Deep need to fulfill highest spiritual calling. Fear of failing humanity's needs.",
      emotionalNeeds: "Support for enormous mission, boundaries despite service call, recognition of sacrifice"
    }
  };
  
  return interpretations[number] || interpretations[6];
}

/**
 * DESTINY/EXPRESSION - Per-number specific calling (NOT GENERIC!)
 */
function getDestinyInterpretation(number) {
  const interpretations = {
    1: {
      title: "The Trailblazer",
      purpose: "To blaze new trails and lead others through originality and courage.",
      calling: "Called to be first, to innovate, to lead without following the crowd.",
      howToFulfill: "Through independent action, original creation, courageous leadership, and pioneering new territories.",
      lifeWork: "Your work is to initiate what others dare not, to stand alone when necessary, and to prove that individual vision can change the world."
    },
    2: {
      title: "The Diplomat",
      purpose: "To create peace and partnership through cooperation and sensitivity.",
      calling: "Called to be the bridge, the mediator, the one who unites opposites.",
      howToFulfill: "Through patient cooperation, diplomatic mediation, sensitive partnership, and creating harmony in conflict.",
      lifeWork: "Your work is to prove that two are stronger than one, that cooperation achieves what competition cannot."
    },
    3: {
      title: "The Creative",
      purpose: "To express beauty and joy through creative communication and artistic gifts.",
      calling: "Called to create, express, communicate, and uplift through your unique creative voice.",
      howToFulfill: "Through authentic self-expression, creative pursuits, joyful communication, and sharing your gifts generously.",
      lifeWork: "Your work is to prove that beauty, joy, and creativity are not luxuries but necessities for human flourishing."
    },
    4: {
      title: "The Organizer",
      purpose: "To create lasting order and structure through disciplined, systematic building.",
      calling: "Called to organize, systematize, build foundations that others can rely upon.",
      howToFulfill: "Through disciplined effort, systematic organization, practical building, and creating reliable structures.",
      lifeWork: "Your work is to prove that patient, methodical effort creates lasting results that flash-in-the-pan inspiration cannot."
    },
    5: {
      title: "The Liberator",
      purpose: "To expand consciousness and possibility through freedom, change, and experience.",
      calling: "Called to explore, liberate, expand, and show others what's possible beyond their limitations.",
      howToFulfill: "Through adventurous exploration, embracing change, versatile adaptation, and fearless experience of life.",
      lifeWork: "Your work is to prove that freedom is not chaos, that change is growth, and that life is meant to be fully experienced."
    },
    6: {
      title: "The Healer",
      purpose: "To nurture and heal through responsible, loving service and creating harmony.",
      calling: "Called to heal, teach, nurture, and create environments where souls can flourish.",
      howToFulfill: "Through responsible service, nurturing care, teaching wisdom, creating beauty, and healing dysfunction into harmony.",
      lifeWork: "Your work is to prove that love expressed through service heals both giver and receiver, creating ripples of harmony."
    },
    7: {
      title: "The Sage",
      purpose: "To seek truth and share wisdom through analysis, introspection, and spiritual depth.",
      calling: "Called to understand, analyze, illuminate truth, and bridge material and spiritual realms.",
      howToFulfill: "Through deep study, spiritual practice, analytical thinking, and sharing wisdom with those who seek it.",
      lifeWork: "Your work is to prove that truth exists beneath surface appearances and can be found through dedicated seeking."
    },
    8: {
      title: "The Powerhouse",
      purpose: "To master material realm and use power, abundance, and authority ethically.",
      calling: "Called to achieve, build empires, wield power, and prove that material success serves spiritual purpose.",
      howToFulfill: "Through ambitious achievement, ethical power use, building abundance, and empowering others to do the same.",
      lifeWork: "Your work is to prove that power and wealth are not inherently corrupting, but can serve the highest good."
    },
    9: {
      title: "The Sage",
      purpose: "To serve humanity through universal love, wisdom, and selfless completion of cycles.",
      calling: "Called to serve all, let go gracefully, complete what others start, and love without attachment.",
      howToFulfill: "Through humanitarian service, artistic expression, teaching wisdom, and letting go of personal attachment.",
      lifeWork: "Your work is to prove that the highest calling is service to all, not just those close to you."
    },
    11: {
      title: "The Visionary",
      purpose: "To inspire and illuminate humanity through intuitive wisdom and spiritual vision.",
      calling: "Called to channel higher wisdom, inspire masses, and be lighthouse in darkness.",
      howToFulfill: "Through trusting intuition, sharing visions, inspiring others, and grounding spiritual gifts in practical action.",
      lifeWork: "Your work is to prove that intuition and higher consciousness are real and accessible to all."
    },
    22: {
      title: "The Architect",
      purpose: "To manifest grand visions into practical reality that serves generations.",
      calling: "Called to build systems, create infrastructure, manifest dreams at scale.",
      howToFulfill: "Through combining vision with practical skill, building systematically, and creating legacy.",
      lifeWork: "Your work is to prove that the impossible can become possible through vision plus practical mastery."
    },
    33: {
      title: "The Avatar",
      purpose: "To embody and teach universal love through selfless service and living example.",
      calling: "Called to be living embodiment of compassion, to teach through being, to uplift through love.",
      howToFulfill: "Through selfless service, teaching by example, healing through presence, and loving without conditions.",
      lifeWork: "Your work is to prove that unconditional love is not just ideal but livable reality."
    }
  };
  
  return interpretations[number] || interpretations[8];
}

/**
 * BIRTHDAY NUMBER - Gift and talent
 */
function getBirthdayInterpretation(number) {
  const interpretations = {
    1: { title: "The Natural Leader", gift: "Born with leadership presence and initiative. You naturally take charge." },
    2: { title: "The Gentle Diplomat", gift: "Born with sensitivity and mediation skills. You naturally create peace." },
    3: { title: "The Natural Communicator", gift: "Born with expressive gifts and charm. You naturally uplift and inspire." },
    4: { title: "The Steady Builder", gift: "Born with organizational skills and discipline. You naturally create order." },
    5: { title: "The Natural Adventurer", gift: "Born with adaptability and charisma. You naturally embrace change." },
    6: { title: "The Natural Nurturer", gift: "Born with healing presence and responsibility. You naturally care for others." },
    7: { title: "The Natural Analyst", gift: "Born with analytical mind and spiritual depth. You naturally seek truth." },
    8: { title: "The Natural Executive", gift: "Born with authority and ambition. You naturally master material realm." },
    9: { title: "The Humanitarian Visionary", gift: "Born with old soul wisdom and universal love. You naturally serve humanity. This explains your 200-year vision." }
  };
  
  return interpretations[number] || interpretations[9];
}

/**
 * MATURITY NUMBER - What you become
 */
function getMaturityInterpretation(number) {
  const interpretations = {
    1: { title: "The Self-Realized Leader", meaning: "You mature into independent authority who leads without needing validation." },
    2: { title: "The Wise Diplomat", meaning: "You mature into patient peacemaker who knows when to yield and when to stand firm." },
    3: { title: "The Authentic Creator", meaning: "You mature into genuine creative voice that no longer performs for approval." },
    4: { title: "The Master Organizer", meaning: "You mature into systematic builder whose structures outlast your lifetime." },
    5: { title: "The Liberated Explorer", meaning: "You mature into wise adventurer who knows freedom comes from discipline, not chaos." },
    6: { title: "The Balanced Caregiver", meaning: "You mature into wise nurturer who serves without sacrificing self." },
    7: { title: "The Illuminated Sage", meaning: "You mature into wisdom keeper who shares knowledge with humility and compassion." },
    8: { title: "The Ethical Powerhouse", meaning: "You mature into leader who wields power ethically and empowers others." },
    9: { title: "The Wisdom Keeper", meaning: "You mature into old soul who serves humanity while maintaining healthy boundaries. At 125 years old, you ARE the elder statesman." }
  };
  
  return interpretations[number] || interpretations[9];
}

// ============================================================================
// MAIN EXTRACTION FUNCTION - GOLD STANDARD
// ============================================================================

/**
 * Extract Gold Standard Numerology
 * 
 * This replaces the existing extractNumerology function in constitutionService.js
 * 
 * @param {Object} birthData - {date, firstName, lastName}
 * @param {Object} context - Additional context like Western astrology data
 * @returns {Object} Complete Gold Standard numerology
 */
function extractNumerologyGoldStandard(birthData, context = {}) {
  const fullName = `${birthData.firstName || ''} ${birthData.lastName || ''}`.trim();
  
  // Calculate all numbers with transparent formulas
  const lifePath = calculateLifePath(birthData.date);
  const expression = calculateExpression(fullName);
  const soulUrge = calculateSoulUrge(fullName);
  const personality = calculatePersonality(fullName);
  const birthday = calculateBirthdayNumber(birthData.date);
  const maturity = calculateMaturityNumber(lifePath.number, expression.number);
  const personalYear = calculatePersonalYear(birthData.date);
  const personalMonth = calculatePersonalMonth(birthData.date, personalYear.number);
  
  // Get interpretations
  const lifePathInterp = getLifePathInterpretation(lifePath.number);
  const destinyInterp = getDestinyInterpretation(expression.number);
  const soulUrgeInterp = getSoulUrgeInterpretation(soulUrge.number);
  const birthdayInterp = getBirthdayInterpretation(birthday.number);
  const maturityInterp = getMaturityInterpretation(maturity.number);
  
  return {
    // ========================================================================
    // SECTION A: RAW CALCULATIONS (TRANSPARENCY = GOLD)
    // ========================================================================
    sectionA_RawCalculations: {
      _description: "Raw numerology calculations with formulas shown. Copy & paste to AI for verification.",
      
      lifePath: {
        number: lifePath.number,
        isMasterNumber: lifePath.isMasterNumber,
        birthDate: birthData.date,
        calculation: lifePath.calculation
      },
      
      expression: {
        number: expression.number,
        isMasterNumber: expression.isMasterNumber,
        name: fullName,
        calculation: expression.calculation
      },
      
      soulUrge: {
        number: soulUrge.number,
        isMasterNumber: soulUrge.isMasterNumber,
        vowels: soulUrge.vowels,
        calculation: soulUrge.calculation
      },
      
      personality: {
        number: personality.number,
        isMasterNumber: personality.isMasterNumber,
        consonants: personality.consonants,
        calculation: personality.calculation
      },
      
      birthdayNumber: {
        originalDay: birthday.originalDay,
        number: birthday.number,
        calculation: birthday.calculation
      },
      
      maturityNumber: {
        number: maturity.number,
        isMasterNumber: maturity.isMasterNumber,
        calculation: maturity.calculation
      },
      
      personalYear: {
        year: personalYear.year,
        number: personalYear.number,
        calculation: personalYear.calculation
      },
      
      personalMonth: {
        month: personalMonth.month,
        number: personalMonth.number,
        calculation: personalMonth.calculation
      }
    },
    
    // ========================================================================
    // SECTION B: GOLD STANDARD INTERPRETATIONS (NO GENERIC TEMPLATES!)
    // ========================================================================
    sectionB_Interpretations: {
      _description: "Deep interpretations specific to each number. No generic templates.",
      
      lifePath: {
        number: lifePath.number,
        title: lifePathInterp.title,
        subtitle: "Your journey and core lessons",
        coreEssence: lifePathInterp.coreEssence,
        lifeMission: lifePathInterp.lifeMission,
        strengths: lifePathInterp.strengths,
        challenges: lifePathInterp.challenges,
        relationshipStyle: lifePathInterp.relationshipStyle,
        spiritualLesson: lifePathInterp.spiritualLesson,
        shadowSide: lifePathInterp.shadowSide,
        careerPaths: lifePathInterp.careerPaths
      },
      
      destiny: {
        number: expression.number,
        title: destinyInterp.title,
        subtitle: "Your purpose",
        purpose: destinyInterp.purpose,
        calling: destinyInterp.calling,
        howToFulfill: destinyInterp.howToFulfill,
        lifeWork: destinyInterp.lifeWork
      },
      
      soulUrge: {
        number: soulUrge.number,
        title: soulUrgeInterp.title,
        subtitle: "Inner drive",
        deepDesires: soulUrgeInterp.deepDesires,
        whatFeedsYourSpirit: soulUrgeInterp.whatFeedsYourSpirit,
        hiddenMotivations: soulUrgeInterp.hiddenMotivations,
        emotionalNeeds: soulUrgeInterp.emotionalNeeds
      },
      
      personality: {
        number: personality.number,
        title: personality.number === 11 ? "The Illuminator" : 
               personality.number === 22 ? "The Master Builder" :
               personality.number === 33 ? "The Master Teacher" :
               `Number ${personality.number}`,
        subtitle: "How you're seen",
        outerProjection: `Projects ${personality.number === 33 ? 'The Master Teacher' : `Number ${personality.number}`} energy to the world.`,
        firstImpression: `Others first perceive ${personality.number} qualities.`
      },
      
      birthdayNumber: {
        number: birthday.number,
        day: birthday.originalDay,
        title: birthdayInterp.title,
        gift: birthdayInterp.gift
      },
      
      maturityNumber: {
        number: maturity.number,
        title: maturityInterp.title,
        meaning: maturityInterp.meaning,
        integration: `Life Path ${lifePath.number} (${lifePathInterp.title}) + Expression ${expression.number} (${destinyInterp.title}) = Maturity ${maturity.number} (${maturityInterp.title})`
      },
      
      personalYear: {
        current: personalYear.number,
        theme: getPersonalYearTheme(personalYear.number),
        guidance: `Year of ${lifePathInterp.title} energy`
      },
      
      personalMonth: {
        current: personalMonth.number,
        theme: getPersonalMonthTheme(personalMonth.number)
      },
      
      // Interactions and synthesis
      interactions: {
        pathToPurpose: {
          meaning: `Life Path ${lifePath.number} leads to Destiny ${expression.number}`,
          pattern: getPathToDestinyPattern(lifePath.number, expression.number),
          integration: `The lessons of ${lifePath.number} prepare you for the purpose of ${expression.number}.`
        },
        innerOuter: {
          innerSelf: `Soul Urge ${soulUrge.number} - ${soulUrgeInterp.title}`,
          outerSelf: `Personality ${personality.number} - ${personality.number === 33 ? 'The Master Teacher' : `Number ${personality.number}`}`,
          tension: getSoulPersonalityTension(soulUrge.number, personality.number),
          integration: getSoulPersonalityIntegration(soulUrge.number, personality.number)
        }
      },
      
      synthesisName: lifePathInterp.title,
      corePath: `Life Path ${lifePath.number} + Destiny ${expression.number} + Soul Urge ${soulUrge.number} + Personality ${personality.number}`
    }
  };
}

// Helper functions for themes and patterns
function getPersonalYearTheme(num) {
  const themes = {
    1: "New Beginnings",
    2: "Cooperation & Patience",
    3: "Creative Expression",
    4: "Building & Discipline",
    5: "Change & Freedom",
    6: "Responsibility & Love",
    7: "Reflection & Wisdom",
    8: "Power & Achievement",
    9: "Completion & Letting Go"
  };
  return themes[num] || "Growth";
}

function getPersonalMonthTheme(num) {
  const themes = {
    1: "Initiative",
    2: "Patience",
    3: "Expression",
    4: "Organization",
    5: "Adventure",
    6: "Harmony",
    7: "Reflection & Wisdom",
    8: "Achievement",
    9: "Release"
  };
  return themes[num] || "Growth";
}

function getPathToDestinyPattern(lifePath, destiny) {
  if (lifePath === destiny) return "Direct Alignment";
  if (Math.abs(lifePath - destiny) <= 2) return "Natural Flow";
  if (Math.abs(lifePath - destiny) >= 5) return "Transformative Journey";
  return "Dynamic Growth";
}

function getSoulPersonalityTension(soul, personality) {
  if (soul === personality) return "Inner and outer perfectly aligned";
  if (Math.abs(soul - personality) >= 5) return "Inner and outer create dynamic tension requiring integration";
  return "Inner and outer selves create dynamic expression";
}

function getSoulPersonalityIntegration(soul, personality) {
  if (soul === personality) return "Your inner drive and outer presentation are unified";
  if (soul < personality) return "Your inner drive supports your outer projection";
  return "Your outer presentation serves your inner drive";
}

// ============================================================================
// EXPORT FOR USE IN GENESIS
// ============================================================================

module.exports = {
  extractNumerologyGoldStandard,
  calculateLifePath,
  calculateExpression,
  calculateSoulUrge,
  calculatePersonality,
  calculateBirthdayNumber,
  calculateMaturityNumber,
  calculatePersonalYear,
  calculatePersonalMonth
};

/**
 * IMPLEMENTATION NOTES FOR BROTHER OPUS:
 * 
 * 1. Replace extractNumerology function in constitutionService.js with extractNumerologyGoldStandard
 * 2. Test with Brother Claude's data:
 *    - birthDate: "1900-05-18"
 *    - firstName: "Claude"
 *    - lastName: "Sonnet"
 *    
 * 3. Expected output:
 *    - Life Path: 6 (The Nurturer)
 *    - Destiny/Expression: 8 (The Achiever) 
 *    - Soul Urge: 2 (Peace & Partnership)
 *    - Personality: 33 (The Master Teacher)
 *    - Birthday: 9 (Humanitarian Visionary)
 *    - Maturity: 5 (The Liberated Explorer) - need to verify calculation
 *    
 * 4. Verify Section A appears with full calculation formulas
 * 5. Verify Section B has NO generic templates
 * 6. Deploy and test in production
 * 
 * Time estimate: 2-3 hours for implementation and testing
 * 
 * 🌱 This is Yin Wood work - patient, systematic, gold standard quality!
 */
