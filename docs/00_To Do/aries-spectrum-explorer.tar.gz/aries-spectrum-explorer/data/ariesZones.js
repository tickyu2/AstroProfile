// Aries Zone Database
// Complete data structure for all 6 zones across the 30° Aries spectrum

export const ariesZones = [
  {
    id: 1,
    name: "The Pisces-Aries Cusp",
    archetype: "The Mystic Warrior",
    degreeRange: {
      start: 0,
      end: 4.99,
      absoluteStart: 0,
      absoluteEnd: 4.99
    },
    dateRange: {
      start: "March 20",
      end: "March 24",
      duration: "~5 days"
    },
    decan: {
      number: 1,
      name: "First Decan (Cardinal)",
      primaryRuler: "Mars",
      subRuler: "Mars",
      modality: "Cardinal"
    },
    influences: [
      {
        source: "Pisces",
        type: "Cusp Bleed",
        planet: "Neptune",
        percentage: 25,
        traits: ["Intuition", "Compassion", "Dreaminess", "Spiritual awareness", "Emotional depth"]
      },
      {
        source: "Aries",
        type: "Core",
        planet: "Mars",
        percentage: 75,
        traits: ["Courage", "Initiative", "Independence", "Directness", "Competitive drive"]
      }
    ],
    qualities: {
      speed: { level: 80, label: "Fast", icon: "⚡⚡⚡⚡" },
      stubbornness: { level: 60, label: "Medium-High", icon: "🐏🐏🐏" },
      riskTolerance: { level: 80, label: "High", icon: "⚖️⚖️⚖️⚖️" },
      physicalEnergy: { level: 90, label: "Very High", icon: "⚡⚡⚡⚡⚡" },
      changeTolerance: { level: 70, label: "High", icon: "🔄🔄🔄🔄" },
      aggression: { level: 60, label: "Medium-High", icon: "⚔️⚔️⚔️" },
      independence: { level: 80, label: "High", icon: "🦅🦅🦅🦅" },
      patience: { level: 30, label: "Low", icon: "⏳⏳" }
    },
    strengths: [
      "Spiritual warrior: Fights for higher ideals with compassion",
      "Intuitive action: Combines instinct with decisive movement",
      "Pioneering vision: Sees possibilities others miss",
      "Empathetic courage: Brave defender of the vulnerable"
    ],
    shadows: [
      "Confused initiative: Unclear boundaries between self and others",
      "Escapist aggression: Fights to avoid dealing with emotions",
      "Martyrdom complex: Sacrifices self without boundaries",
      "Impulsive sensitivity: Reacts emotionally before thinking"
    ],
    careerSignatures: [
      "Spiritual Leadership",
      "Healing Professions with Action",
      "Creative Arts (Dance, Music)",
      "Humanitarian Work",
      "Counseling with Advocacy"
    ],
    relationshipStyle: {
      pursuit: "Romantic and passionate - leads with heart",
      commitmentSpeed: "Fast but emotionally deep",
      passion: "Intense emotional + physical connection",
      conflict: "Avoidant initially, then explosive",
      jealousy: "Deep but hidden - suffers in silence"
    },
    famousExamples: [
      {
        name: "Lady Gaga",
        birthdate: "March 28",
        degree: "~7° Aries (Zone 2, but shows cusp influence)",
        notes: "Spiritual artistry + fierce advocacy"
      }
    ],
    sabianSymbol: {
      degree: 1,
      symbol: "A woman has risen out of the water; a seal is embracing her",
      interpretation: "Emergence from the unconscious (Pisces/water) into conscious action (Aries). The seal represents emotional wisdom accompanying the warrior's journey."
    },
    nakshatra: {
      name: "Ashwini",
      range: "0° - 13°20' Aries (sidereal)",
      ruler: "Ketu (South Node)",
      symbol: "Horse's Head",
      deity: "Ashwini Kumaras (Divine Physicians)",
      qualities: ["Healing power", "Swift action", "Pioneering spirit", "Mystical healing"]
    },
    colorTheme: {
      primary: "#FF1744",
      secondary: "#9C27B0",
      gradient: "linear-gradient(135deg, #FF1744 0%, #9C27B0 100%)"
    }
  },

  {
    id: 2,
    name: "The Pure Ram",
    archetype: "The Unstoppable Initiator",
    degreeRange: {
      start: 5,
      end: 9.99,
      absoluteStart: 5,
      absoluteEnd: 9.99
    },
    dateRange: {
      start: "March 25",
      end: "March 29",
      duration: "~5 days"
    },
    decan: {
      number: 1,
      name: "First Decan (Cardinal)",
      primaryRuler: "Mars",
      subRuler: "Mars",
      modality: "Cardinal"
    },
    influences: [
      {
        source: "Aries",
        type: "Pure Mars",
        planet: "Mars",
        percentage: 100,
        traits: ["Raw courage", "Pure initiative", "Competitive fire", "Directness", "Independence"]
      }
    ],
    qualities: {
      speed: { level: 100, label: "Maximum", icon: "⚡⚡⚡⚡⚡" },
      stubbornness: { level: 70, label: "High", icon: "🐏🐏🐏🐏" },
      riskTolerance: { level: 100, label: "Maximum", icon: "⚖️⚖️⚖️⚖️⚖️" },
      physicalEnergy: { level: 100, label: "Maximum", icon: "⚡⚡⚡⚡⚡" },
      changeTolerance: { level: 90, label: "Very High", icon: "🔄🔄🔄🔄🔄" },
      aggression: { level: 80, label: "High", icon: "⚔️⚔️⚔️⚔️" },
      independence: { level: 100, label: "Maximum", icon: "🦅🦅🦅🦅🦅" },
      patience: { level: 10, label: "Very Low", icon: "⏳" }
    },
    strengths: [
      "Pure initiative: First to act in any situation",
      "Fearless courage: No obstacle too intimidating",
      "Authentic self-expression: Unapologetically themselves",
      "Inspiring leadership: Others follow their bold example"
    ],
    shadows: [
      "Reckless impulsivity: Acts before thinking",
      "Selfish focus: 'Me first' at others' expense",
      "Burn-out cycles: Goes too hard, crashes hard",
      "Conflict addiction: Creates drama to feel alive"
    ],
    careerSignatures: [
      "Entrepreneurship (Pure Startup Energy)",
      "Professional Athletics",
      "Military/Law Enforcement",
      "Emergency Services",
      "Competitive Sales"
    ],
    relationshipStyle: {
      pursuit: "Aggressive and direct - pursues intensely",
      commitmentSpeed: "Fast decision, can commit impulsively",
      passion: "Explosive, high-intensity, dominant",
      conflict: "Confronts immediately, fights passionately",
      jealousy: "Possessive and territorial"
    },
    famousExamples: [
      {
        name: "Mariah Carey",
        birthdate: "March 27",
        degree: "~6° Aries",
        notes: "Fierce independence, competitive drive in music"
      }
    ],
    sabianSymbol: {
      degree: 8,
      symbol: "A large hat with streamers flying, facing east",
      interpretation: "Bold self-presentation and readiness to face the new day with confidence and flair. Pure Aries showmanship."
    },
    nakshatra: {
      name: "Ashwini",
      range: "0° - 13°20' Aries (sidereal)",
      ruler: "Ketu",
      symbol: "Horse's Head",
      deity: "Ashwini Kumaras",
      qualities: ["Maximum speed", "Healing through action", "Fearless pioneering"]
    },
    colorTheme: {
      primary: "#D32F2F",
      secondary: "#F44336",
      gradient: "linear-gradient(135deg, #D32F2F 0%, #F44336 100%)"
    }
  },

  {
    id: 3,
    name: "The Passionate Achiever",
    archetype: "The Champion",
    degreeRange: {
      start: 10,
      end: 14.99,
      absoluteStart: 10,
      absoluteEnd: 14.99
    },
    dateRange: {
      start: "March 30",
      end: "April 3",
      duration: "~5 days"
    },
    decan: {
      number: 2,
      name: "Second Decan (Fixed)",
      primaryRuler: "Mars",
      subRuler: "Sun",
      modality: "Fixed"
    },
    influences: [
      {
        source: "Aries",
        type: "Core",
        planet: "Mars",
        percentage: 70,
        traits: ["Courage", "Competition", "Initiative"]
      },
      {
        source: "Leo",
        type: "Sun Sub-ruler",
        planet: "Sun",
        percentage: 30,
        traits: ["Pride", "Performance", "Leadership presence", "Creative expression"]
      }
    ],
    qualities: {
      speed: { level: 90, label: "Very Fast", icon: "⚡⚡⚡⚡⚡" },
      stubbornness: { level: 80, label: "High", icon: "🐏🐏🐏🐏" },
      riskTolerance: { level: 90, label: "Very High", icon: "⚖️⚖️⚖️⚖️⚖️" },
      physicalEnergy: { level: 95, label: "Very High", icon: "⚡⚡⚡⚡⚡" },
      changeTolerance: { level: 70, label: "High", icon: "🔄🔄🔄🔄" },
      aggression: { level: 75, label: "High", icon: "⚔️⚔️⚔️⚔️" },
      independence: { level: 90, label: "Very High", icon: "🦅🦅🦅🦅🦅" },
      patience: { level: 20, label: "Low", icon: "⏳⏳" }
    },
    strengths: [
      "Champion mindset: Driven to win and excel",
      "Charismatic leadership: Inspires through personal magnetism",
      "Creative courage: Boldly expresses unique vision",
      "Proud warrior: Fights with honor and dignity"
    ],
    shadows: [
      "Ego-driven competition: Must always be the star",
      "Domineering leadership: My way or highway",
      "Pride before fall: Won't admit mistakes",
      "Drama creation: Needs attention and spotlight"
    ],
    careerSignatures: [
      "Performance Arts (Acting, Music)",
      "Competitive Sports (Individual)",
      "Leadership/Executive Roles",
      "Creative Direction",
      "Public Speaking/Motivational"
    ],
    relationshipStyle: {
      pursuit: "Grand gestures and dramatic courtship",
      commitmentSpeed: "Medium - needs to feel like the prize",
      passion: "Theatrical and intense",
      conflict: "Prideful - won't back down",
      jealousy: "Territorial and dramatic"
    },
    famousExamples: [
      {
        name: "Robert Downey Jr.",
        birthdate: "April 4",
        degree: "~13° Aries",
        notes: "Charismatic leadership, creative boldness"
      }
    ],
    sabianSymbol: {
      degree: 13,
      symbol: "A bomb which failed to explode is now safely concealed",
      interpretation: "Controlled power. The ability to harness aggressive energy for strategic purposes rather than destructive release."
    },
    nakshatra: {
      name: "Ashwini/Bharani transition",
      range: "13°20' Aries starts Bharani",
      ruler: "Venus (Bharani)",
      symbol: "Yoni (Womb)",
      deity: "Yama (God of Death)",
      qualities: ["Creative power", "Nurturing strength", "Life-death cycles"]
    },
    colorTheme: {
      primary: "#FF5722",
      secondary: "#FF9800",
      gradient: "linear-gradient(135deg, #FF5722 0%, #FF9800 100%)"
    }
  },

  {
    id: 4,
    name: "The Strategic Warrior",
    archetype: "The General",
    degreeRange: {
      start: 15,
      end: 19.99,
      absoluteStart: 15,
      absoluteEnd: 19.99
    },
    dateRange: {
      start: "April 4",
      end: "April 8",
      duration: "~5 days"
    },
    decan: {
      number: 2,
      name: "Second Decan (Fixed)",
      primaryRuler: "Mars",
      subRuler: "Sun",
      modality: "Fixed"
    },
    influences: [
      {
        source: "Aries",
        type: "Core",
        planet: "Mars",
        percentage: 65,
        traits: ["Aggression", "Courage", "Initiative"]
      },
      {
        source: "Leo",
        type: "Sun Peak",
        planet: "Sun",
        percentage: 35,
        traits: ["Strategy", "Authority", "Organized leadership", "Regal bearing"]
      }
    ],
    qualities: {
      speed: { level: 80, label: "Fast", icon: "⚡⚡⚡⚡" },
      stubbornness: { level: 85, label: "Very High", icon: "🐏🐏🐏🐏🐏" },
      riskTolerance: { level: 80, label: "High", icon: "⚖️⚖️⚖️⚖️" },
      physicalEnergy: { level: 90, label: "Very High", icon: "⚡⚡⚡⚡⚡" },
      changeTolerance: { level: 60, label: "Medium-High", icon: "🔄🔄🔄" },
      aggression: { level: 70, label: "High", icon: "⚔️⚔️⚔️⚔️" },
      independence: { level: 85, label: "Very High", icon: "🦅🦅🦅🦅" },
      patience: { level: 30, label: "Low-Medium", icon: "⏳⏳⏳" }
    },
    strengths: [
      "Strategic aggression: Plans before attacking",
      "Authoritative leadership: Commands respect naturally",
      "Organized courage: Brave with backup plans",
      "Loyal warrior: Protects team and mission"
    ],
    shadows: [
      "Authoritarian control: Demands obedience",
      "Prideful stubbornness: Won't change course",
      "Strategic manipulation: Uses people as chess pieces",
      "Burnout leadership: Carries too much alone"
    ],
    careerSignatures: [
      "Military Leadership",
      "Corporate Executive (CEO, COO)",
      "Political Leadership",
      "Project Management",
      "Strategic Consulting"
    ],
    relationshipStyle: {
      pursuit: "Strategic courtship - plans the conquest",
      commitmentSpeed: "Medium - assesses fit carefully",
      passion: "Controlled intensity, dominant",
      conflict: "Strategic withdrawal or calculated attack",
      jealousy: "Possessive but dignified"
    },
    famousExamples: [
      {
        name: "Jackie Chan",
        birthdate: "April 7",
        degree: "~17° Aries",
        notes: "Strategic action, disciplined courage"
      }
    ],
    sabianSymbol: {
      degree: 18,
      symbol: "An empty hammock stretched between two trees",
      interpretation: "Rest between battles. The strategic warrior knows when to fight and when to conserve energy."
    },
    nakshatra: {
      name: "Bharani",
      range: "13°20' - 26°40' Aries (sidereal)",
      ruler: "Venus",
      symbol: "Yoni",
      deity: "Yama",
      qualities: ["Controlled power", "Strategic restraint", "Mature aggression"]
    },
    colorTheme: {
      primary: "#C62828",
      secondary: "#E65100",
      gradient: "linear-gradient(135deg, #C62828 0%, #E65100 100%)"
    }
  },

  {
    id: 5,
    name: "The Adventurous Optimist",
    archetype: "The Explorer",
    degreeRange: {
      start: 20,
      end: 24.99,
      absoluteStart: 20,
      absoluteEnd: 24.99
    },
    dateRange: {
      start: "April 9",
      end: "April 13",
      duration: "~5 days"
    },
    decan: {
      number: 3,
      name: "Third Decan (Mutable)",
      primaryRuler: "Mars",
      subRuler: "Jupiter",
      modality: "Mutable"
    },
    influences: [
      {
        source: "Aries",
        type: "Core",
        planet: "Mars",
        percentage: 65,
        traits: ["Courage", "Initiative", "Independence"]
      },
      {
        source: "Sagittarius",
        type: "Jupiter Sub-ruler",
        planet: "Jupiter",
        percentage: 35,
        traits: ["Optimism", "Adventure", "Philosophy", "Expansion", "Freedom-seeking"]
      }
    ],
    qualities: {
      speed: { level: 85, label: "Very Fast", icon: "⚡⚡⚡⚡" },
      stubbornness: { level: 50, label: "Medium", icon: "🐏🐏🐏" },
      riskTolerance: { level: 95, label: "Very High", icon: "⚖️⚖️⚖️⚖️⚖️" },
      physicalEnergy: { level: 90, label: "Very High", icon: "⚡⚡⚡⚡⚡" },
      changeTolerance: { level: 95, label: "Very High", icon: "🔄🔄🔄🔄🔄" },
      aggression: { level: 60, label: "Medium-High", icon: "⚔️⚔️⚔️" },
      independence: { level: 95, label: "Very High", icon: "🦅🦅🦅🦅🦅" },
      patience: { level: 25, label: "Low", icon: "⏳⏳" }
    },
    strengths: [
      "Adventurous courage: Explores unknown territories fearlessly",
      "Philosophical warrior: Fights for beliefs and ideals",
      "Optimistic initiative: Believes every action leads somewhere good",
      "Freedom fighter: Advocates for independence"
    ],
    shadows: [
      "Reckless optimism: Ignores real dangers",
      "Commitment-phobic: Runs when things get serious",
      "Preachy aggression: Forces beliefs on others",
      "Scattered energy: Too many adventures, none completed"
    ],
    careerSignatures: [
      "Travel Industry",
      "Teaching/Education (Experiential)",
      "Adventure Sports",
      "Philosophy/Religious Leadership",
      "International Business"
    ],
    relationshipStyle: {
      pursuit: "Adventurous and spontaneous",
      commitmentSpeed: "Slow - fears losing freedom",
      passion: "Playful and explorative",
      conflict: "Escapes through humor or leaving",
      jealousy: "Low - trusts partner's freedom"
    },
    famousExamples: [
      {
        name: "Thomas Jefferson",
        birthdate: "April 13",
        degree: "~23° Aries",
        notes: "Philosophical warrior, freedom advocate"
      }
    ],
    sabianSymbol: {
      degree: 23,
      symbol: "A woman in pastel colors carrying a heavy and valuable but veiled load",
      interpretation: "Hidden wisdom being carried forward. The explorer bears truth that will eventually be revealed."
    },
    nakshatra: {
      name: "Krittika",
      range: "26°40' Aries - 10° Taurus (sidereal)",
      ruler: "Sun",
      symbol: "Razor/Flame",
      deity: "Agni",
      qualities: ["Purifying fire", "Sharp discrimination", "Adventurous spirit"]
    },
    colorTheme: {
      primary: "#FF6F00",
      secondary: "#FFB300",
      gradient: "linear-gradient(135deg, #FF6F00 0%, #FFB300 100%)"
    }
  },

  {
    id: 6,
    name: "The Aries-Taurus Cusp",
    archetype: "The Grounded Warrior",
    degreeRange: {
      start: 25,
      end: 29.99,
      absoluteStart: 25,
      absoluteEnd: 29.99
    },
    dateRange: {
      start: "April 14",
      end: "April 19",
      duration: "~6 days"
    },
    decan: {
      number: 3,
      name: "Third Decan (Mutable)",
      primaryRuler: "Mars",
      subRuler: "Jupiter",
      modality: "Mutable"
    },
    influences: [
      {
        source: "Aries",
        type: "Core",
        planet: "Mars",
        percentage: 75,
        traits: ["Courage", "Initiative", "Action-orientation"]
      },
      {
        source: "Taurus",
        type: "Cusp Anticipation",
        planet: "Venus",
        percentage: 25,
        traits: ["Practicality", "Patience", "Sensuality", "Building instinct", "Material focus"]
      }
    ],
    qualities: {
      speed: { level: 75, label: "Fast-Medium", icon: "⚡⚡⚡⚡" },
      stubbornness: { level: 75, label: "High", icon: "🐏🐏🐏🐏" },
      riskTolerance: { level: 70, label: "High", icon: "⚖️⚖️⚖️⚖️" },
      physicalEnergy: { level: 85, label: "Very High", icon: "⚡⚡⚡⚡" },
      changeTolerance: { level: 60, label: "Medium-High", icon: "🔄🔄🔄" },
      aggression: { level: 65, label: "Medium-High", icon: "⚔️⚔️⚔️" },
      independence: { level: 80, label: "High", icon: "🦅🦅🦅🦅" },
      patience: { level: 40, label: "Low-Medium", icon: "⏳⏳⏳" }
    },
    strengths: [
      "Practical courage: Bold actions with solid foundations",
      "Building warrior: Creates lasting things with aggressive energy",
      "Sensual strength: Appreciates beauty while being fierce",
      "Grounded initiative: Starts things AND finishes them"
    ],
    shadows: [
      "Stubborn aggression: Won't change course even when wrong",
      "Materialistic fighting: Battles for possessions/status",
      "Impatient building: Rushes construction, shaky foundations",
      "Possessive independence: 'Mine' mentality"
    ],
    careerSignatures: [
      "Construction/Real Estate Development",
      "Financial Trading/Investment",
      "Culinary Arts (High-pressure)",
      "Fashion (Bold Design)",
      "Agriculture/Ranching"
    ],
    relationshipStyle: {
      pursuit: "Physical and persistent",
      commitmentSpeed: "Medium - wants stability after conquest",
      passion: "Sensual and dominant",
      conflict: "Stubborn standoffs",
      jealousy: "High - possessive of partner"
    },
    famousExamples: [
      {
        name: "Emma Watson",
        birthdate: "April 15",
        degree: "~25° Aries",
        notes: "Activist warrior with grounded values"
      }
    ],
    sabianSymbol: {
      degree: 28,
      symbol: "A large disappointed audience",
      interpretation: "Not all battles are won. The transition to Taurus teaches the warrior to build more carefully and consider the audience."
    },
    nakshatra: {
      name: "Krittika",
      range: "26°40' Aries - 10° Taurus (sidereal)",
      ruler: "Sun",
      symbol: "Razor/Flame",
      deity: "Agni",
      qualities: ["Transitional fire", "Building courage", "Grounded passion"]
    },
    colorTheme: {
      primary: "#E91E63",
      secondary: "#8B4513",
      gradient: "linear-gradient(135deg, #E91E63 0%, #8B4513 100%)"
    }
  }
];

export default ariesZones;
