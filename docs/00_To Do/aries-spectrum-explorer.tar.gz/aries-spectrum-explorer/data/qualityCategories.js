// Quality Categories for Aries
// Includes Aggression metric specific to Fire signs

export const qualityCategories = [
  {
    id: 'speed',
    label: 'Speed/Tempo',
    icon: '⚡',
    maxLevel: 5,
    description: 'How quickly you move through decisions and actions - Aries signature trait',
    lowDescription: 'Strategic pace (rare for Aries)',
    highDescription: 'Lightning-fast action (classic Aries)'
  },
  {
    id: 'stubbornness',
    label: 'Stubbornness',
    icon: '🐏',
    maxLevel: 5,
    description: 'Resistance to changing course - less than Taurus but still present',
    lowDescription: 'Flexible and adaptable',
    highDescription: 'Headstrong and determined'
  },
  {
    id: 'riskTolerance',
    label: 'Risk Tolerance',
    icon: '⚖️',
    maxLevel: 5,
    description: 'Willingness to take chances - Aries excels here',
    lowDescription: 'Calculated risks only',
    highDescription: 'Fearless risk-taker'
  },
  {
    id: 'physicalEnergy',
    label: 'Physical Energy',
    icon: '⚡',
    maxLevel: 5,
    description: 'Base vitality and action capacity - consistently high for Aries',
    lowDescription: 'Sustainable energy',
    highDescription: 'Tireless, explosive vitality'
  },
  {
    id: 'changeTolerance',
    label: 'Change Tolerance',
    icon: '🔄',
    maxLevel: 5,
    description: 'Ability to adapt and pivot - Aries initiates change',
    lowDescription: 'Prefers consistency',
    highDescription: 'Thrives on change and newness'
  },
  {
    id: 'aggression',
    label: 'Aggression',
    icon: '⚔️',
    maxLevel: 5,
    description: 'Assertiveness, competitiveness, combativeness - key Aries trait',
    lowDescription: 'Gentle warrior (tempered by other influences)',
    highDescription: 'Direct, confrontational, competitive'
  },
  {
    id: 'independence',
    label: 'Independence',
    icon: '🦅',
    maxLevel: 5,
    description: 'Need for autonomy and self-reliance - THE Aries constant',
    lowDescription: 'Collaborative but self-sufficient',
    highDescription: 'Fiercely independent, must be free'
  },
  {
    id: 'patience',
    label: 'Patience',
    icon: '⏳',
    maxLevel: 5,
    description: 'Ability to wait - Aries weakest trait',
    lowDescription: 'Acts immediately, minimal patience',
    highDescription: 'Can wait strategically when needed'
  }
];

export default qualityCategories;
