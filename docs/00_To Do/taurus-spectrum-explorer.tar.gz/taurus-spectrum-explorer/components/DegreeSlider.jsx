import React from 'react';
import taurusZones from '../data/taurusZones.js';
import { getZoneFromDegree } from '../utils/zoneCalculations.js';
import './DegreeSlider.css';

/**
 * Interactive degree slider with visual zone markers
 */
const DegreeSlider = ({ 
  currentDegree, 
  onDegreeChange, 
  userDegree = null,
  showUserHighlight = false,
  onJumpToUser = null
}) => {
  
  const handleSliderChange = (event) => {
    const newDegree = parseFloat(event.target.value);
    onDegreeChange(newDegree);
  };

  const currentZone = getZoneFromDegree(currentDegree);
  const userZone = userDegree ? getZoneFromDegree(userDegree) : null;

  return (
    <div className="degree-slider-container">
      {/* Zodiac Context Labels */}
      <div className="zodiac-context">
        <span className="sign-label aries">♈ Aries 29°</span>
        <span className="sign-label taurus">♉ TAURUS (0° - 30°)</span>
        <span className="sign-label gemini">♊ Gemini 0°</span>
      </div>

      {/* Decan Markers */}
      <div className="decan-markers">
        <div className="decan decan-1" title="First Decan: Venus/Venus - Cardinal">
          <span className="decan-label">1st Decan</span>
          <span className="decan-ruler">Venus</span>
        </div>
        <div className="decan decan-2" title="Second Decan: Venus/Mercury - Fixed">
          <span className="decan-label">2nd Decan</span>
          <span className="decan-ruler">Mercury</span>
        </div>
        <div className="decan decan-3" title="Third Decan: Venus/Saturn - Mutable">
          <span className="decan-label">3rd Decan</span>
          <span className="decan-ruler">Saturn</span>
        </div>
      </div>

      {/* Zone Markers */}
      <div className="zone-markers">
        {taurusZones.map(zone => (
          <div
            key={zone.id}
            className={`zone-marker zone-${zone.id} ${currentZone?.id === zone.id ? 'active' : ''}`}
            style={{
              left: `${(zone.degreeRange.start / 30) * 100}%`,
              width: `${((zone.degreeRange.end - zone.degreeRange.start + 0.99) / 30) * 100}%`,
              background: zone.colorTheme.gradient
            }}
            title={`Zone ${zone.id}: ${zone.name} (${zone.degreeRange.start}°-${zone.degreeRange.end}°)`}
          >
            <span className="zone-number">{zone.id}</span>
          </div>
        ))}
      </div>

      {/* User Degree Marker (if provided) */}
      {userDegree !== null && showUserHighlight && (
        <div
          className="user-degree-marker"
          style={{ left: `${(userDegree / 30) * 100}%` }}
          title={`Your Sun: ${userDegree.toFixed(2)}° Taurus`}
        >
          <div className="user-marker-line"></div>
          <div className="user-marker-label">⭐ You</div>
        </div>
      )}

      {/* Main Slider */}
      <div className="slider-wrapper">
        <input
          type="range"
          min="0"
          max="29.99"
          step="0.01"
          value={currentDegree}
          onChange={handleSliderChange}
          className="degree-slider"
          style={{
            '--zone-color': currentZone?.colorTheme?.primary || '#8B4513'
          }}
        />
      </div>

      {/* Current Position Info */}
      <div className="slider-info">
        <div className="current-position">
          <div className="degree-display">
            <span className="degree-value">{currentDegree.toFixed(2)}°</span>
            <span className="sign-name">Taurus</span>
          </div>
          <div className="absolute-position">
            Absolute: {(30 + currentDegree).toFixed(2)}° ecliptic
          </div>
        </div>

        {currentZone && (
          <div className="current-zone" style={{ borderLeft: `4px solid ${currentZone.colorTheme.primary}` }}>
            <div className="zone-name">
              <strong>Zone {currentZone.id}:</strong> {currentZone.name}
            </div>
            <div className="zone-archetype">{currentZone.archetype}</div>
          </div>
        )}

        {userDegree !== null && onJumpToUser && (
          <button 
            className="jump-to-user-btn"
            onClick={onJumpToUser}
            title={`Jump to your degree: ${userDegree.toFixed(2)}°`}
          >
            <span className="btn-icon">⭐</span>
            <span className="btn-text">Jump to My Degree</span>
          </button>
        )}
      </div>

      {/* Degree Scale */}
      <div className="degree-scale">
        {[0, 5, 10, 15, 20, 25, 30].map(deg => (
          <div
            key={deg}
            className="scale-mark"
            style={{ left: `${(deg / 30) * 100}%` }}
          >
            <div className="scale-tick"></div>
            <div className="scale-label">{deg}°</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DegreeSlider;
