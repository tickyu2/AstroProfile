import React, { useState, useEffect } from 'react';
import taurusZones from '../data/taurusZones.js';
import { getUserZoneInfo } from '../utils/zoneCalculations.js';
import DegreeSlider from './DegreeSlider.jsx';
import ViewModeSelector from './ViewModeSelector.jsx';
import ZoneSelector from './ZoneSelector.jsx';
import SingleZoneView from './SingleZoneView.jsx';
import SideBySideView from './SideBySideView.jsx';
import FullMatrixView from './FullMatrixView.jsx';
import './TaurusSpectrumExplorer.css';

/**
 * Main Taurus Spectrum Explorer Component
 * Educational tool for understanding the 30° journey through Taurus
 */
const TaurusSpectrumExplorer = ({ userDegree = null, userName = null }) => {
  // State management
  const [currentDegree, setCurrentDegree] = useState(userDegree || 15); // Default to middle
  const [viewMode, setViewMode] = useState('single'); // 'single', 'sideBySide', 'matrix'
  const [selectedZones, setSelectedZones] = useState([1]); // Zone IDs for comparison
  const [showUserHighlight, setShowUserHighlight] = useState(!!userDegree);

  // Update selected zone when degree changes
  useEffect(() => {
    const currentZone = taurusZones.find(zone => 
      currentDegree >= zone.degreeRange.start && currentDegree <= zone.degreeRange.end
    );
    
    if (currentZone && viewMode === 'single') {
      setSelectedZones([currentZone.id]);
    }
  }, [currentDegree, viewMode]);

  // Handle degree change from slider
  const handleDegreeChange = (newDegree) => {
    setCurrentDegree(newDegree);
  };

  // Handle view mode change
  const handleViewModeChange = (newMode) => {
    setViewMode(newMode);
    
    // Adjust selected zones based on view mode
    if (newMode === 'single' && selectedZones.length > 1) {
      setSelectedZones([selectedZones[0]]);
    } else if (newMode === 'matrix') {
      setSelectedZones([1, 2, 3, 4, 5, 6]); // All zones
    } else if (newMode === 'sideBySide' && selectedZones.length === 1) {
      // Add a comparison zone
      const currentZone = selectedZones[0];
      const comparisonZone = currentZone === 1 ? 3 : 1;
      setSelectedZones([currentZone, comparisonZone]);
    }
  };

  // Handle zone selection toggle
  const handleZoneToggle = (zoneId) => {
    if (viewMode === 'matrix') return; // Matrix always shows all

    if (viewMode === 'single') {
      setSelectedZones([zoneId]);
      // Move slider to middle of selected zone
      const zone = taurusZones.find(z => z.id === zoneId);
      if (zone) {
        const middleDegree = (zone.degreeRange.start + zone.degreeRange.end) / 2;
        setCurrentDegree(middleDegree);
      }
    } else if (viewMode === 'sideBySide') {
      setSelectedZones(prev => {
        if (prev.includes(zoneId)) {
          // Remove if already selected (but keep at least 1)
          return prev.length > 1 ? prev.filter(id => id !== zoneId) : prev;
        } else {
          // Add if not selected (max 3)
          return prev.length < 3 ? [...prev, zoneId].sort() : prev;
        }
      });
    }
  };

  // Jump to user's degree
  const jumpToUserDegree = () => {
    if (userDegree !== null) {
      setCurrentDegree(userDegree);
      setShowUserHighlight(true);
    }
  };

  // Get zones for current view
  const getDisplayZones = () => {
    if (viewMode === 'matrix') {
      return taurusZones;
    }
    return taurusZones.filter(zone => selectedZones.includes(zone.id));
  };

  const displayZones = getDisplayZones();
  const userZoneInfo = userDegree ? getUserZoneInfo(userDegree) : null;

  return (
    <div className="taurus-spectrum-explorer">
      {/* Header */}
      <header className="explorer-header">
        <h1>The Taurus Spectrum Explorer</h1>
        <p className="subtitle">Understanding the 30° Journey Through the Bull</p>
        {userName && userDegree && (
          <div className="user-welcome">
            Welcome, {userName}! Your Sun is at {userDegree.toFixed(2)}° Taurus 
            (Zone {userZoneInfo?.zone?.id}: {userZoneInfo?.zone?.name})
          </div>
        )}
      </header>

      {/* Interactive Degree Slider */}
      <section className="slider-section">
        <DegreeSlider
          currentDegree={currentDegree}
          onDegreeChange={handleDegreeChange}
          userDegree={userDegree}
          showUserHighlight={showUserHighlight}
          onJumpToUser={jumpToUserDegree}
        />
      </section>

      {/* View Mode Selector */}
      <section className="controls-section">
        <ViewModeSelector
          currentMode={viewMode}
          onModeChange={handleViewModeChange}
        />
        
        {viewMode !== 'matrix' && (
          <ZoneSelector
            selectedZones={selectedZones}
            onZoneToggle={handleZoneToggle}
            maxSelections={viewMode === 'single' ? 1 : 3}
            allZones={taurusZones}
          />
        )}
      </section>

      {/* Main Content Area */}
      <main className="content-area">
        {viewMode === 'single' && displayZones.length > 0 && (
          <SingleZoneView
            zone={displayZones[0]}
            currentDegree={currentDegree}
            isUserZone={userZoneInfo?.zone?.id === displayZones[0].id}
          />
        )}

        {viewMode === 'sideBySide' && displayZones.length >= 2 && (
          <SideBySideView
            zones={displayZones}
            userDegree={userDegree}
          />
        )}

        {viewMode === 'matrix' && (
          <FullMatrixView
            zones={displayZones}
            userDegree={userDegree}
            highlightZone={userZoneInfo?.zone?.id}
          />
        )}
      </main>

      {/* Educational Footer */}
      <footer className="explorer-footer">
        <div className="educational-note">
          <h4>💡 Educational Note</h4>
          <p>
            This tool demonstrates that even within a single zodiac sign, there are 
            significant variations based on degree placement. Your exact degree creates 
            a unique expression of Taurus energy, influenced by decan rulers and cusp effects.
          </p>
        </div>
        
        <div className="methodology">
          <h4>📊 Methodology</h4>
          <p>
            Based on traditional decan system (10° subdivisions) combined with 5° cusp 
            influence zones. Quality assessments derived from classical astrology, 
            modern research, and observed patterns across thousands of charts.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default TaurusSpectrumExplorer;
