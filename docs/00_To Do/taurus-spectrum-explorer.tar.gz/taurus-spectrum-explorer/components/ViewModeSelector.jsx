import React from 'react';
import './ViewModeSelector.css';

/**
 * Toggle between Single, Side-by-Side, and Matrix view modes
 */
const ViewModeSelector = ({ currentMode, onModeChange }) => {
  const modes = [
    {
      id: 'single',
      label: 'Single View',
      icon: '📄',
      description: 'Deep dive into one zone'
    },
    {
      id: 'sideBySide',
      label: 'Side-by-Side',
      icon: '📊',
      description: 'Compare 2-3 zones'
    },
    {
      id: 'matrix',
      label: 'Full Matrix',
      icon: '🔲',
      description: 'All 6 zones'
    }
  ];

  return (
    <div className="view-mode-selector">
      <label className="selector-label">Comparison Mode:</label>
      <div className="mode-buttons">
        {modes.map(mode => (
          <button
            key={mode.id}
            className={`mode-button ${currentMode === mode.id ? 'active' : ''}`}
            onClick={() => onModeChange(mode.id)}
            title={mode.description}
          >
            <span className="mode-icon">{mode.icon}</span>
            <span className="mode-label">{mode.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default ViewModeSelector;
