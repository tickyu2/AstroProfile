import React from 'react';
import { qualityCategories, compareQualityAcrossZones } from '../data/qualityCategories.js';
import './SideBySideView.css';

/**
 * Side-by-side comparison of 2-3 zones
 */
const SideBySideView = ({ zones, userDegree = null }) => {
  
  // Generate comparison insights
  const generateInsights = () => {
    const insights = [];
    
    qualityCategories.forEach(category => {
      const comparison = compareQualityAcrossZones(zones, category.id);
      
      if (comparison.range > 30) {
        insights.push({
          category: category.label,
          icon: category.icon,
          text: `${comparison.range}% difference: Zone ${comparison.maxZone.id} (${comparison.max}%) vs Zone ${comparison.minZone.id} (${comparison.min}%)`,
          significance: comparison.range > 50 ? 'high' : 'medium'
        });
      }
    });
    
    return insights;
  };

  const insights = generateInsights();

  return (
    <div className="side-by-side-view">
      {/* Comparison Header */}
      <div className="comparison-header">
        <h3>Comparing {zones.length} Taurus Zones</h3>
        <p>Highlighting similarities and differences across the spectrum</p>
      </div>

      {/* Zone Columns */}
      <div className="comparison-grid" style={{
        gridTemplateColumns: `repeat(${zones.length}, 1fr)`
      }}>
        {zones.map(zone => (
          <div key={zone.id} className="zone-column">
            {/* Column Header */}
            <header 
              className="zone-column-header"
              style={{ background: zone.colorTheme.gradient }}
            >
              <div className="zone-id">Zone {zone.id}</div>
              <h4 className="zone-name">{zone.name}</h4>
              <div className="zone-archetype">{zone.archetype}</div>
              <div className="zone-degree-range">
                {zone.degreeRange.start}° - {zone.degreeRange.end}°
              </div>
            </header>

            {/* Influence Summary */}
            <div className="influence-summary">
              {zone.influences.map((inf, idx) => (
                <div key={idx} className="influence-chip" title={inf.traits.join(', ')}>
                  <span className="influence-source">{inf.source}</span>
                  <span className="influence-percent">{inf.percentage}%</span>
                </div>
              ))}
            </div>

            {/* Quality Bars */}
            <div className="qualities-compact">
              {qualityCategories.map(category => {
                const quality = zone.qualities[category.id];
                if (!quality) return null;
                
                return (
                  <div key={category.id} className="quality-row">
                    <div className="quality-row-header">
                      <span className="quality-icon">{category.icon}</span>
                      <label className="quality-label">{category.label}</label>
                    </div>
                    <div className="mini-bar-container">
                      <div className="mini-bar">
                        <div 
                          className="mini-bar-fill"
                          style={{ 
                            width: `${quality.level}%`,
                            background: zone.colorTheme.gradient
                          }}
                        />
                      </div>
                      <span className="quality-percent">{quality.level}%</span>
                    </div>
                    <div className="quality-label-text">{quality.label}</div>
                  </div>
                );
              })}
            </div>

            {/* Key Traits */}
            <div className="key-traits">
              <div className="trait-item">
                <h5>Career Style</h5>
                <p>{zone.careerSignatures[0]}</p>
              </div>
              
              <div className="trait-item">
                <h5>Commitment Speed</h5>
                <p>{zone.relationshipStyle.commitmentSpeed}</p>
              </div>
              
              <div className="trait-item">
                <h5>Conflict Style</h5>
                <p>{zone.relationshipStyle.conflict}</p>
              </div>

              <div className="trait-item">
                <h5>Core Strength</h5>
                <p>{zone.strengths[0]}</p>
              </div>

              <div className="trait-item">
                <h5>Main Challenge</h5>
                <p>{zone.shadows[0]}</p>
              </div>
            </div>

            {/* Famous Example */}
            {zone.famousExamples && zone.famousExamples[0] && (
              <div className="famous-example-mini">
                <h5>Example</h5>
                <div className="person-name">{zone.famousExamples[0].name}</div>
                <div className="person-date">{zone.famousExamples[0].birthdate}</div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Key Insights Section */}
      {insights.length > 0 && (
        <section className="comparison-insights">
          <h4 className="insights-title">💡 Key Differences</h4>
          <div className="insights-grid">
            {insights.map((insight, idx) => (
              <div 
                key={idx} 
                className={`insight-card ${insight.significance}`}
              >
                <span className="insight-icon">{insight.icon}</span>
                <div className="insight-content">
                  <strong>{insight.category}:</strong> {insight.text}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Commonalities */}
      <section className="commonalities">
        <h4 className="commonalities-title">🔗 What All These Zones Share</h4>
        <div className="commonalities-grid">
          <div className="commonality-item">
            <span className="commonality-icon">💎</span>
            <div>
              <strong>Loyalty:</strong> All maintain 80-100% loyalty—this is the Taurus constant
            </div>
          </div>
          <div className="commonality-item">
            <span className="commonality-icon">🌹</span>
            <div>
              <strong>Sensuality:</strong> All express some form of physical/aesthetic appreciation
            </div>
          </div>
          <div className="commonality-item">
            <span className="commonality-icon">🏗️</span>
            <div>
              <strong>Building Instinct:</strong> All are oriented toward creating lasting things
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SideBySideView;
