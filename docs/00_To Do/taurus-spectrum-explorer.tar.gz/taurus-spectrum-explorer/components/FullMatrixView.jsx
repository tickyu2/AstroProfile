import React from 'react';
import { qualityCategories } from '../data/qualityCategories.js';
import './FullMatrixView.css';

/**
 * Full matrix view showing all 6 zones in comprehensive table
 */
const FullMatrixView = ({ zones, userDegree = null, highlightZone = null }) => {
  
  return (
    <div className="matrix-view">
      {/* Visual Spectrum Bar */}
      <section className="spectrum-visual">
        <h3>The Complete Taurus Spectrum</h3>
        <div className="spectrum-bar">
          {zones.map(zone => (
            <div
              key={zone.id}
              className={`spectrum-segment ${highlightZone === zone.id ? 'highlighted' : ''}`}
              style={{
                width: `${100 / zones.length}%`,
                background: zone.colorTheme.gradient
              }}
              title={zone.name}
            >
              <div className="segment-label">
                <strong>{zone.id}</strong>
                <span>{zone.degreeRange.start}°-{zone.degreeRange.end}°</span>
              </div>
            </div>
          ))}
        </div>
        <div className="spectrum-labels">
          <span className="label-start">🔥 Aries Cusp</span>
          <span className="label-middle">🌹 Pure Taurus</span>
          <span className="label-end">💬 Gemini Cusp</span>
        </div>
      </section>

      {/* Decan Structure */}
      <section className="decan-structure">
        <h4>Decan Structure</h4>
        <div className="decan-row">
          <div className="decan-block decan-1">
            <div className="decan-header">First Decan</div>
            <div className="decan-ruler">Venus/Venus Ruled</div>
            <div className="decan-zones">Zones 1-2</div>
            <div className="decan-quality">Cardinal/Initiating</div>
          </div>
          <div className="decan-block decan-2">
            <div className="decan-header">Second Decan</div>
            <div className="decan-ruler">Mercury/Virgo Ruled</div>
            <div className="decan-zones">Zones 3-4</div>
            <div className="decan-quality">Fixed/Stabilizing</div>
          </div>
          <div className="decan-block decan-3">
            <div className="decan-header">Third Decan</div>
            <div className="decan-ruler">Saturn/Capricorn Ruled</div>
            <div className="decan-zones">Zones 5-6</div>
            <div className="decan-quality">Mutable/Transitioning</div>
          </div>
        </div>
      </section>

      {/* Main Comparison Table */}
      <section className="matrix-table-section">
        <h4>Quality Comparison Matrix</h4>
        <div className="table-wrapper">
          <table className="matrix-table">
            <thead>
              <tr>
                <th className="quality-header">Quality</th>
                {zones.map(zone => (
                  <th 
                    key={zone.id}
                    className={`zone-header ${highlightZone === zone.id ? 'highlighted' : ''}`}
                    style={{ borderTop: `4px solid ${zone.colorTheme.primary}` }}
                  >
                    <div className="zone-header-content">
                      <span className="zone-number">Zone {zone.id}</span>
                      <span className="zone-degrees">{zone.degreeRange.start}°-{zone.degreeRange.end}°</span>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {/* Quality rows */}
              {qualityCategories.map(category => (
                <tr key={category.id} className="quality-row">
                  <td className="quality-label-cell">
                    <span className="quality-icon">{category.icon}</span>
                    <span className="quality-name">{category.label}</span>
                  </td>
                  {zones.map(zone => {
                    const quality = zone.qualities[category.id];
                    return (
                      <td 
                        key={zone.id}
                        className={`quality-cell ${highlightZone === zone.id ? 'highlighted' : ''}`}
                      >
                        <div className="quality-cell-content">
                          <div className="quality-icons">{quality?.icon}</div>
                          <div className="quality-percentage">{quality?.level}%</div>
                          <div className="quality-bar-mini">
                            <div 
                              className="quality-bar-fill-mini"
                              style={{ 
                                width: `${quality?.level}%`,
                                background: zone.colorTheme.primary
                              }}
                            />
                          </div>
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}

              {/* Section Break */}
              <tr className="section-break">
                <td colSpan={zones.length + 1}>
                  <strong>Career & Relationship Patterns</strong>
                </td>
              </tr>

              {/* Career Archetype */}
              <tr className="info-row">
                <td className="info-label-cell">
                  <span className="info-icon">💼</span>
                  <span>Primary Career Style</span>
                </td>
                {zones.map(zone => (
                  <td 
                    key={zone.id}
                    className={`info-cell ${highlightZone === zone.id ? 'highlighted' : ''}`}
                  >
                    {zone.careerSignatures[0]}
                  </td>
                ))}
              </tr>

              {/* Commitment Speed */}
              <tr className="info-row">
                <td className="info-label-cell">
                  <span className="info-icon">❤️</span>
                  <span>Commitment Timeline</span>
                </td>
                {zones.map(zone => (
                  <td 
                    key={zone.id}
                    className={`info-cell ${highlightZone === zone.id ? 'highlighted' : ''}`}
                  >
                    {zone.relationshipStyle.commitmentSpeed}
                  </td>
                ))}
              </tr>

              {/* Conflict Style */}
              <tr className="info-row">
                <td className="info-label-cell">
                  <span className="info-icon">⚔️</span>
                  <span>Conflict Response</span>
                </td>
                {zones.map(zone => (
                  <td 
                    key={zone.id}
                    className={`info-cell ${highlightZone === zone.id ? 'highlighted' : ''}`}
                  >
                    {zone.relationshipStyle.conflict}
                  </td>
                ))}
              </tr>

              {/* Section Break */}
              <tr className="section-break">
                <td colSpan={zones.length + 1}>
                  <strong>Unique Defining Traits</strong>
                </td>
              </tr>

              {/* Core Strength */}
              <tr className="info-row">
                <td className="info-label-cell">
                  <span className="info-icon">💪</span>
                  <span>Primary Strength</span>
                </td>
                {zones.map(zone => (
                  <td 
                    key={zone.id}
                    className={`info-cell ${highlightZone === zone.id ? 'highlighted' : ''}`}
                  >
                    {zone.strengths[0]}
                  </td>
                ))}
              </tr>

              {/* Main Challenge */}
              <tr className="info-row">
                <td className="info-label-cell">
                  <span className="info-icon">⚠️</span>
                  <span>Main Shadow</span>
                </td>
                {zones.map(zone => (
                  <td 
                    key={zone.id}
                    className={`info-cell ${highlightZone === zone.id ? 'highlighted' : ''}`}
                  >
                    {zone.shadows[0]}
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* Pattern Insights */}
      <section className="pattern-insights">
        <h4>🔍 Pattern Recognition</h4>
        <div className="insights-grid">
          <div className="insight-card">
            <h5>Speed Spectrum</h5>
            <p>Zone 1 moves 4x faster than Zone 3 (80% vs 20%), with gradual acceleration from Zone 3→6 as Gemini influence builds.</p>
          </div>
          <div className="insight-card">
            <h5>Sensuality Peak</h5>
            <p>Zone 3 (10-14°) represents peak Taurus sensuality (100%), with decline at both cusp ends due to Aries/Gemini influences.</p>
          </div>
          <div className="insight-card">
            <h5>Stubbornness Arc</h5>
            <p>Highest in Zone 3 (110%), decreasing toward both cusps as adaptability increases from neighboring sign influences.</p>
          </div>
          <div className="insight-card">
            <h5>Ambition Rise</h5>
            <p>Ambition steadily increases from Zone 1→5 (peaking at Zone 5 with Saturn influence) before shifting to communication in Zone 6.</p>
          </div>
          <div className="insight-card">
            <h5>Loyalty Constant</h5>
            <p>All zones maintain 80-110% loyalty despite other differences—this is the non-negotiable Taurus core trait.</p>
          </div>
          <div className="insight-card">
            <h5>Energy Distribution</h5>
            <p>Physical energy peaks in Zone 1 (100% with Aries influence), normalizes in middle zones, then rises slightly in Zone 6 (Gemini mental energy).</p>
          </div>
        </div>
      </section>

      {/* Evolution Narrative */}
      <section className="evolution-narrative">
        <h4>📖 The Taurus Journey: A 30° Evolution</h4>
        <div className="narrative-content">
          <p>
            <strong>Zone 1 (0-4°):</strong> The Warrior-Builder charges into Taurus season with Aries fire still burning, 
            initiating projects with high energy and quick decisions.
          </p>
          <p>
            <strong>Zone 2 (5-9°):</strong> Pure Venus energy emerges as Aries fades. The Builder focuses on aesthetics, 
            sensuality, and creating beautiful foundations.
          </p>
          <p>
            <strong>Zone 3 (10-14°):</strong> Peak Taurus. Maximum stubbornness, patience, and sensuality. This is the 
            Bull at full strength—immovable, deeply rooted, eternally loyal.
          </p>
          <p>
            <strong>Zone 4 (15-19°):</strong> Mercury's influence adds precision. The Craftsperson perfects technique 
            through analysis, detail-orientation, and dedicated practice.
          </p>
          <p>
            <strong>Zone 5 (20-24°):</strong> Saturn brings ambition. The Empire Builder thinks in generations, creating 
            structures and legacies that transcend individual lifetimes.
          </p>
          <p>
            <strong>Zone 6 (25-29°):</strong> Gemini's approach adds communication. The Articulate Builder can explain, 
            network, and adapt while maintaining core Taurus values.
          </p>
        </div>
      </section>
    </div>
  );
};

export default FullMatrixView;
