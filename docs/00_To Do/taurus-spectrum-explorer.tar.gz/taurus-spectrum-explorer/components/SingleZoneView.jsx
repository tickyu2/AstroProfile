import React from 'react';
import { qualityCategories } from '../data/qualityCategories.js';
import './SingleZoneView.css';

/**
 * Detailed single zone profile view
 */
const SingleZoneView = ({ zone, currentDegree, isUserZone = false }) => {
  
  return (
    <div 
      className="single-zone-view"
      style={{ 
        borderTop: `6px solid ${zone.colorTheme.primary}`,
        '--zone-primary': zone.colorTheme.primary,
        '--zone-secondary': zone.colorTheme.secondary
      }}
    >
      {/* Header */}
      <header className="zone-header">
        <div className="zone-badge" style={{ background: zone.colorTheme.gradient }}>
          Zone {zone.id}
        </div>
        <h2 className="zone-name">{zone.name}</h2>
        <h3 className="zone-archetype">"{zone.archetype}"</h3>
        
        {isUserZone && (
          <div className="user-zone-indicator">
            ⭐ This is YOUR zone at {currentDegree.toFixed(2)}°
          </div>
        )}
        
        <div className="degree-info-grid">
          <div className="info-item">
            <span className="info-label">Degree Range</span>
            <span className="info-value">{zone.degreeRange.start}° - {zone.degreeRange.end}° Taurus</span>
          </div>
          <div className="info-item">
            <span className="info-label">Absolute Position</span>
            <span className="info-value">{zone.degreeRange.absoluteStart}° - {zone.degreeRange.absoluteEnd}° ecliptic</span>
          </div>
          <div className="info-item">
            <span className="info-label">Birth Dates</span>
            <span className="info-value">{zone.dateRange.start} - {zone.dateRange.end}</span>
          </div>
          <div className="info-item">
            <span className="info-label">Duration</span>
            <span className="info-value">{zone.dateRange.duration}</span>
          </div>
        </div>
      </header>

      {/* Decan & Rulers */}
      <section className="decan-section">
        <h4 className="section-title">🌟 Decan & Planetary Rulers</h4>
        
        <div className="decan-grid">
          <div className="decan-info-card">
            <label>Decan</label>
            <div className="decan-value">{zone.decan.name}</div>
          </div>
          <div className="decan-info-card">
            <label>Primary Ruler</label>
            <div className="decan-value">{zone.decan.primaryRuler} (Taurus)</div>
          </div>
          <div className="decan-info-card">
            <label>Sub-Ruler</label>
            <div className="decan-value">{zone.decan.subRuler}</div>
          </div>
          <div className="decan-info-card">
            <label>Modality</label>
            <div className="decan-value">{zone.decan.modality}</div>
          </div>
        </div>

        <div className="influences">
          <h5>Planetary Influences:</h5>
          {zone.influences.map((influence, idx) => (
            <div key={idx} className="influence-item">
              <div className="influence-header">
                <span className="influence-source">{influence.source}</span>
                <span className="influence-planet">({influence.planet})</span>
                <span className="influence-type">{influence.type}</span>
                <span className="influence-percentage">{influence.percentage}%</span>
              </div>
              <div className="influence-bar-container">
                <div 
                  className="influence-bar-fill"
                  style={{ 
                    width: `${influence.percentage}%`,
                    background: zone.colorTheme.gradient
                  }}
                />
              </div>
              <div className="influence-traits">
                {influence.traits.map((trait, i) => (
                  <span key={i} className="trait-tag">{trait}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Quality Profile */}
      <section className="quality-profile-section">
        <h4 className="section-title">🔬 Quality Profile</h4>
        <div className="quality-bars">
          {qualityCategories.map(category => {
            const quality = zone.qualities[category.id];
            if (!quality) return null;
            
            return (
              <div key={category.id} className="quality-item">
                <div className="quality-label-row">
                  <label className="quality-label">
                    <span className="quality-icon">{category.icon}</span>
                    {category.label}
                  </label>
                  <span className="quality-level-label">{quality.label}</span>
                </div>
                
                <div className="quality-bar-container">
                  <div className="quality-icons-display">{quality.icon}</div>
                  <div className="quality-bar">
                    <div 
                      className="quality-bar-fill"
                      style={{ 
                        width: `${quality.level}%`,
                        background: zone.colorTheme.gradient
                      }}
                    >
                      <span className="quality-percentage">{quality.level}%</span>
                    </div>
                  </div>
                </div>
                
                <div className="quality-description">
                  {category.description}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Archetype Essence */}
      <section className="archetype-section">
        <h4 className="section-title">🎭 Archetype Essence</h4>
        <div className="archetype-description">
          {getArchetypeDescription(zone)}
        </div>
      </section>

      {/* Strengths & Shadows */}
      <div className="strengths-shadows-grid">
        <section className="strengths-section">
          <h4 className="section-title">💪 Core Strengths</h4>
          <ul className="strengths-list">
            {zone.strengths.map((strength, idx) => (
              <li key={idx}>{strength}</li>
            ))}
          </ul>
        </section>

        <section className="shadows-section">
          <h4 className="section-title">⚠️ Shadow Challenges</h4>
          <ul className="shadows-list">
            {zone.shadows.map((shadow, idx) => (
              <li key={idx}>{shadow}</li>
            ))}
          </ul>
        </section>
      </div>

      {/* Career Signatures */}
      <section className="career-section">
        <h4 className="section-title">💼 Career Signatures</h4>
        <div className="career-tags">
          {zone.careerSignatures.map((career, idx) => (
            <span 
              key={idx} 
              className="career-tag"
              style={{ 
                borderColor: zone.colorTheme.primary,
                color: zone.colorTheme.primary
              }}
            >
              {career}
            </span>
          ))}
        </div>
      </section>

      {/* Relationship Style */}
      <section className="relationship-section">
        <h4 className="section-title">❤️ Relationship Style</h4>
        <div className="relationship-grid">
          {Object.entries(zone.relationshipStyle).map(([key, value]) => (
            <div key={key} className="relationship-item">
              <label>{formatLabel(key)}</label>
              <div className="relationship-value">{value}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Famous Examples */}
      {zone.famousExamples && zone.famousExamples.length > 0 && (
        <section className="famous-examples-section">
          <h4 className="section-title">🌍 Famous Examples</h4>
          <div className="famous-examples-grid">
            {zone.famousExamples.map((person, idx) => (
              <div key={idx} className="famous-person-card">
                <div className="person-name">{person.name}</div>
                <div className="person-details">
                  {person.birthdate} • {person.degree}
                </div>
                <p className="person-notes">{person.notes}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Sabian Symbol */}
      {zone.sabianSymbol && (
        <section className="sabian-section">
          <h4 className="section-title">🔮 Sabian Symbol</h4>
          <div className="sabian-card">
            <div className="sabian-degree">{zone.sabianSymbol.degree}° Taurus</div>
            <blockquote className="sabian-symbol">
              "{zone.sabianSymbol.symbol}"
            </blockquote>
            <p className="sabian-interpretation">{zone.sabianSymbol.interpretation}</p>
          </div>
        </section>
      )}

      {/* Nakshatra */}
      {zone.nakshatra && (
        <section className="nakshatra-section">
          <h4 className="section-title">✨ Nakshatra (Vedic Astrology)</h4>
          <div className="nakshatra-card">
            <div className="nakshatra-header">
              <strong className="nakshatra-name">{zone.nakshatra.name}</strong>
              <span className="nakshatra-range">({zone.nakshatra.range})</span>
            </div>
            <div className="nakshatra-details">
              <div className="nakshatra-detail">
                <label>Ruled by:</label>
                <span>{zone.nakshatra.ruler}</span>
              </div>
              <div className="nakshatra-detail">
                <label>Symbol:</label>
                <span>{zone.nakshatra.symbol}</span>
              </div>
              <div className="nakshatra-detail">
                <label>Deity:</label>
                <span>{zone.nakshatra.deity}</span>
              </div>
            </div>
            <div className="nakshatra-qualities">
              {zone.nakshatra.qualities.map((quality, idx) => (
                <span key={idx} className="quality-chip">{quality}</span>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
};

// Helper function to get archetype description
function getArchetypeDescription(zone) {
  const descriptions = {
    1: "You're the Taurus who STARTS things. While other Bulls wait for the perfect moment, you charge ahead with Aries initiative but Taurus commitment. You're 75% classic Taurus stability, 25% Aries fire. Think of yourself as the warrior who builds gardens—you'll fight to protect what you've created.",
    
    2: "You've hit the sweet spot between initiative and stability. The Aries influence has faded, leaving you with pure Venus energy—deeply sensual, aesthetic-focused, and naturally drawn to creating beautiful, lasting things. You're the architect who builds empires with patience and exquisite taste.",
    
    3: "You ARE the definition of Taurus. Maximum sensuality, maximum stubbornness, maximum patience. You move on geological time, but what you build lasts forever. People misunderstand your slowness for weakness—they learn otherwise when they try to move you. You're the immovable force of nature.",
    
    4: "You're the Taurus perfectionist. Mercury/Virgo influence adds analytical precision to Taurus's natural craftsmanship. You don't just build things; you master the process through 10,000 hours of dedicated practice. Quality isn't just important to you—it's everything.",
    
    5: "You combine Taurus's love of beauty with Capricorn's ambition for achievement. You're not just building a home; you're building an empire. You think in terms of legacy, generational wealth, structures that outlive you. Saturn adds discipline to Venus's indulgence, creating the ultimate empire builder.",
    
    6: "You're the Taurus who can explain WHY beauty matters. Approaching Gemini gives you mental agility, communication skills, and intellectual curiosity that other Taurus lack. You're the most adaptable Bull, able to pivot when necessary while maintaining your core values."
  };
  
  return descriptions[zone.id] || "";
}

// Helper function to format camelCase labels
function formatLabel(key) {
  return key
    .replace(/([A-Z])/g, ' $1')
    .replace(/^./, str => str.toUpperCase())
    .trim();
}

export default SingleZoneView;
