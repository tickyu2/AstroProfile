import React from 'react';
import './ZoneSelector.css';

/**
 * Multi-select zone picker for comparison views
 */
const ZoneSelector = ({ selectedZones, onZoneToggle, maxSelections, allZones }) => {
  
  return (
    <div className="zone-selector">
      <label className="selector-label">
        Select Zones to Compare:
        {maxSelections > 1 && (
          <span className="selection-count"> ({selectedZones.length}/{maxSelections})</span>
        )}
      </label>
      
      <div className="zone-buttons">
        {allZones.map(zone => {
          const isSelected = selectedZones.includes(zone.id);
          const isDisabled = !isSelected && selectedZones.length >= maxSelections;
          
          return (
            <button
              key={zone.id}
              className={`zone-button ${isSelected ? 'selected' : ''} ${isDisabled ? 'disabled' : ''}`}
              onClick={() => onZoneToggle(zone.id)}
              disabled={isDisabled}
              style={{
                '--zone-color': zone.colorTheme.primary,
                background: isSelected ? zone.colorTheme.gradient : 'transparent',
                borderColor: zone.colorTheme.primary,
                color: isSelected ? '#fff' : zone.colorTheme.primary
              }}
              title={`${zone.name} (${zone.degreeRange.start}°-${zone.degreeRange.end}°)`}
            >
              <span className="zone-number">Zone {zone.id}</span>
              <span className="zone-name-short">{zone.name.split(':')[0].trim()}</span>
            </button>
          );
        })}
      </div>

      {maxSelections > 1 && selectedZones.length < 2 && (
        <div className="selection-hint">
          Select at least 2 zones to compare
        </div>
      )}
    </div>
  );
};

export default ZoneSelector;
