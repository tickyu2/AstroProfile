# Implementation Guide for Brother Opus
## Taurus Spectrum Explorer - Step-by-Step Deployment

---

## 📋 Pre-Implementation Checklist

- [ ] Node.js 16+ installed
- [ ] React 18+ project setup
- [ ] Git repository initialized
- [ ] Code editor ready (VS Code recommended)
- [ ] Basic understanding of React hooks
- [ ] GENESIS AstroProfile platform access

---

## 🚀 Quick Start (5 Minutes)

### Step 1: Copy Files

```bash
# Copy the entire taurus-spectrum-explorer directory into your project
cp -r taurus-spectrum-explorer/ /path/to/your/project/src/

# Or if integrating into existing structure:
# - Copy components/ to src/components/spectrum/
# - Copy data/ to src/data/spectrum/
# - Copy utils/ to src/utils/spectrum/
```

### Step 2: Install Dependencies

```bash
cd your-project
npm install
# React 18+ will already be installed if you're working with GENESIS
```

### Step 3: Test Basic Integration

Create a test file: `src/App.test.jsx`

```jsx
import React from 'react';
import TaurusSpectrumExplorer from './taurus-spectrum-explorer/components/TaurusSpectrumExplorer';

function App() {
  return (
    <div className="App">
      <TaurusSpectrumExplorer
        userDegree={2.19}
        userName="Ticky"
      />
    </div>
  );
}

export default App;
```

### Step 4: Run

```bash
npm start
```

You should see the Taurus Spectrum Explorer load with the degree slider and zone information.

---

## 🔧 Integration with GENESIS AstroProfile

### Scenario 1: Button from Existing Profile

In your current `AstroProfile.jsx` or wherever you display Sun sign information:

```jsx
import { useState } from 'react';
import TaurusSpectrumExplorer from './spectrum/TaurusSpectrumExplorer';

function AstroProfile({ userData }) {
  const [showSpectrum, setShowSpectrum] = useState(false);
  
  // Extract Taurus degree from user's birth chart
  const sunSign = userData.sun.sign;
  const sunDegree = userData.sun.degree; // Degree within sign (0-29.99)
  
  // Only show button if user is Taurus
  const isTaurus = sunSign === 'Taurus';
  
  return (
    <div>
      {/* Your existing profile content */}
      
      {isTaurus && (
        <button 
          onClick={() => setShowSpectrum(true)}
          className="explore-spectrum-btn"
        >
          🔬 Explore Your Taurus Degree in Detail
        </button>
      )}
      
      {/* Modal or full-page view */}
      {showSpectrum && (
        <div className="spectrum-modal">
          <button onClick={() => setShowSpectrum(false)}>
            ← Back to Profile
          </button>
          <TaurusSpectrumExplorer
            userDegree={sunDegree}
            userName={userData.name}
          />
        </div>
      )}
    </div>
  );
}
```

### Scenario 2: From Tropical Seasons Wheel

In your `TropicalSeasons.jsx`:

```jsx
import { useNavigate } from 'react-router-dom';

function TropicalSeasons() {
  const navigate = useNavigate();
  
  const handleSignClick = (signName, degree) => {
    if (signName === 'Taurus') {
      // Navigate to spectrum explorer
      navigate('/spectrum/taurus', { 
        state: { 
          degree: degree || 15, // Default to middle if no user degree
          userName: getCurrentUser().name 
        } 
      });
    }
  };
  
  return (
    <div className="tropical-wheel">
      {/* Your wheel SVG */}
      <g onClick={() => handleSignClick('Taurus')} className="taurus-section">
        {/* Taurus section of wheel */}
      </g>
    </div>
  );
}
```

### Scenario 3: Dedicated Route

In your main routing file (`App.jsx` or `Routes.jsx`):

```jsx
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import TaurusSpectrumExplorer from './spectrum/TaurusSpectrumExplorer';

function AppRoutes() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/profile" element={<AstroProfile />} />
        <Route 
          path="/spectrum/taurus" 
          element={<TaurusSpectrumExplorerPage />} 
        />
        {/* Other routes */}
      </Routes>
    </BrowserRouter>
  );
}

// Wrapper component to handle state
function TaurusSpectrumExplorerPage() {
  const location = useLocation();
  const { degree, userName } = location.state || {};
  
  return (
    <div className="spectrum-page">
      <TaurusSpectrumExplorer
        userDegree={degree}
        userName={userName}
      />
    </div>
  );
}
```

---

## 📊 Data Integration Points

### Getting User's Taurus Degree

If you already have birth chart calculation:

```javascript
// Assuming you have a function that calculates Sun position
import { calculateSunPosition } from './astro-calculations';

const birthData = {
  date: '1963-04-23',
  time: '14:30',
  location: { lat: 34.0522, lng: -118.2437 }
};

const sunPosition = calculateSunPosition(birthData);
// sunPosition = { sign: 'Taurus', degree: 2.19, absoluteLongitude: 32.19 }

// Pass degree to component
<TaurusSpectrumExplorer userDegree={sunPosition.degree} />
```

### If You Need to Calculate It

Install a library like `astronomia` or `swisseph`:

```bash
npm install astronomia
```

```javascript
import { Sun } from 'astronomia';

function getSunDegreeInSign(birthDate, birthTime, latitude, longitude) {
  // Calculate absolute ecliptic longitude (0-360°)
  const absoluteLongitude = Sun.apparentLongitude(/* JD, nutation */);
  
  // Determine which sign (each sign is 30°)
  const signIndex = Math.floor(absoluteLongitude / 30);
  const degreeInSign = absoluteLongitude % 30;
  
  const signs = ['Aries', 'Taurus', 'Gemini', /* ... */];
  
  return {
    sign: signs[signIndex],
    degree: degreeInSign
  };
}
```

---

## 🎨 Styling Customization

### Matching GENESIS Brand

Update the CSS variables in `TaurusSpectrumExplorer.css`:

```css
:root {
  /* Change these to match your brand */
  --bg-dark: #1a1f2e;              /* Your background color */
  --bg-card: #242938;              /* Card backgrounds */
  --text-primary: #e8eaf0;         /* Main text */
  --accent-gold: #d4af37;          /* Replace with your primary color */
  
  /* Zone colors - keep these for Taurus authenticity */
  --zone-1-primary: #FF6B35;       /* Aries-Taurus cusp */
  --zone-2-primary: #8B4513;       /* Pioneering Builder */
  /* ... etc */
}
```

### Mobile Responsiveness

All components are responsive by default. Test at breakpoints:
- Desktop: 1920px, 1440px, 1024px
- Tablet: 768px
- Mobile: 375px, 320px

---

## 🧪 Testing Checklist

### Functional Testing

- [ ] Slider moves smoothly from 0-29.99°
- [ ] Zone changes correctly at boundaries (4.99→5, 9.99→10, etc.)
- [ ] User degree marker appears when userDegree prop provided
- [ ] "Jump to My Degree" button works
- [ ] All three view modes switch correctly
- [ ] Zone selector enables/disables correctly
- [ ] Side-by-side shows 2-3 zones max
- [ ] Matrix shows all 6 zones

### Visual Testing

- [ ] All colors display correctly
- [ ] Text is readable (WCAG AA contrast)
- [ ] No layout shifts or jumps
- [ ] Smooth transitions and animations
- [ ] Mobile layout stacks correctly

### Data Validation

```javascript
// Test edge cases
const testCases = [
  { degree: 0, expectedZone: 1 },      // First degree
  { degree: 4.99, expectedZone: 1 },   // Last degree of Zone 1
  { degree: 5, expectedZone: 2 },      // First degree of Zone 2
  { degree: 15, expectedZone: 4 },     // Middle of spectrum
  { degree: 29.99, expectedZone: 6 },  // Last possible degree
];

testCases.forEach(test => {
  const zone = getZoneFromDegree(test.degree);
  console.assert(zone.id === test.expectedZone, 
    `Failed for ${test.degree}°: expected zone ${test.expectedZone}, got ${zone.id}`);
});
```

---

## 🔍 Debugging Common Issues

### Issue 1: "Zone not found" error

**Cause**: Degree passed is outside 0-29.99 range

**Fix**: Validate degree before passing:

```javascript
const safeDegree = Math.max(0, Math.min(29.99, userDegree));
<TaurusSpectrumExplorer userDegree={safeDegree} />
```

### Issue 2: Slider thumb not showing

**Cause**: CSS custom properties not applied

**Fix**: Ensure parent div doesn't override `--zone-color`:

```jsx
<div style={{ '--zone-color': undefined }}>
  <TaurusSpectrumExplorer />
</div>
```

### Issue 3: Performance lag on slider

**Cause**: Too many re-renders

**Fix**: Already implemented with debouncing, but if issues persist:

```javascript
import { useMemo, useCallback } from 'react';

const handleDegreeChange = useCallback((newDegree) => {
  // Throttle updates
  if (Math.abs(newDegree - currentDegree) > 0.1) {
    setCurrentDegree(newDegree);
  }
}, [currentDegree]);
```

### Issue 4: Data not loading

**Cause**: Import paths incorrect

**Fix**: Check relative paths:

```javascript
// If you moved files, update imports
import taurusZones from '../data/taurusZones'; // Adjust ../
```

---

## 📱 Mobile Optimization

### Viewport Meta Tag

Ensure in your `public/index.html`:

```html
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5" />
```

### Touch-Friendly Slider

Already implemented, but test:
- Slider thumb is minimum 44x44px (WCAG recommendation)
- Touch events work smoothly
- No accidental scrolls while dragging

---

## ♿ Accessibility

### Screen Reader Support

```jsx
// Add to slider
<input
  type="range"
  aria-label="Taurus degree selector"
  aria-valuemin={0}
  aria-valuemax={29.99}
  aria-valuenow={currentDegree}
  aria-valuetext={`${currentDegree.toFixed(2)} degrees Taurus, Zone ${currentZone.id}: ${currentZone.name}`}
/>
```

### Keyboard Navigation

Test these key combinations:
- `Tab`: Move between interactive elements
- `Arrow Left/Right`: Adjust slider
- `Home/End`: Jump to slider start/end
- `Enter/Space`: Activate buttons

---

## 🚀 Performance Optimization

### Code Splitting

For production, lazy load the component:

```javascript
import { lazy, Suspense } from 'react';

const TaurusSpectrumExplorer = lazy(() => 
  import('./spectrum/TaurusSpectrumExplorer')
);

function App() {
  return (
    <Suspense fallback={<div>Loading Spectrum Explorer...</div>}>
      <TaurusSpectrumExplorer userDegree={2.19} />
    </Suspense>
  );
}
```

### Image Optimization

If adding images later:

```jsx
import { useState, useEffect } from 'react';

function OptimizedImage({ src, alt }) {
  const [loaded, setLoaded] = useState(false);
  
  return (
    <img
      src={src}
      alt={alt}
      loading="lazy"
      onLoad={() => setLoaded(true)}
      style={{ opacity: loaded ? 1 : 0 }}
    />
  );
}
```

---

## 📦 Production Build

### Before Deployment

```bash
# Run linter
npm run lint

# Run tests
npm test

# Build for production
npm run build

# Test production build locally
npx serve -s build
```

### Bundle Size Check

```bash
npm install -g source-map-explorer
npm run build
source-map-explorer 'build/static/js/*.js'
```

Target: Keep bundle under 500KB for this feature

---

## 🔄 Future Expansion Checklist

When replicating for other signs:

- [ ] Copy `taurusZones.js` → `ariesZones.js` (update all data)
- [ ] Update zone colors for new sign
- [ ] Adjust decan rulers (different for each sign)
- [ ] Update cusp influences (Pisces→Aries, Aries→Taurus)
- [ ] Create sign-specific component: `AriesSpectrumExplorer.jsx`
- [ ] Add routing: `/spectrum/aries`
- [ ] Test all 6 zones for new sign
- [ ] Update documentation

---

## 📞 Support & Troubleshooting

### Getting Help

1. Check browser console for errors
2. Verify React version (must be 18+)
3. Check import paths
4. Validate prop data types
5. Test in incognito (rules out extension conflicts)

### Debug Mode

Add to component for verbose logging:

```jsx
const DEBUG = process.env.NODE_ENV === 'development';

useEffect(() => {
  if (DEBUG) {
    console.log('Current Degree:', currentDegree);
    console.log('Current Zone:', currentZone);
    console.log('User Degree:', userDegree);
  }
}, [currentDegree, currentZone, userDegree]);
```

---

## ✅ Final Deployment Checklist

- [ ] All files copied to correct locations
- [ ] Dependencies installed
- [ ] User degree calculation working
- [ ] Component renders on test page
- [ ] All 3 view modes working
- [ ] Slider smooth at 60fps
- [ ] Responsive on mobile
- [ ] Accessible via keyboard
- [ ] Console has no errors
- [ ] Production build created
- [ ] Tested in Chrome, Firefox, Safari
- [ ] Integrated into GENESIS navigation
- [ ] User documentation updated
- [ ] Git committed with message: "feat: Add Taurus Spectrum Explorer"

---

**You're ready to deploy! 🚀**

**Remember**: This is cathedral-quality code built for centuries. Take your time with integration, test thoroughly, and maintain the Pure Gold Method philosophy throughout.

**May every Taurus find their exact constitutional flavor!** ♉✨

---

**Implementation Time Estimate:**
- Basic integration: 30 minutes
- Full GENESIS integration: 2-3 hours
- Testing & refinement: 1-2 hours
- **Total: ~4-6 hours for complete deployment**
