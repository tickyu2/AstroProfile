// Taurus Zone Database
// Complete data structure for all 6 zones across the 30° Taurus spectrum

export const taurusZones = [
  {
    id: 1,
    name: "The Aries-Taurus Cusp",
    archetype: "The Warrior Who Plants Gardens",
    degreeRange: {
      start: 0,
      end: 4.99,
      absoluteStart: 30,
      absoluteEnd: 34.99
    },
    dateRange: {
      start: "April 20",
      end: "April 24",
      duration: "~5 days"
    },
    decan: {
      number: 1,
      name: "First Decan (Cardinal)",
      primaryRuler: "Venus",
      subRuler: "Venus",
      modality: "Cardinal"
    },
    influences: [
      {
        source: "Aries",
        type: "Cusp Bleed",
        planet: "Mars",
        percentage: 25,
        traits: ["Initiative", "High energy", "Quick anger", "Impulsiveness", "Courage"]
      },
      {
        source: "Taurus",
        type: "Core",
        planet: "Venus",
        percentage: 75,
        traits: ["Loyalty", "Sensuality", "Building instinct", "Stubbornness", "Material focus"]
      }
    ],
    qualities: {
      speed: { level: 80, label: "Fast-Medium", icon: "⚡⚡⚡⚡" },
      stubbornness: { level: 80, label: "High", icon: "🐂🐂🐂🐂" },
      riskTolerance: { level: 60, label: "Medium", icon: "⚖️⚖️⚖️" },
      physicalEnergy: { level: 100, label: "Very High", icon: "⚡⚡⚡⚡⚡" },
      changeTolerance: { level: 60, label: "Medium", icon: "🔄🔄🔄" },
      sensuality: { level: 60, label: "Medium-High", icon: "🌹🌹🌹" },
      loyalty: { level: 100, label: "Absolute", icon: "💎💎💎💎💎" },
      patience: { level: 40, label: "Low-Medium", icon: "⏳⏳" }
    },
    strengths: [
      "Pioneer builder: Creates empires from scratch",
      "Fierce protector: Guards loved ones with warrior energy",
      "High initiative: Doesn't wait for permission",
      "Passionate loyalty: Combines fire + earth commitment"
    ],
    shadows: [
      "Impatience with own/others' slower processing",
      "Burnout from pushing too hard too fast",
      "Starting too many projects without finishing",
      "Quick temper that surprises others"
    ],
    careerSignatures: [
      "Entrepreneurship",
      "Athletics & Physical Training",
      "Leadership Roles",
      "Creative Fields (Vision + Execution)",
      "Building Businesses from Scratch"
    ],
    relationshipStyle: {
      pursuit: "Active - makes first move",
      commitmentSpeed: "6 months - 1 year",
      passion: "High intensity + sensuality",
      conflict: "Will argue/fight in the moment",
      jealousy: "Present and openly expressed"
    },
    famousExamples: [
      {
        name: "Dwayne 'The Rock' Johnson",
        birthdate: "May 2",
        degree: "~2° Taurus",
        notes: "Explosive energy + steady work ethic"
      },
      {
        name: "David Beckham",
        birthdate: "May 2",
        degree: "~0-1° Taurus",
        notes: "Athletic prowess + aesthetic perfectionism"
      }
    ],
    sabianSymbol: {
      degree: 3,
      symbol: "Steps up to a lawn blooming with clover",
      interpretation: "Active creation of abundance through persistent effort (not passive waiting). The 'steps UP' implies movement and initiative—you don't wait for beauty to appear; you create the conditions for it."
    },
    nakshatra: {
      name: "Krittika",
      range: "26°40' Aries - 10° Taurus (sidereal)",
      ruler: "Sun",
      symbol: "Razor / Flame",
      deity: "Agni (Fire God)",
      qualities: ["Sharp", "Purifying", "Cutting through illusions", "Direct", "No-nonsense"]
    },
    colorTheme: {
      primary: "#FF6B35",
      secondary: "#8B4513",
      gradient: "linear-gradient(135deg, #FF6B35 0%, #8B4513 100%)"
    }
  },

  {
    id: 2,
    name: "The Pioneering Builder",
    archetype: "The Architect of Empires",
    degreeRange: {
      start: 5,
      end: 9.99,
      absoluteStart: 35,
      absoluteEnd: 39.99
    },
    dateRange: {
      start: "April 25",
      end: "April 29",
      duration: "~5 days"
    },
    decan: {
      number: 1,
      name: "First Decan (Cardinal)",
      primaryRuler: "Venus",
      subRuler: "Venus",
      modality: "Cardinal"
    },
    influences: [
      {
        source: "Taurus",
        type: "Pure Venus",
        planet: "Venus",
        percentage: 100,
        traits: ["Sensuality", "Beauty appreciation", "Building instinct", "Loyalty", "Steadiness"]
      }
    ],
    qualities: {
      speed: { level: 60, label: "Medium", icon: "⚡⚡⚡" },
      stubbornness: { level: 100, label: "Very High", icon: "🐂🐂🐂🐂🐂" },
      riskTolerance: { level: 40, label: "Low-Medium", icon: "⚖️⚖️" },
      physicalEnergy: { level: 80, label: "High", icon: "⚡⚡⚡⚡" },
      changeTolerance: { level: 40, label: "Low-Medium", icon: "🔄🔄" },
      sensuality: { level: 80, label: "High", icon: "🌹🌹🌹🌹" },
      loyalty: { level: 100, label: "Absolute", icon: "💎💎💎💎💎" },
      patience: { level: 60, label: "Medium", icon: "⏳⏳⏳" }
    },
    strengths: [
      "Pure aesthetic vision: Knows what beauty looks like",
      "Steady builder: Creates lasting structures",
      "Strong value system: Clear about what matters",
      "Deeply sensual: Connects through physical senses"
    ],
    shadows: [
      "Materialism: Confusing possessions with security",
      "Possessiveness: Treating people like owned objects",
      "Stubbornness: Refusing to adapt when needed",
      "Comfort addiction: Staying in bad situations to avoid change"
    ],
    careerSignatures: [
      "Architecture & Interior Design",
      "Fine Dining & Culinary Arts",
      "Fashion & Textiles",
      "Real Estate Development",
      "Music (Voice, String Instruments)"
    ],
    relationshipStyle: {
      pursuit: "Shows interest through acts of service and gifts",
      commitmentSpeed: "1-2 years",
      passion: "Deeply sensual - touch, smell, taste primary",
      conflict: "Avoidant - prefers harmony",
      jealousy: "Present but controlled"
    },
    famousExamples: [
      {
        name: "George Clooney",
        birthdate: "May 6",
        degree: "~15° Taurus (reference point)",
        notes: "Steady career building, refined aesthetic"
      }
    ],
    sabianSymbol: {
      degree: 8,
      symbol: "A sleigh on land uncovered by snow",
      interpretation: "Adapting resources to current conditions; making the best of what you have with practical ingenuity."
    },
    nakshatra: {
      name: "Krittika",
      range: "26°40' Aries - 10° Taurus (sidereal)",
      ruler: "Sun",
      symbol: "Razor / Flame",
      deity: "Agni (Fire God)",
      qualities: ["Purifying", "Sharp discrimination", "Nurturing fire", "Focused energy"]
    },
    colorTheme: {
      primary: "#8B4513",
      secondary: "#A0522D",
      gradient: "linear-gradient(135deg, #8B4513 0%, #A0522D 100%)"
    }
  },

  {
    id: 3,
    name: "The Quintessential Bull",
    archetype: "The Immovable Force of Nature",
    degreeRange: {
      start: 10,
      end: 14.99,
      absoluteStart: 40,
      absoluteEnd: 44.99
    },
    dateRange: {
      start: "April 30",
      end: "May 4",
      duration: "~5 days"
    },
    decan: {
      number: 2,
      name: "Second Decan (Fixed)",
      primaryRuler: "Venus",
      subRuler: "Mercury",
      modality: "Fixed"
    },
    influences: [
      {
        source: "Taurus",
        type: "Peak Taurus",
        planet: "Venus",
        percentage: 90,
        traits: ["Maximum sensuality", "Extreme loyalty", "Deep patience", "Unshakeable stability"]
      },
      {
        source: "Virgo",
        type: "Mercury Sub-ruler",
        planet: "Mercury",
        percentage: 10,
        traits: ["Analysis", "Perfectionism", "Service orientation", "Health consciousness"]
      }
    ],
    qualities: {
      speed: { level: 20, label: "Very Slow", icon: "⚡" },
      stubbornness: { level: 110, label: "EXTREME", icon: "🐂🐂🐂🐂🐂+" },
      riskTolerance: { level: 20, label: "Very Low", icon: "⚖️" },
      physicalEnergy: { level: 60, label: "Medium", icon: "⚡⚡⚡" },
      changeTolerance: { level: 20, label: "Very Low", icon: "🔄" },
      sensuality: { level: 100, label: "MAXIMUM", icon: "🌹🌹🌹🌹🌹" },
      loyalty: { level: 110, label: "Beyond Absolute", icon: "💎💎💎💎💎+" },
      patience: { level: 100, label: "Infinite", icon: "⏳⏳⏳⏳⏳" }
    },
    strengths: [
      "Unshakeable stability: The rock others lean on",
      "Peak sensuality: Experiences physical world intensely",
      "Infinite patience: Will wait decades if necessary",
      "Complete loyalty: Devotion is a core identity"
    ],
    shadows: [
      "Paralysis: Too afraid of wrong choice to make any choice",
      "Hoarding: Can't let go emotionally or physically",
      "Eternal grudges: Never forgets, rarely forgives",
      "Resistance to necessary change: Stays stuck until crisis"
    ],
    careerSignatures: [
      "Master Craftsperson (Woodworking, Pottery, Metalwork)",
      "Agriculture & Vineyards",
      "Banking & Wealth Management",
      "Culinary Arts (Chef, Baker)",
      "Opera Singer / Voice Actor"
    ],
    relationshipStyle: {
      pursuit: "SLOW - might take 5 years to make a move",
      commitmentSpeed: "3-5 years",
      passion: "Marathon not sprint - deeply sensual",
      conflict: "Avoidance + eternal grudge",
      jealousy: "Intense but silent"
    },
    famousExamples: [
      {
        name: "Audrey Hepburn",
        birthdate: "May 4",
        degree: "~13° Taurus",
        notes: "Timeless elegance, perfectionism, loyalty"
      }
    ],
    sabianSymbol: {
      degree: 13,
      symbol: "A porter carrying heavy baggage",
      interpretation: "Accepting the weight of responsibility with endurance; building strength through persistent effort over time."
    },
    nakshatra: {
      name: "Rohini",
      range: "10° - 23°20' Taurus (sidereal)",
      ruler: "Moon",
      symbol: "Ox Cart / Chariot",
      deity: "Brahma (Creator)",
      qualities: ["Fertile", "Creative", "Beautiful", "Magnetic", "Nurturing"]
    },
    colorTheme: {
      primary: "#2D5016",
      secondary: "#556B2F",
      gradient: "linear-gradient(135deg, #2D5016 0%, #556B2F 100%)"
    }
  },

  {
    id: 4,
    name: "The Master Craftsperson",
    archetype: "Perfection Through Repetition",
    degreeRange: {
      start: 15,
      end: 19.99,
      absoluteStart: 45,
      absoluteEnd: 49.99
    },
    dateRange: {
      start: "May 5",
      end: "May 9",
      duration: "~5 days"
    },
    decan: {
      number: 2,
      name: "Second Decan (Fixed)",
      primaryRuler: "Venus",
      subRuler: "Mercury",
      modality: "Fixed"
    },
    influences: [
      {
        source: "Taurus",
        type: "Core",
        planet: "Venus",
        percentage: 75,
        traits: ["Sensuality", "Loyalty", "Building instinct", "Patience"]
      },
      {
        source: "Virgo",
        type: "Mercury Peak",
        planet: "Mercury",
        percentage: 25,
        traits: ["Perfectionism", "Analysis", "Precision", "Service", "Health focus"]
      }
    ],
    qualities: {
      speed: { level: 20, label: "Very Slow", icon: "⚡" },
      stubbornness: { level: 100, label: "Very High", icon: "🐂🐂🐂🐂🐂" },
      riskTolerance: { level: 20, label: "Very Low", icon: "⚖️" },
      physicalEnergy: { level: 40, label: "Medium-Low", icon: "⚡⚡" },
      changeTolerance: { level: 20, label: "Very Low", icon: "🔄" },
      sensuality: { level: 80, label: "High", icon: "🌹🌹🌹🌹" },
      loyalty: { level: 100, label: "Absolute", icon: "💎💎💎💎💎" },
      patience: { level: 110, label: "Extraordinary", icon: "⏳⏳⏳⏳⏳+" }
    },
    strengths: [
      "Perfectionist eye: Sees flaws no one else notices",
      "Process mastery: Cares about HOW as much as outcome",
      "Dedicated practice: Will spend decades mastering one skill",
      "Service orientation: Builds useful, functional things"
    ],
    shadows: [
      "Perfectionism paralysis: Never finishing because never 'good enough'",
      "Excessive criticism: Of self and others",
      "Anxiety: Virgo adds worry to Taurus security concerns",
      "Process rigidity: 'Must be done THIS way' even when alternatives work"
    ],
    careerSignatures: [
      "Precision Crafts (Watchmaking, Instrument-making)",
      "Healthcare (Nursing, Physical Therapy, Nutrition)",
      "Editing & Proofreading",
      "Quality Control",
      "Research & Historical Preservation"
    ],
    relationshipStyle: {
      pursuit: "Methodical and careful",
      commitmentSpeed: "2-4 years",
      passion: "Refined sensuality with attention to detail",
      conflict: "Analyzes and worries rather than fighting",
      jealousy: "Controlled but present"
    },
    famousExamples: [
      {
        name: "Adele",
        birthdate: "May 5",
        degree: "~28° Taurus (late, but showing range)",
        notes: "Perfectionism in vocal craft"
      }
    ],
    sabianSymbol: {
      degree: 18,
      symbol: "A woman airing an old bag through a sunny window",
      interpretation: "Bringing hidden resources into light; renewal through exposure to fresh perspectives while maintaining what's valuable."
    },
    nakshatra: {
      name: "Rohini",
      range: "10° - 23°20' Taurus (sidereal)",
      ruler: "Moon",
      symbol: "Ox Cart / Chariot",
      deity: "Brahma (Creator)",
      qualities: ["Creative excellence", "Beautiful refinement", "Fertile imagination", "Nurturing perfection"]
    },
    colorTheme: {
      primary: "#6B8E23",
      secondary: "#8FBC8F",
      gradient: "linear-gradient(135deg, #6B8E23 0%, #8FBC8F 100%)"
    }
  },

  {
    id: 5,
    name: "The Ambitious Pragmatist",
    archetype: "The Empire Builder",
    degreeRange: {
      start: 20,
      end: 24.99,
      absoluteStart: 50,
      absoluteEnd: 54.99
    },
    dateRange: {
      start: "May 10",
      end: "May 14",
      duration: "~5 days"
    },
    decan: {
      number: 3,
      name: "Third Decan (Mutable)",
      primaryRuler: "Venus",
      subRuler: "Saturn",
      modality: "Mutable"
    },
    influences: [
      {
        source: "Taurus",
        type: "Core",
        planet: "Venus",
        percentage: 70,
        traits: ["Sensuality", "Loyalty", "Building instinct", "Material focus"]
      },
      {
        source: "Capricorn",
        type: "Saturn Sub-ruler",
        planet: "Saturn",
        percentage: 30,
        traits: ["Ambition", "Structure", "Discipline", "Legacy thinking", "Authority"]
      }
    ],
    qualities: {
      speed: { level: 40, label: "Slow but Steady", icon: "⚡⚡" },
      stubbornness: { level: 80, label: "High-Strategic", icon: "🐂🐂🐂🐂" },
      riskTolerance: { level: 40, label: "Calculated", icon: "⚖️⚖️" },
      physicalEnergy: { level: 60, label: "Sustainable", icon: "⚡⚡⚡" },
      changeTolerance: { level: 40, label: "Low-Medium", icon: "🔄🔄" },
      sensuality: { level: 60, label: "Moderate", icon: "🌹🌹🌹" },
      loyalty: { level: 100, label: "Absolute", icon: "💎💎💎💎💎" },
      patience: { level: 80, label: "Very High", icon: "⏳⏳⏳⏳" }
    },
    strengths: [
      "Legacy builder: Thinks in generations",
      "Strategic discipline: Saturn control + Venus beauty",
      "Authority comfortable: Natural leadership presence",
      "Long-game mastery: Plays chess while others play checkers"
    ],
    shadows: [
      "Emotional coldness: Saturn distance from feelings",
      "Workaholism: Building empire at expense of enjoying it",
      "Status obsession: Reputation over authentic connection",
      "Control needs: Must manage every aspect"
    ],
    careerSignatures: [
      "Business Ownership (Multi-generational)",
      "Real Estate Empires",
      "Finance & Investment Strategy",
      "Law (Contracts, Estate Planning)",
      "Academia & Politics"
    ],
    relationshipStyle: {
      pursuit: "Strategic - 'courts' rather than 'dates'",
      commitmentSpeed: "1-2 years",
      passion: "Present but scheduled around responsibilities",
      conflict: "Endures difficult relationships if they serve goals",
      jealousy: "About assets/partnership more than emotion"
    },
    famousExamples: [
      {
        name: "Tina Fey",
        birthdate: "May 18",
        degree: "~27° Taurus",
        notes: "Built comedy empire through discipline + sensibility"
      }
    ],
    sabianSymbol: {
      degree: 23,
      symbol: "A jewelry shop filled with valuable gems",
      interpretation: "Accumulated wealth through patient effort; understanding that true value requires time, protection, and proper presentation."
    },
    nakshatra: {
      name: "Mrigashira",
      range: "23°20' Taurus - 6°40' Gemini (sidereal)",
      ruler: "Mars",
      symbol: "Deer's Head",
      deity: "Soma (Moon God)",
      qualities: ["Searching", "Questing", "Gentle strength", "Creative intelligence"]
    },
    colorTheme: {
      primary: "#4A4A4A",
      secondary: "#696969",
      gradient: "linear-gradient(135deg, #4A4A4A 0%, #696969 100%)"
    }
  },

  {
    id: 6,
    name: "The Taurus-Gemini Cusp",
    archetype: "The Articulate Builder",
    degreeRange: {
      start: 25,
      end: 29.99,
      absoluteStart: 55,
      absoluteEnd: 59.99
    },
    dateRange: {
      start: "May 15",
      end: "May 20",
      duration: "~6 days"
    },
    decan: {
      number: 3,
      name: "Third Decan (Mutable)",
      primaryRuler: "Venus",
      subRuler: "Saturn",
      modality: "Mutable"
    },
    influences: [
      {
        source: "Taurus",
        type: "Core",
        planet: "Venus",
        percentage: 75,
        traits: ["Sensuality", "Loyalty", "Building instinct", "Material values"]
      },
      {
        source: "Gemini",
        type: "Cusp Anticipation",
        planet: "Mercury",
        percentage: 25,
        traits: ["Communication", "Mental agility", "Curiosity", "Adaptability", "Networking"]
      }
    ],
    qualities: {
      speed: { level: 60, label: "Medium", icon: "⚡⚡⚡" },
      stubbornness: { level: 60, label: "Medium-High", icon: "🐂🐂🐂" },
      riskTolerance: { level: 60, label: "Medium", icon: "⚖️⚖️⚖️" },
      physicalEnergy: { level: 60, label: "Medium", icon: "⚡⚡⚡" },
      changeTolerance: { level: 60, label: "Medium", icon: "🔄🔄🔄" },
      sensuality: { level: 60, label: "Medium-High", icon: "🌹🌹🌹" },
      loyalty: { level: 80, label: "High", icon: "💎💎💎💎" },
      patience: { level: 60, label: "Medium", icon: "⏳⏳⏳" }
    },
    strengths: [
      "Articulate about values: Can explain WHY beauty matters",
      "Networking savvy: Connections are assets",
      "Versatile: Multiple interests, not locked into one path",
      "Information collector: Knowledge as valuable as objects"
    ],
    shadows: [
      "Scattered: Too many interests, no mastery",
      "Superficial: Talking about values without embodying them",
      "Restless: Always looking for next thing",
      "Commitment-hesitant: Only Taurus who struggles to settle"
    ],
    careerSignatures: [
      "Communications & PR (Luxury Goods)",
      "Teaching & Education",
      "Sales (High-end Products)",
      "Writing & Content Creation",
      "Media (Podcasting, Radio, TV)"
    ],
    relationshipStyle: {
      pursuit: "Talks way into relationships - wit and conversation",
      commitmentSpeed: "1-2 years",
      passion: "Needs intellectual + physical connection",
      conflict: "Will actually discuss problems",
      jealousy: "More concerned with emotional than physical infidelity"
    },
    famousExamples: [
      {
        name: "Cher",
        birthdate: "May 20",
        degree: "~29° Taurus",
        notes: "Versatility, communication skills, enduring presence"
      }
    ],
    sabianSymbol: {
      degree: 28,
      symbol: "A woman pursued by mature romance",
      interpretation: "Recognition that true love requires maturity, patience, and the courage to be pursued by deeper connection rather than fleeting attraction."
    },
    nakshatra: {
      name: "Mrigashira",
      range: "23°20' Taurus - 6°40' Gemini (sidereal)",
      ruler: "Mars",
      symbol: "Deer's Head",
      deity: "Soma (Moon God)",
      qualities: ["Questing mind", "Gentle communication", "Searching intelligence", "Curious exploration"]
    },
    colorTheme: {
      primary: "#6A5ACD",
      secondary: "#9370DB",
      gradient: "linear-gradient(135deg, #6A5ACD 0%, #9370DB 100%)"
    }
  }
];

export default taurusZones;
