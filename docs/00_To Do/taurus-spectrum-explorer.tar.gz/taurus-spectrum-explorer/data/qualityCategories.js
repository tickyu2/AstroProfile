// Quality Categories Definition
// Defines all the qualities we measure across Taurus zones

export const qualityCategories = [
  {
    id: 'speed',
    label: 'Speed/Tempo',
    icon: '⚡',
    maxLevel: 5,
    description: 'How quickly you move through decisions, actions, and life changes',
    lowDescription: 'Moves at geological pace, never rushes',
    highDescription: 'Fast-moving, quick to act and decide'
  },
  {
    id: 'stubbornness',
    label: 'Stubbornness',
    icon: '🐂',
    maxLevel: 5,
    description: 'Resistance to changing course once committed',
    lowDescription: 'Flexible and adaptable when needed',
    highDescription: 'Immovable once mind is made up'
  },
  {
    id: 'riskTolerance',
    label: 'Risk Tolerance',
    icon: '⚖️',
    maxLevel: 5,
    description: 'Willingness to take chances without guaranteed outcomes',
    lowDescription: 'Needs certainty and guarantees',
    highDescription: 'Willing to take calculated risks'
  },
  {
    id: 'physicalEnergy',
    label: 'Physical Energy',
    icon: '⚡',
    maxLevel: 5,
    description: 'Base energy levels and physical vitality',
    lowDescription: 'Conserves energy, steady endurance',
    highDescription: 'High vitality with burst capacity'
  },
  {
    id: 'changeTolerance',
    label: 'Change Tolerance',
    icon: '🔄',
    maxLevel: 5,
    description: 'Ability to handle disruption and transition',
    lowDescription: 'Prefers stability and routine',
    highDescription: 'Can initiate and adapt to change'
  },
  {
    id: 'sensuality',
    label: 'Sensuality',
    icon: '🌹',
    maxLevel: 5,
    description: 'Connection to physical senses and embodied experience',
    lowDescription: 'Present but not defining',
    highDescription: 'Experiences world intensely through senses'
  },
  {
    id: 'loyalty',
    label: 'Loyalty',
    icon: '💎',
    maxLevel: 5,
    description: 'Depth of commitment to people, values, and causes',
    lowDescription: 'Committed but flexible',
    highDescription: 'Absolute devotion, unwavering'
  },
  {
    id: 'patience',
    label: 'Patience',
    icon: '⏳',
    maxLevel: 5,
    description: 'Ability to wait and persist over long timescales',
    lowDescription: 'Wants results relatively soon',
    highDescription: 'Will wait decades if necessary'
  }
];

// Quality comparison helper functions
export const getQualityColor = (level) => {
  if (level >= 80) return '#4CAF50'; // High - Green
  if (level >= 60) return '#8BC34A'; // Medium-High - Light Green
  if (level >= 40) return '#FFC107'; // Medium - Amber
  if (level >= 20) return '#FF9800'; // Low-Medium - Orange
  return '#F44336'; // Low - Red
};

export const getQualityLabel = (level) => {
  if (level >= 90) return 'Very High';
  if (level >= 70) return 'High';
  if (level >= 50) return 'Medium';
  if (level >= 30) return 'Low-Medium';
  return 'Low';
};

export const compareQualityAcrossZones = (zones, qualityId) => {
  const levels = zones.map(zone => zone.qualities[qualityId].level);
  const max = Math.max(...levels);
  const min = Math.min(...levels);
  const range = max - min;
  const avg = levels.reduce((a, b) => a + b, 0) / levels.length;
  
  return {
    range,
    max,
    min,
    avg: Math.round(avg),
    maxZone: zones.find(z => z.qualities[qualityId].level === max),
    minZone: zones.find(z => z.qualities[qualityId].level === min)
  };
};

export default qualityCategories;
