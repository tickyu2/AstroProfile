# Taurus Spectrum Explorer

## A Khan Academy for Constitutional Astrology

**Understanding the 30° Journey Through Taurus**

---

## 🌟 Overview

The Taurus Spectrum Explorer is an interactive educational tool that reveals why two people with the same Sun sign can express that energy completely differently. By dividing the 30 degrees of Taurus into 6 distinct zones, users can discover their exact constitutional flavor and understand the nuanced differences across the Taurus spectrum.

### Core Features

- **Interactive Degree Slider**: Explore any degree from 0-29.99° Taurus
- **6-Zone System**: Comprehensive breakdown of Taurus types
- **Three View Modes**:
  - Single View: Deep dive into one zone
  - Side-by-Side: Compare 2-3 zones
  - Full Matrix: All 6 zones in comprehensive table
- **Personal Insights**: Users can jump to their exact Sun degree
- **Educational Content**: Decan rulers, cusp influences, Sabian symbols, nakshatras
- **Quality Analysis**: 8 core qualities measured across zones

---

## 📁 Project Structure

```
taurus-spectrum-explorer/
├── components/
│   ├── TaurusSpectrumExplorer.jsx      # Main container
│   ├── TaurusSpectrumExplorer.css      # Main styles
│   ├── DegreeSlider.jsx                # Interactive slider
│   ├── DegreeSlider.css                # Slider styles
│   ├── SingleZoneView.jsx              # Detailed zone profile
│   ├── SingleZoneView.css              # Single view styles
│   ├── ViewModeSelector.jsx            # View mode toggle
│   ├── ViewModeSelector.css            # Selector styles
│   ├── ZoneSelector.jsx                # Multi-zone picker
│   ├── ZoneSelector.css                # Zone picker styles
│   ├── SideBySideView.jsx              # Comparison view (2-3 zones)
│   ├── SideBySideView.css              # Comparison styles
│   ├── FullMatrixView.jsx              # Matrix view (all 6)
│   └── FullMatrixView.css              # Matrix styles
├── data/
│   ├── taurusZones.js                  # Complete zone database
│   └── qualityCategories.js            # Quality definitions
├── utils/
│   └── zoneCalculations.js             # Helper functions
├── README.md                           # This file
└── package.json                        # Dependencies
```

---

## 🚀 Installation

### Prerequisites

- Node.js 16+ 
- npm or yarn
- React 18+

### Setup

```bash
# Clone or copy the taurus-spectrum-explorer directory
cd taurus-spectrum-explorer

# Install dependencies
npm install

# Start development server
npm start
```

---

## 💻 Usage

### Basic Integration

```jsx
import TaurusSpectrumExplorer from './components/TaurusSpectrumExplorer';

function App() {
  return (
    <TaurusSpectrumExplorer
      userDegree={2.19}           // User's Taurus Sun degree (optional)
      userName="Ticky"             // User's name (optional)
    />
  );
}
```

### Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `userDegree` | number | null | User's exact Taurus Sun degree (0-29.99) |
| userName` | string | null | User's name for personalization |

---

## 📊 The 6 Taurus Zones

### Zone 1: The Aries-Taurus Cusp (0-4.99°)
**"The Warrior Who Plants Gardens"**
- **Dates**: April 20-24
- **Influence**: 75% Taurus, 25% Aries
- **Key Traits**: High initiative, fast tempo, action-oriented
- **Career**: Entrepreneurs, athletes, leaders

### Zone 2: The Pioneering Builder (5-9.99°)
**"The Architect of Empires"**
- **Dates**: April 25-29
- **Influence**: 100% Pure Venus (1st Decan)
- **Key Traits**: Strong aesthetics, building instinct
- **Career**: Architects, designers, real estate

### Zone 3: The Quintessential Bull (10-14.99°)
**"The Immovable Force of Nature"**
- **Dates**: April 30 - May 4
- **Influence**: Peak Taurus + Mercury sub-ruler
- **Key Traits**: Maximum sensuality, extreme patience
- **Career**: Master craftspeople, agriculture, banking

### Zone 4: The Master Craftsperson (15-19.99°)
**"Perfection Through Repetition"**
- **Dates**: May 5-9
- **Influence**: Mercury/Virgo peak
- **Key Traits**: Perfectionism, precision, analysis
- **Career**: Precision crafts, healthcare, quality control

### Zone 5: The Ambitious Pragmatist (20-24.99°)
**"The Empire Builder"**
- **Dates**: May 10-14
- **Influence**: Saturn/Capricorn
- **Key Traits**: Ambition, structure, legacy thinking
- **Career**: Business empires, finance, law, politics

### Zone 6: The Taurus-Gemini Cusp (25-29.99°)
**"The Articulate Builder"**
- **Dates**: May 15-20
- **Influence**: 75% Taurus, 25% Gemini
- **Key Traits**: Communication, adaptability, mental agility
- **Career**: Communications, teaching, sales, media

---

## 🎨 Customization

### Color Themes

Each zone has its own color palette defined in `taurusZones.js`:

```javascript
colorTheme: {
  primary: "#FF6B35",    // Main zone color
  secondary: "#8B4513",  // Accent color
  gradient: "linear-gradient(135deg, #FF6B35 0%, #8B4513 100%)"
}
```

### Quality Categories

8 qualities are measured across all zones (defined in `qualityCategories.js`):

1. **Speed/Tempo** - Decision-making pace
2. **Stubbornness** - Resistance to change
3. **Risk Tolerance** - Willingness to take chances
4. **Physical Energy** - Base vitality levels
5. **Change Tolerance** - Adaptability
6. **Sensuality** - Physical world connection
7. **Loyalty** - Commitment depth
8. **Patience** - Long-term perspective

---

## 🔧 Advanced Features

### Zone Calculation

```javascript
import { getUserZoneInfo } from './utils/zoneCalculations';

const userInfo = getUserZoneInfo(2.19); // Your Taurus degree
console.log(userInfo.zone.name);         // "The Aries-Taurus Cusp"
console.log(userInfo.cuspInfluences);    // { aries: 25, taurus: 75, gemini: 0 }
```

### Compatibility Analysis

```javascript
import { calculateTaurusCompatibility } from './utils/zoneCalculations';

const compatibility = calculateTaurusCompatibility(2.19, 15.5);
console.log(compatibility.compatibilityScore); // 72
console.log(compatibility.interpretation);     // "Good compatibility..."
```

---

## 📚 Educational Methodology

### The Pure Gold Method

This tool follows the **Pure Gold Method** philosophy:

1. **Complete Transparency**: Show all calculations and reasoning
2. **Mathematical Precision**: Exact degree placements matter
3. **Soul Agency Respect**: Empower users to understand themselves
4. **Cathedral Quality**: Built to last centuries

### Decan System

- **First Decan (0-9.99°)**: Venus/Venus - Cardinal/Initiating
- **Second Decan (10-19.99°)**: Venus/Mercury - Fixed/Stabilizing
- **Third Decan (20-29.99°)**: Venus/Saturn - Mutable/Transitioning

### Cusp Influence Formula

```
Aries Influence (0-5°) = (5 - degree) / 5 × 25%
Gemini Influence (25-30°) = (degree - 25) / 5 × 25%
```

---

## 🎯 Integration with GENESIS

This tool is designed as a module for the **GENESIS AstroProfile** platform:

### Integration Points

1. **From AstroProfile**: "Explore Your Sun Degree" button
2. **From Tropical Seasons**: Click Taurus → Opens Spectrum Explorer
3. **From Compatibility**: Compare Sun degree compatibility

### Data Flow

```
User Profile → Birth Data → Sun Calculation → Taurus Degree → Spectrum Explorer
```

---

## 🔬 Technical Details

### Performance Optimization

- **Lazy Loading**: Components load on demand
- **Memoization**: Calculations cached with useMemo
- **Virtual Scrolling**: For large data tables
- **Debounced Slider**: Smooth 60fps sliding

### Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers (iOS Safari, Chrome Mobile)

### Accessibility

- **ARIA labels**: All interactive elements
- **Keyboard navigation**: Full tab support
- **Screen reader**: Semantic HTML throughout
- **Color contrast**: WCAG AA compliant

---

## 📈 Future Expansion

Once Taurus is complete, replicate for all 12 signs:

```
Taurus Template → 
  ♈ Aries (Cardinal Fire)
  ♊ Gemini (Mutable Air)
  ♋ Cancer (Cardinal Water)
  ♌ Leo (Fixed Fire)
  ♍ Virgo (Mutable Earth)
  ♎ Libra (Cardinal Air)
  ♏ Scorpio (Fixed Water)
  ♐ Sagittarius (Mutable Fire)
  ♑ Capricorn (Cardinal Earth)
  ♒ Aquarius (Fixed Air)
  ♓ Pisces (Mutable Water)
```

---

## 🤝 Contributing

### Adding New Educational Content

1. Update zone data in `taurusZones.js`
2. Add new insights to description functions
3. Update comparison logic in view components

### Adding New Quality Categories

1. Define in `qualityCategories.js`
2. Add measurements to each zone
3. Update visualization components

---

## 📖 References

### Astrological Foundations

- Traditional decan system (Ptolemaic)
- Modern psychological astrology
- Vedic nakshatra correlations
- Sabian symbols (Marc Edmund Jones)

### Technical References

- React 18 documentation
- CSS Grid and Flexbox guides
- Accessibility guidelines (WCAG)

---

## 📝 License

This educational tool is part of the **GENESIS** platform.

**Philosophy**: "Don't date blind. Date soul-first."

---

## 🙏 Acknowledgments

**Created with** 🔥 **by**:
- **Ticky** (Pure Gold Dragon) - Vision & Fire
- **Claude** (Winter Wood Lighthouse) - Strategy & Implementation
- **The Cosmic Renaissance** - For making this possible

---

## 💬 Support

For questions, suggestions, or bug reports:
- Check the `EDUCATIONAL_GUIDE.md` for teaching methodology
- Review `DATA_STRUCTURE.md` for schema documentation
- See `EXPANSION_ROADMAP.md` for future plans

---

**May every Taurus find their exact flavor in the spectrum** ♉✨

**The Builder Who Doesn't Wait for Permission** 🔥🌹
