// Quality Categories for Gemini
// Includes Mental Energy and Curiosity metrics specific to Air signs

export const qualityCategories = [
  {
    id: 'speed',
    label: 'Speed/Tempo',
    icon: '⚡',
    maxLevel: 5,
    description: 'Mental processing speed and decision-making pace',
    lowDescription: 'Thoughtful deliberation',
    highDescription: 'Lightning-fast thinking (classic Gemini)'
  },
  {
    id: 'stubbornness',
    label: 'Stubbornness',
    icon: '💭',
    maxLevel: 5,
    description: 'Mental fixedness - very low for Gemini',
    lowDescription: 'Extremely flexible, adaptable thinker',
    highDescription: 'Can stick to ideas when needed'
  },
  {
    id: 'riskTolerance',
    label: 'Risk Tolerance',
    icon: '⚖️',
    maxLevel: 5,
    description: 'Willingness to explore unknown mental territory',
    lowDescription: 'Prefers proven information',
    highDescription: 'Explores radical new ideas fearlessly'
  },
  {
    id: 'mentalEnergy',
    label: 'Mental Energy',
    icon: '🧠',
    maxLevel: 5,
    description: 'Cognitive stamina and information processing capacity - Gemini signature',
    lowDescription: 'Focused mental energy',
    highDescription: 'Never-stopping thought engine'
  },
  {
    id: 'changeTolerance',
    label: 'Change Tolerance',
    icon: '🔄',
    maxLevel: 5,
    description: 'Adaptability to new information - Gemini excels',
    lowDescription: 'Prefers mental consistency',
    highDescription: 'Thrives on new information and perspectives'
  },
  {
    id: 'curiosity',
    label: 'Curiosity',
    icon: '🔍',
    maxLevel: 5,
    description: 'Drive to learn and explore - THE Gemini constant',
    lowDescription: 'Curious about practical matters',
    highDescription: 'Must know everything about everything'
  },
  {
    id: 'communication',
    label: 'Communication',
    icon: '💬',
    maxLevel: 5,
    description: 'Need and ability to express and connect - core Gemini trait',
    lowDescription: 'Communicates when necessary',
    highDescription: 'Constant expression, verbal mastery'
  },
  {
    id: 'patience',
    label: 'Patience',
    icon: '⏳',
    maxLevel: 5,
    description: 'Ability to wait and persist - varies in Gemini',
    lowDescription: 'Restless, needs constant stimulation',
    highDescription: 'Can focus deeply when interested'
  }
];

export default qualityCategories;
