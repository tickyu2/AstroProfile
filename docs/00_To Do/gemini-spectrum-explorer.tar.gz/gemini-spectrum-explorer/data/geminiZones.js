// Gemini Zone Database
// Complete data structure for all 6 zones across the 30° Gemini spectrum

export const geminiZones = [
  {
    id: 1,
    name: "The Taurus-Gemini Cusp",
    archetype: "The Articulate Builder",
    degreeRange: {
      start: 0,
      end: 4.99,
      absoluteStart: 60,
      absoluteEnd: 64.99
    },
    dateRange: {
      start: "May 21",
      end: "May 25",
      duration: "~5 days"
    },
    decan: {
      number: 1,
      name: "First Decan (Mutable)",
      primaryRuler: "Mercury",
      subRuler: "Mercury",
      modality: "Mutable"
    },
    influences: [
      {
        source: "Taurus",
        type: "Cusp Bleed",
        planet: "Venus",
        percentage: 25,
        traits: ["Stability", "Sensuality", "Practicality", "Material focus", "Loyalty"]
      },
      {
        source: "Gemini",
        type: "Core",
        planet: "Mercury",
        percentage: 75,
        traits: ["Communication", "Curiosity", "Mental agility", "Versatility", "Social connection"]
      }
    ],
    qualities: {
      speed: { level: 70, label: "Fast", icon: "⚡⚡⚡⚡" },
      stubbornness: { level: 40, label: "Low-Medium", icon: "💭💭" },
      riskTolerance: { level: 60, label: "Medium-High", icon: "⚖️⚖️⚖️" },
      mentalEnergy: { level: 80, label: "High", icon: "🧠🧠🧠🧠" },
      changeTolerance: { level: 70, label: "High", icon: "🔄🔄🔄🔄" },
      curiosity: { level: 85, label: "Very High", icon: "🔍🔍🔍🔍" },
      communication: { level: 80, label: "High", icon: "💬💬💬💬" },
      patience: { level: 50, label: "Medium", icon: "⏳⏳⏳" }
    },
    strengths: [
      "Grounded communication: Practical ideas expressed clearly",
      "Building with words: Creates lasting value through communication",
      "Stable curiosity: Explores but with commitment",
      "Sensual intellect: Appreciates beauty AND ideas"
    ],
    shadows: [
      "Stuck in analysis: Too practical to take mental leaps",
      "Slow communicator: Overthinks before speaking",
      "Materialistic curiosity: Only explores what has value",
      "Commitment-heavy: Stays in conversations too long"
    ],
    careerSignatures: [
      "Technical Writing",
      "Architecture (Design + Communication)",
      "Real Estate (Sales/Marketing)",
      "Financial Analysis with Client Relations",
      "Teaching Practical Skills"
    ],
    relationshipStyle: {
      pursuit: "Talks way in with practical charm",
      commitmentSpeed: "Medium - needs mental + physical connection",
      passion: "Intellectual foreplay important",
      conflict: "Discusses but can be stubborn",
      jealousy: "Moderate - more about intellectual intimacy"
    },
    famousExamples: [
      {
        name: "Lauryn Hill",
        birthdate: "May 26",
        degree: "~5° Gemini (Zone 2 but shows cusp)",
        notes: "Practical artistry meets verbal mastery"
      }
    ],
    sabianSymbol: {
      degree: 1,
      symbol: "A glass-bottomed boat in still water",
      interpretation: "Seeing depth clearly through transparent communication. The transition from Taurus earth to Gemini air creates clear windows of perception."
    },
    nakshatra: {
      name: "Mrigashira",
      range: "23°20' Taurus - 6°40' Gemini (sidereal)",
      ruler: "Mars",
      symbol: "Deer's Head",
      deity: "Soma",
      qualities: ["Searching mind", "Gentle communication", "Curious exploration"]
    },
    colorTheme: {
      primary: "#FFB300",
      secondary: "#66BB6A",
      gradient: "linear-gradient(135deg, #FFB300 0%, #66BB6A 100%)"
    }
  },

  {
    id: 2,
    name: "The Pure Communicator",
    archetype: "The Messenger",
    degreeRange: {
      start: 5,
      end: 9.99,
      absoluteStart: 65,
      absoluteEnd: 69.99
    },
    dateRange: {
      start: "May 26",
      end: "May 30",
      duration: "~5 days"
    },
    decan: {
      number: 1,
      name: "First Decan (Mutable)",
      primaryRuler: "Mercury",
      subRuler: "Mercury",
      modality: "Mutable"
    },
    influences: [
      {
        source: "Gemini",
        type: "Pure Mercury",
        planet: "Mercury",
        percentage: 100,
        traits: ["Maximum mental agility", "Pure communication", "Extreme versatility", "Information mastery", "Social brilliance"]
      }
    ],
    qualities: {
      speed: { level: 100, label: "Maximum", icon: "⚡⚡⚡⚡⚡" },
      stubbornness: { level: 20, label: "Very Low", icon: "💭" },
      riskTolerance: { level: 70, label: "High", icon: "⚖️⚖️⚖️⚖️" },
      mentalEnergy: { level: 100, label: "Maximum", icon: "🧠🧠🧠🧠🧠" },
      changeTolerance: { level: 100, label: "Maximum", icon: "🔄🔄🔄🔄🔄" },
      curiosity: { level: 100, label: "Maximum", icon: "🔍🔍🔍🔍🔍" },
      communication: { level: 100, label: "Maximum", icon: "💬💬💬💬💬" },
      patience: { level: 20, label: "Low", icon: "⏳⏳" }
    },
    strengths: [
      "Information mastery: Absorbs and shares knowledge instantly",
      "Verbal brilliance: Words flow effortlessly and effectively",
      "Social genius: Connects anyone with anyone",
      "Mental flexibility: Adapts thinking instantly"
    ],
    shadows: [
      "Scattered focus: Too many interests, no depth",
      "Superficial knowledge: Knows a little about everything, mastery of nothing",
      "Commitment-phobic: Can't stick to one thing",
      "Anxious overthinking: Mind never stops spinning"
    ],
    careerSignatures: [
      "Journalism (News, Reporting)",
      "Social Media Management",
      "Public Relations",
      "Stand-up Comedy",
      "Telecommunications"
    ],
    relationshipStyle: {
      pursuit: "Witty banter and mental stimulation",
      commitmentSpeed: "Very slow - fears being trapped",
      passion: "Cerebral and playful",
      conflict: "Talks way out or ghosts",
      jealousy: "Low - needs freedom"
    },
    famousExamples: [
      {
        name: "Kendrick Lamar",
        birthdate: "June 17",
        degree: "~26° Gemini (shows pure Gemini in different zone)",
        notes: "Verbal mastery, information weaving"
      }
    ],
    sabianSymbol: {
      degree: 8,
      symbol: "Aroused strikers",
      interpretation: "Communication that sparks movement. Pure Gemini's power to mobilize through words and ideas."
    },
    nakshatra: {
      name: "Mrigashira",
      range: "23°20' Taurus - 6°40' Gemini (sidereal)",
      ruler: "Mars",
      symbol: "Deer's Head",
      deity: "Soma",
      qualities: ["Peak mental agility", "Restless seeking", "Swift communication"]
    },
    colorTheme: {
      primary: "#4CAF50",
      secondary: "#8BC34A",
      gradient: "linear-gradient(135deg, #4CAF50 0%, #8BC34A 100%)"
    }
  },

  {
    id: 3,
    name: "The Balanced Thinker",
    archetype: "The Diplomat",
    degreeRange: {
      start: 10,
      end: 14.99,
      absoluteStart: 70,
      absoluteEnd: 74.99
    },
    dateRange: {
      start: "May 31",
      end: "June 4",
      duration: "~5 days"
    },
    decan: {
      number: 2,
      name: "Second Decan (Cardinal)",
      primaryRuler: "Mercury",
      subRuler: "Venus",
      modality: "Cardinal"
    },
    influences: [
      {
        source: "Gemini",
        type: "Core",
        planet: "Mercury",
        percentage: 70,
        traits: ["Communication", "Versatility", "Mental agility"]
      },
      {
        source: "Libra",
        type: "Venus Sub-ruler",
        planet: "Venus",
        percentage: 30,
        traits: ["Harmony", "Diplomacy", "Aesthetics", "Balance", "Relationship focus"]
      }
    ],
    qualities: {
      speed: { level: 85, label: "Very Fast", icon: "⚡⚡⚡⚡" },
      stubbornness: { level: 30, label: "Low", icon: "💭💭" },
      riskTolerance: { level: 65, label: "Medium-High", icon: "⚖️⚖️⚖️" },
      mentalEnergy: { level: 90, label: "Very High", icon: "🧠🧠🧠🧠🧠" },
      changeTolerance: { level: 85, label: "Very High", icon: "🔄🔄🔄🔄" },
      curiosity: { level: 90, label: "Very High", icon: "🔍🔍🔍🔍🔍" },
      communication: { level: 95, label: "Very High", icon: "💬💬💬💬💬" },
      patience: { level: 40, label: "Low-Medium", icon: "⏳⏳⏳" }
    },
    strengths: [
      "Diplomatic communication: Finds win-win through words",
      "Aesthetic intelligence: Appreciates beauty of ideas",
      "Relationship connector: Brings people together harmoniously",
      "Balanced curiosity: Explores with grace"
    ],
    shadows: [
      "People-pleasing: Says what others want to hear",
      "Indecisive communication: Can't pick a side",
      "Superficial harmony: Avoids necessary conflict",
      "Scattered aesthetics: Too many pretty ideas, no focus"
    ],
    careerSignatures: [
      "Diplomacy/Foreign Service",
      "Marriage Counseling",
      "Art Curation/Criticism",
      "Fashion Journalism",
      "Mediation/Arbitration"
    ],
    relationshipStyle: {
      pursuit: "Charming conversation and aesthetic appeal",
      commitmentSpeed: "Medium - weighs all options",
      passion: "Romantic and mentally stimulating",
      conflict: "Mediates, seeks compromise",
      jealousy: "Moderate - wants harmony more than possession"
    },
    famousExamples: [
      {
        name: "Angelina Jolie",
        birthdate: "June 4",
        degree: "~13° Gemini",
        notes: "Diplomatic humanitarian, balanced communication"
      }
    ],
    sabianSymbol: {
      degree: 13,
      symbol: "A great musician at his piano",
      interpretation: "Harmony through skilled expression. The diplomat plays the keys of communication to create beautiful understanding."
    },
    nakshatra: {
      name: "Ardra",
      range: "6°40' - 20° Gemini (sidereal)",
      ruler: "Rahu (North Node)",
      symbol: "Teardrop",
      deity: "Rudra (Storm God)",
      qualities: ["Intellectual storms", "Transformative communication", "Balanced chaos"]
    },
    colorTheme: {
      primary: "#009688",
      secondary: "#80CBC4",
      gradient: "linear-gradient(135deg, #009688 0%, #80CBC4 100%)"
    }
  },

  {
    id: 4,
    name: "The Strategic Networker",
    archetype: "The Connector",
    degreeRange: {
      start: 15,
      end: 19.99,
      absoluteStart: 75,
      absoluteEnd: 79.99
    },
    dateRange: {
      start: "June 5",
      end: "June 9",
      duration: "~5 days"
    },
    decan: {
      number: 2,
      name: "Second Decan (Cardinal)",
      primaryRuler: "Mercury",
      subRuler: "Venus",
      modality: "Cardinal"
    },
    influences: [
      {
        source: "Gemini",
        type: "Core",
        planet: "Mercury",
        percentage: 65,
        traits: ["Communication", "Networking", "Information"]
      },
      {
        source: "Libra",
        type: "Venus Peak",
        planet: "Venus",
        percentage: 35,
        traits: ["Strategic relationships", "Social intelligence", "Partnership mastery"]
      }
    ],
    qualities: {
      speed: { level: 80, label: "Fast", icon: "⚡⚡⚡⚡" },
      stubbornness: { level: 35, label: "Low-Medium", icon: "💭💭" },
      riskTolerance: { level: 60, label: "Medium-High", icon: "⚖️⚖️⚖️" },
      mentalEnergy: { level: 85, label: "Very High", icon: "🧠🧠🧠🧠" },
      changeTolerance: { level: 80, label: "High", icon: "🔄🔄🔄🔄" },
      curiosity: { level: 85, label: "Very High", icon: "🔍🔍🔍🔍" },
      communication: { level: 90, label: "Very High", icon: "💬💬💬💬💬" },
      patience: { level: 45, label: "Medium", icon: "⏳⏳⏳" }
    },
    strengths: [
      "Strategic networking: Knows who to connect with whom",
      "Relationship intelligence: Reads social dynamics expertly",
      "Partnership builder: Creates win-win collaborations",
      "Information broker: Trades knowledge strategically"
    ],
    shadows: [
      "Manipulative networking: Uses people as tools",
      "Superficial connections: Knows everyone, close to no one",
      "Strategic deception: Tells different people different things",
      "Relationship addiction: Needs constant social validation"
    ],
    careerSignatures: [
      "Business Development",
      "Strategic Partnerships",
      "Talent Agency",
      "Political Consulting",
      "Professional Networking"
    ],
    relationshipStyle: {
      pursuit: "Strategic courtship through social circles",
      commitmentSpeed: "Medium-slow - assesses strategic fit",
      passion: "Intellectually calculated",
      conflict: "Manages through social maneuvering",
      jealousy: "Low but strategic about partnerships"
    },
    famousExamples: [
      {
        name: "Kanye West",
        birthdate: "June 8",
        degree: "~17° Gemini",
        notes: "Strategic networking, partnership mastery"
      }
    ],
    sabianSymbol: {
      degree: 18,
      symbol: "Two Chinese men talking Chinese",
      interpretation: "Specialized communication within networks. The ability to speak the language of specific communities strategically."
    },
    nakshatra: {
      name: "Ardra",
      range: "6°40' - 20° Gemini (sidereal)",
      ruler: "Rahu",
      symbol: "Teardrop",
      deity: "Rudra",
      qualities: ["Strategic intellect", "Network mastery", "Relationship calculation"]
    },
    colorTheme: {
      primary: "#00BCD4",
      secondary: "#4DD0E1",
      gradient: "linear-gradient(135deg, #00BCD4 0%, #4DD0E1 100%)"
    }
  },

  {
    id: 5,
    name: "The Philosophical Explorer",
    archetype: "The Teacher-Learner",
    degreeRange: {
      start: 20,
      end: 24.99,
      absoluteStart: 80,
      absoluteEnd: 84.99
    },
    dateRange: {
      start: "June 10",
      end: "June 14",
      duration: "~5 days"
    },
    decan: {
      number: 3,
      name: "Third Decan (Fixed)",
      primaryRuler: "Mercury",
      subRuler: "Uranus",
      modality: "Fixed"
    },
    influences: [
      {
        source: "Gemini",
        type: "Core",
        planet: "Mercury",
        percentage: 65,
        traits: ["Communication", "Curiosity", "Mental agility"]
      },
      {
        source: "Aquarius",
        type: "Uranus Sub-ruler",
        planet: "Uranus",
        percentage: 35,
        traits: ["Innovation", "Humanitarian focus", "Abstract thinking", "Future orientation"]
      }
    ],
    qualities: {
      speed: { level: 90, label: "Very Fast", icon: "⚡⚡⚡⚡⚡" },
      stubbornness: { level: 25, label: "Low", icon: "💭" },
      riskTolerance: { level: 80, label: "High", icon: "⚖️⚖️⚖️⚖️" },
      mentalEnergy: { level: 95, label: "Very High", icon: "🧠🧠🧠🧠🧠" },
      changeTolerance: { level: 95, label: "Very High", icon: "🔄🔄🔄🔄🔄" },
      curiosity: { level: 95, label: "Very High", icon: "🔍🔍🔍🔍🔍" },
      communication: { level: 90, label: "Very High", icon: "💬💬💬💬💬" },
      patience: { level: 30, label: "Low", icon: "⏳⏳" }
    },
    strengths: [
      "Innovative thinking: Sees future possibilities others miss",
      "Teaching through curiosity: Educates by asking questions",
      "Humanitarian communication: Uses words to improve humanity",
      "Abstract intelligence: Connects ideas across vast conceptual distances"
    ],
    shadows: [
      "Detached intellect: Too abstract, loses human connection",
      "Chaotic teaching: Confuses others with non-linear thinking",
      "Revolutionary impatience: Frustrated with slow learners",
      "Information overload: Overwhelms with too many ideas"
    ],
    careerSignatures: [
      "Technology Innovation",
      "Science Communication",
      "Educational Reform",
      "Think Tanks",
      "Futurism/Forecasting"
    ],
    relationshipStyle: {
      pursuit: "Intellectual fascination and quirky connection",
      commitmentSpeed: "Slow - needs mental freedom",
      passion: "Experimental and unconventional",
      conflict: "Detaches emotionally, discusses rationally",
      jealousy: "Very low - values independence"
    },
    famousExamples: [
      {
        name: "Donald Trump",
        birthdate: "June 14",
        degree: "~22° Gemini",
        notes: "Unconventional communication, innovative (controversial) thinking"
      }
    ],
    sabianSymbol: {
      degree: 23,
      symbol: "Three fledglings in a nest high in a tree",
      interpretation: "New ideas being nurtured before flight. The philosophical explorer protects emerging concepts before sharing them with the world."
    },
    nakshatra: {
      name: "Punarvasu",
      range: "20° Gemini - 3°20' Cancer (sidereal)",
      ruler: "Jupiter",
      symbol: "Bow and Quiver",
      deity: "Aditi (Mother of Gods)",
      qualities: ["Philosophical communication", "Teaching wisdom", "Cyclical learning"]
    },
    colorTheme: {
      primary: "#03A9F4",
      secondary: "#81D4FA",
      gradient: "linear-gradient(135deg, #03A9F4 0%, #81D4FA 100%)"
    }
  },

  {
    id: 6,
    name: "The Gemini-Cancer Cusp",
    archetype: "The Nurturing Communicator",
    degreeRange: {
      start: 25,
      end: 29.99,
      absoluteStart: 85,
      absoluteEnd: 89.99
    },
    dateRange: {
      start: "June 15",
      end: "June 20",
      duration: "~6 days"
    },
    decan: {
      number: 3,
      name: "Third Decan (Fixed)",
      primaryRuler: "Mercury",
      subRuler: "Uranus",
      modality: "Fixed"
    },
    influences: [
      {
        source: "Gemini",
        type: "Core",
        planet: "Mercury",
        percentage: 75,
        traits: ["Communication", "Curiosity", "Mental agility"]
      },
      {
        source: "Cancer",
        type: "Cusp Anticipation",
        planet: "Moon",
        percentage: 25,
        traits: ["Emotional intelligence", "Nurturing", "Memory", "Protection", "Family focus"]
      }
    ],
    qualities: {
      speed: { level: 75, label: "Fast", icon: "⚡⚡⚡⚡" },
      stubbornness: { level: 45, label: "Medium", icon: "💭💭💭" },
      riskTolerance: { level: 55, label: "Medium", icon: "⚖️⚖️⚖️" },
      mentalEnergy: { level: 80, label: "High", icon: "🧠🧠🧠🧠" },
      changeTolerance: { level: 70, label: "High", icon: "🔄🔄🔄🔄" },
      curiosity: { level: 80, label: "High", icon: "🔍🔍🔍🔍" },
      communication: { level: 85, label: "Very High", icon: "💬💬💬💬" },
      patience: { level: 55, label: "Medium", icon: "⏳⏳⏳" }
    },
    strengths: [
      "Emotional communication: Speaks to hearts AND minds",
      "Nurturing curiosity: Helps others learn and grow",
      "Memory keeper: Preserves and shares stories",
      "Protective intelligence: Uses words to create safety"
    ],
    shadows: [
      "Emotionally manipulative: Uses feelings to control conversation",
      "Moody communication: Speaks differently based on emotional state",
      "Clingy curiosity: Won't let go of people/topics",
      "Defensive intellect: Takes intellectual challenges personally"
    ],
    careerSignatures: [
      "Family Therapy",
      "Children's Education",
      "Memoir Writing",
      "Genealogy/History",
      "Food Writing/Criticism"
    ],
    relationshipStyle: {
      pursuit: "Emotionally intelligent conversation",
      commitmentSpeed: "Medium - needs emotional + mental bond",
      passion: "Nurturing and mentally stimulating",
      conflict: "Emotionally reactive but wants to talk it out",
      jealousy: "Medium-high - protective of emotional bonds"
    },
    famousExamples: [
      {
        name: "Nicole Kidman",
        birthdate: "June 20",
        degree: "~29° Gemini",
        notes: "Emotionally intelligent communication"
      }
    ],
    sabianSymbol: {
      degree: 28,
      symbol: "A man declared bankrupt",
      interpretation: "Letting go of old mental patterns to embrace emotional truth. The transition to Cancer teaches Gemini to feel, not just think."
    },
    nakshatra: {
      name: "Punarvasu",
      range: "20° Gemini - 3°20' Cancer (sidereal)",
      ruler: "Jupiter",
      symbol: "Bow and Quiver",
      deity: "Aditi",
      qualities: ["Nurturing wisdom", "Emotional intelligence", "Protective communication"]
    },
    colorTheme: {
      primary: "#29B6F6",
      secondary: "#80DEEA",
      gradient: "linear-gradient(135deg, #29B6F6 0%, #80DEEA 100%)"
    }
  }
];

export default geminiZones;
