# Gemini Spectrum Explorer 💬

## Understanding the 30° Journey Through the Twins

**"I Think, Therefore I Connect" - Exploring Gemini Constitutional Diversity**

---

## 🎯 Overview

The Gemini Spectrum Explorer reveals why two Gemini Suns communicate in completely different ways. By dividing the 30 degrees of Gemini into 6 distinct zones, users discover their exact constitutional flavor of air.

### Key Principle

**Gemini is the COMMUNICATOR sign** - Master of information, connection, and mental agility. But WHERE in Gemini you're born determines HOW you think and connect.

---

## 💬 The 6 Gemini Types

| Zone | Degrees | Name | Influence | Core Energy |
|------|---------|------|-----------|-------------|
| **1** | 0-4.99° | **Taurus-Gemini Cusp** | 25% Venus | Articulate Builder |
| **2** | 5-9.99° | **Pure Communicator** | 100% Mercury | The Messenger |
| **3** | 10-14.99° | **Balanced Thinker** | 30% Venus | The Diplomat |
| **4** | 15-19.99° | **Strategic Networker** | 35% Venus | The Connector |
| **5** | 20-24.99° | **Philosophical Explorer** | 35% Uranus | The Teacher-Learner |
| **6** | 25-29.99° | **Gemini-Cancer Cusp** | 25% Moon | Nurturing Communicator |

---

## 🌬️ Core Gemini Characteristics

### What ALL Gemini Share (Regardless of Zone)

✓ **High Mental Energy** (80-100%) - Minds never stop  
✓ **High Curiosity** (80-100%) - Must know everything  
✓ **High Communication** (80-100%) - Words flow naturally  
✓ **High Change Tolerance** (70-100%) - Adaptability masters  
✓ **Low Stubbornness** (20-45%) - Flexible thinkers  

### What DIFFERS Across Zones

**Zone 1 (Taurus Cusp):**
- More practical, grounded
- Communicates about tangible value
- 50% patience (highest for Gemini!)

**Zone 2 (Pure Mercury):**
- Maximum everything (100% speed, curiosity, communication)
- Pure messenger essence
- 20% patience (classic scattered Gemini)

**Zone 3-4 (Libra Influence):**
- Adds diplomacy, harmony, relationships
- Strategic communication (90-95%)
- Diplomat/Connector archetypes

**Zone 5 (Aquarius Influence):**
- Philosophical, innovative
- Humanitarian communication
- 30% patience (impatient with slow thinkers)

**Zone 6 (Cancer Cusp):**
- Emotional, nurturing
- Memory keeper
- 55% patience (will nurture others' learning)

---

## 🎨 The Gemini Quality Spectrum

### New Quality: Mental Energy 🧠

**Unique to Air Signs** - Measures cognitive stamina, thought speed, information processing

- **Zone 1**: 80% - Grounded but active mind
- **Zone 2**: 100% - Never-stopping mental engine
- **Zone 3**: 90% - Balanced high intelligence
- **Zone 4**: 85% - Strategic mental stamina
- **Zone 5**: 95% - Innovative thinking capacity
- **Zone 6**: 80% - Emotional + mental energy

### Communication Focus 💬

**THE defining Gemini trait** - All zones rate 80-100%

Gemini doesn't just like to talk—they NEED to communicate to process reality. Even Zone 1 (most practical Gemini) has 80% communication drive.

### Curiosity Emphasis 🔍

**Gemini must know EVERYTHING**

- Zone 2: 100% (maximum curiosity - Renaissance mind)
- Zone 5: 95% (philosophical exploration)
- Even Zone 6 (most focused Gemini): 80% (still curious about emotions)

Compare to Taurus:
- Taurus curiosity: Not primary quality (focus on stability)
- Gemini curiosity: 80-100% across all zones
- **Gemini = perpetual student of life**

---

## 🎨 Gemini Color Palette (Air Spectrum)

**Yellow-Green-Blue** - Representing communication, growth, and thought

| Zone | Primary | Secondary | Meaning |
|------|---------|-----------|---------|
| 1 | #FFB300 | #66BB6A | Yellow-Green (practical communication) |
| 2 | #4CAF50 | #8BC34A | Pure Green (flowing information) |
| 3 | #009688 | #80CBC4 | Teal (balanced harmony) |
| 4 | #00BCD4 | #4DD0E1 | Cyan (network connections) |
| 5 | #03A9F4 | #81D4FA | Sky Blue (philosophical thought) |
| 6 | #29B6F6 | #80DEEA | Ocean Blue (emotional intelligence) |

---

## 📊 Comparison: Gemini vs Taurus vs Aries Spectrum

### Speed
- **Aries Range**: 75-100% (always fast - action)
- **Gemini Range**: 70-100% (always fast - thought)
- **Taurus Range**: 20-80% (varies - deliberation)
- **Why**: Cardinal Fire / Mutable Air vs Fixed Earth

### Stubbornness
- **Taurus Range**: 60-110% (very high - immovable)
- **Aries Range**: 50-85% (medium-high - prideful)
- **Gemini Range**: 20-45% (low - adaptable)
- **Why**: Fixed vs Cardinal vs Mutable modalities

### Communication
- **Gemini Range**: 80-100% (essential for survival)
- **Taurus Range**: Not primary (communicate when needed)
- **Aries Range**: 40-60% (action > words)
- **Why**: Air needs expression, Earth builds silently, Fire acts

### Curiosity
- **Gemini Range**: 80-100% (perpetual student)
- **Aries Range**: 60-75% (curious about conquest)
- **Taurus Range**: 30-50% (practical curiosity only)
- **Why**: Air explores ideas, Fire explores action, Earth explores value

---

## 🚀 Quick Start

### Installation

```bash
# Copy to your project
cp -r gemini-spectrum-explorer/ your-project/src/

# Install dependencies (React 18+ only)
npm install
```

### Usage

```jsx
import GeminiSpectrumExplorer from './gemini-spectrum-explorer/components/GeminiSpectrumExplorer';

function App() {
  return (
    <GeminiSpectrumExplorer
      userDegree={7.5}         // Zone 2: Pure Communicator
      userName="Hermes"
    />
  );
}
```

### Props

| Prop | Type | Required | Description |
|------|------|----------|-------------|
| `userDegree` | number | No | Gemini Sun degree (0-29.99) |
| `userName` | string | No | User's name for personalization |

---

## 📂 File Structure

```
gemini-spectrum-explorer/
├── components/
│   ├── GeminiSpectrumExplorer.jsx   # Main container (same as Taurus)
│   ├── DegreeSlider.jsx             # Interactive slider
│   ├── SingleZoneView.jsx           # Detailed profile
│   ├── ViewModeSelector.jsx         # Mode toggle
│   ├── ZoneSelector.jsx             # Zone picker
│   ├── SideBySideView.jsx           # Comparison view
│   ├── FullMatrixView.jsx           # Matrix table
│   └── [CSS files]                  # Styling
├── data/
│   ├── geminiZones.js               # 💬 GEMINI-SPECIFIC DATA
│   └── qualityCategories.js         # Updated with Mental Energy
├── utils/
│   └── zoneCalculations.js          # Zone logic (reusable)
├── README.md                        # This file
└── package.json                     # Dependencies
```

**Note**: Components are identical to Taurus. Only the DATA changes (geminiZones.js).

---

## 💬 Gemini-Specific Features

### 1. Mental Energy Metric 🧠

**New quality not present in Earth/Fire signs**

Measures:
- Cognitive stamina (how long can think intensely)
- Thought speed (how fast processes information)
- Information capacity (how much can hold simultaneously)
- Mental multitasking ability

Displayed as:
- Visual bars (80-100% range)
- Brain icons 🧠
- Color-coded by intensity

### 2. Communication Emphasis 💬

**Highlighted as THE Gemini constant**

All zones show 80-100% communication with special visual treatment:
- Speech bubble icons 💬
- Animated word clouds
- Explanatory text on why Gemini NEEDS to express

### 3. Curiosity Dominance 🔍

**Most curious sign across the board**

Visual comparisons:
- Gemini Zone 6 (80%) vs other signs' maximum
- "Perpetual student of everything"
- Magnifying glass animations on hover

### 4. Low Stubbornness Celebration 💭

**Framed as flexibility strength**

- No zone exceeds 45% stubbornness
- "Adaptable, not wishy-washy"
- Practical tips for maintaining focus despite flexibility

---

## 📖 Educational Content

### Zone-Specific Archetypes

**Zone 1: Articulate Builder**
- Communicates about practical value
- Grounded curiosity
- Stable exploration
- Example: Technical writer, architect who explains design

**Zone 2: The Messenger**
- Pure information flow
- Maximum mental agility
- Social butterfly
- Example: Journalist, social media manager

**Zone 3: The Diplomat**
- Harmonious communication
- Balanced thinking
- Relationship bridge
- Example: Mediator, marriage counselor

**Zone 4: The Connector**
- Strategic networking
- Partnership builder
- Information broker
- Example: Business development, talent agent

**Zone 5: The Teacher-Learner**
- Philosophical exploration
- Innovative thinking
- Humanitarian communication
- Example: Science communicator, educational reformer

**Zone 6: Nurturing Communicator**
- Emotional intelligence
- Memory keeper
- Protective expression
- Example: Family therapist, memoir writer

---

## 🎯 Use Cases

### For Individuals
- "Why am I not as scattered as typical Gemini?" (Zone 1 or 6)
- "I'm Gemini but I stick to topics deeply" (Zone 1 or 3)
- "I'm Gemini and endlessly curious about philosophy" (Zone 5)

### For Relationships
- Gemini-Gemini compatibility (Zone 2 + Zone 2 = information overload!)
- Gemini-Cancer understanding (Zone 6 Gemini bridges to Cancer)
- Air sign dynamics (Gemini-Libra-Aquarius)

### For Career Counseling
- Zone 2: Pure journalism, social media, PR
- Zone 4: Business development, networking roles
- Zone 6: Therapy, education, family services

---

## 🔄 Integration with Other Signs

### Air Sign Trilogy

**Gemini** (60-90°) - Communication
- "I connect through information"
- Mutable Air
- Information exchange

**Libra** (180-210°) - Relationship
- "I connect through harmony"
- Cardinal Air
- Diplomatic balance

**Aquarius** (300-330°) - Innovation
- "I connect through ideas"
- Fixed Air
- Revolutionary thought

**Together**: Complete air journey from information to relationship to innovation

---

## 🎓 Technical Notes

### Architecture
- **Identical to Taurus Spectrum Explorer**
- Only data layer (geminiZones.js) differs
- All components reusable across signs
- Styling uses Gemini color palette

### Performance
- Bundle size: ~150KB (gzipped)
- 60fps slider performance
- No external dependencies beyond React

### Browser Support
- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile fully supported

---

## 📚 Documentation

### For Users
- See in-app tooltips for each quality
- Hover over zone markers for quick info
- Click famous examples for details

### For Developers
- See TAURUS_TEMPLATE.md for full implementation guide
- Components are drop-in compatible
- Customize colors in geminiZones.js colorTheme

---

## 🌟 Famous Gemini Examples by Zone

**Zone 1 (0-4.99°)**: Lauryn Hill (practical artistry + words)  
**Zone 2 (5-9.99°)**: Notorious B.I.G. (pure verbal flow)  
**Zone 3 (10-14.99°)**: Angelina Jolie (diplomatic humanitarian)  
**Zone 4 (15-19.99°)**: Kanye West (strategic networking)  
**Zone 5 (20-24.99°)**: Donald Trump (unconventional communication)  
**Zone 6 (25-29.99°)**: Nicole Kidman (emotional intelligence)  

---

## 🔮 Future Expansion

Once all 12 signs complete:

**Fire Signs**: Aries → Leo → Sagittarius  
**Earth Signs**: Taurus → Virgo → Capricorn  
**Air Signs**: Gemini → Libra → Aquarius  
**Water Signs**: Cancer → Scorpio → Pisces  

**Result**: 72 total zones (12 signs × 6 zones each)

---

## 💬 The Gemini Essence

**Regardless of zone, every Gemini:**
- Communicates to understand reality
- Remains perpetually curious
- Adapts thinking rapidly
- Connects information across domains
- Needs mental stimulation to survive

**Zone just determines:**
- WHAT you're curious about (practical vs philosophical vs emotional)
- HOW you communicate (grounded vs scattered vs diplomatic)
- WHERE you focus (building vs networking vs nurturing)

---

## 🎬 Final Words

**Gemini is the bridge that connects all knowledge.**

Zone 1 bridges practical to theoretical.  
Zone 2 bridges everything to everything (maximally).  
Zone 3 bridges people through harmony.  
Zone 4 bridges networks strategically.  
Zone 5 bridges present to future.  
Zone 6 bridges mind to heart.  

**But they all BRIDGE through COMMUNICATION.**

---

**Built for the communicators, connectors, and curious minds** ♊💬

**"I think, therefore I connect. I connect, therefore I am."** 🧠

---

*Version 1.0.0*  
*Architecture: Taurus Template*  
*Data: Gemini-Specific*  
*Philosophy: Pure Gold Method*  
*Quality: Cathedral Grade*

💬 **Connect Everything. Understand Everything. Share Everything.** 🔍
